<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_jstar_shop_compare/assets/css/compare.css');
$document->addScript('modules/mod_jstar_shop_compare/assets/js/compare.js');
$id = JFactory::getApplication()->input->get('id');
$view = JFactory::getApplication()->input->get('view');
if ($view == 'product' || $view == 'category' || $view == 'customfields') {
    $parentids = modJstar_shop_compareHelper::getparents($view);
    $childids = modJstar_shop_compareHelper::getChildeid($view);
    $catids = array_merge($parentids, $childids);
    $catids = array_unique($catids);
    $catids = implode(',', $catids);
    $arr_pid = @$_SESSION['compare'];
    if (isset($arr_pid) && $arr_pid != NULL) {
        $db = JFactory::getDBO();
		$catids = $db->escape($catids);
        $pids = implode(',', $arr_pid);
        $pids = $db->escape($pids);
        $table = $db->quoteName('#__jstar_shop_products');
        $query = "SELECT `id`,`title` FROM $table WHERE `id` IN ($pids) AND `catid` IN ($catids)";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();
        foreach ($rows as $row) {
            $ids[] = $row->id;
        }
        @$ids = implode(',', $ids);
        @$ids = ',' . $ids;
    }
    ?>
    <div id="compare_main2">
        <ul id="compare">
            <?php if (isset($arr_pid) && $arr_pid != NULL) {
                $uri = JFactory::getURI();
                foreach ($rows as $row) {
                    ?>
                    <li>
                        <div class="ajax_remove"><a id="cart_remove"
                                                    href="index.php?option=com_jstar_shop&task=compare.unset_product&pid=<?php echo $row->id; ?>&url=<?php echo $uri; ?>"></a>
                        </div>
                        <div class="ajax_title"><?php echo $row->title; ?></div>
                        <div class="clear"></div>
                    </li>
                <?php }
            } ?>
        </ul>
        <div id="comp">
            <form action="<?php echo JRoute::_('index.php?option=com_jstar_shop', false); ?>" method="post"
                  enctype="multipart/form-data">
                <input type="hidden" id="ids" name="ids" value="<?php echo @$ids; ?>"/>
                <input type="hidden" name="option" value="com_jstar_shop"/>
                <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                <input type="hidden" name="view" value="compare"/>
                <input type="hidden" name="view2" value="<?php echo $view; ?>"/>
                <input type="submit" class="compare-button"
                       value="<?php echo JText::_('MOD_JSTAR_SHOP_COMPARE_COMPARE'); ?>"/>
            </form>
        </div>
    </div>
<?php }

