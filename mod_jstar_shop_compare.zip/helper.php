<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class modJstar_shop_compareHelper
{
    static function getparents($view)
    {
        $db = JFactory::getDbo();
        if ($view == 'product') {
            $pid = JFactory::getApplication()->input->get('id');
			$pid = $db->escape($pid);
            $table = $db->quoteName('#__jstar_shop_products');
            $query = "SELECT `catid` FROM $table WHERE `id` = '$pid'";
            $db->setQuery($query);
            $catID = $db->LoadResult();
        }
        if ($view == 'category') {
			$catID = JFactory::getApplication()->input->get('id');
        }
        if ($view == 'customfields') {
            $fieldid = JFactory::getApplication()->input->get('id');
			$fieldid = $db->escape($fieldid);
            $table = $db->quoteName('#__jstar_shop_customfields');
            $query = "SELECT `catid` FROM $table WHERE `id` = '$fieldid'";
            $db->setQuery($query);
            $catID = $db->LoadResult();
        }
		$catID = $db->escape($catID);
        $query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` ";
        $db->setQuery($query);
        $parentid = $db->LoadColumn();
        return $parentid;
    }

    static function getChildeid($view)
    {
        $db = JFactory::getDbo();
        if ($view == 'product') {
            $pid = JFactory::getApplication()->input->get('id');
			$pid = $db->escape($pid);
            $table = $db->quoteName('#__jstar_shop_products');
            $query = "SELECT `catid` FROM $table WHERE `id` = '$pid'";
            $db->setQuery($query);
            $catID = $db->LoadResult();
        }
        if ($view == 'category') {
            $catID = JFactory::getApplication()->input->get('id');
        }
        if ($view == 'customfields') {
            $fieldid = JFactory::getApplication()->input->get('id');
            $table = $db->quoteName('#__jstar_shop_customfields');
            $query = "SELECT `catid` FROM $table WHERE `id` = '$fieldid'";
            $db->setQuery($query);
            $catID = $db->LoadResult();
        }
		$catID = $db->escape($catID);
        $query = "SELECT `node`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `parent`.`id` = '$catID' ORDER BY `node`.`lft` ";
        $db->setQuery($query);
        $childid = $db->LoadColumn();
        return $childid;
    }

}
