<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined( '_JEXEC' ) or die;

class plgJstar_shop_paymentsSamplepayment extends JPlugin
{

	 function OnSubmit($orderid, $payment)
	 {	 
	 	// submit to PaymentGateway and set callback URL BY API GETEWAY
		 $callback = JURI::root().'index.php?option=com_jstar_shop&task=payment.call_back&sh='.$orderid.'&payment='.$payment;
		 header('Location: '.$callback);
		 die();
	}
	
	function OnCallBack($orderid,$payment)
	{
		//check status payment
		$this->modifyOrder($orderid,$Refid,$status);
	}
	
	protected function modifyOrder($orderid,$Refid = NULL,$status = NULL)
	{
		$db = JFactory::getDBO();
	//getAmount
		/*
		$query = "SELECT SUM(amount) FROM `#__jstar_shop_orders` WHERE `sh` = '$orderid'";
		$db->setQuery( $query );
		$Amount = $db->LoadResult();
	//update table
		$query = "UPDATE `#__jstar_shop_order_details` SET `bank` = '$status', `RefID` = '$Refid' WHERE `sh_order` = '$orderid'";
		$db->setQuery( $query);
		db->execute();
		*/
	//update table success pay
		$query = "UPDATE `#__jstar_shop_order_details` SET `status` = '0' WHERE `sh_order` = '$orderid'";
		$db->setQuery( $query);
		$db->execute();
		
				
		$app = JFactory::getApplication();
		$link =  JRoute::_('index.php?option=com_jstar_shop',false);
		$msg = JText::_('COM_JSTAR_SHOP_NO_PAYMENT_ORDERID').$orderid;
		$app->redirect($link, $msg);
		
	}
}
?>