<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_jstar_shop_login/assets/css/login.css');
$userid  = JFactory::getUser()->id;
JHtml::_('behavior.modal');
?>
<div id="main_login" class="btn btn-light">
	<div>
        <div id="txt_login">
            <?php if(!isset($userid) || $userid == 0 || $userid == NULL || trim($userid) == '') { ?>
                <span class="login-larg"><?php echo JText::_('MOD_JSTAR_SHOP_LOGIN_REGORLOGIN'); ?></span>
                <span class="login-smal"></span>
            <?php } else { 
                    echo '<span class="btn">'.JFactory::getUser()->name.'</span>';
                 } ?>
        </div>
        <div id="arrow_login"></div>
        <div class="clear"></div>
    </div>
    
    <div id="login_form">
    	<?php if(!isset($userid) || $userid == 0 || $userid == NULL || trim($userid) == '') { ?>
            <div id="register_link">
                <a class="btn btn-success btn-block" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=register'); ?>">
                	<?php echo JText::_('JREGISTER'); ?>
                </a>
            </div>
            <div id="login_link">
                <a class="btn btn-info btn-block" href="<?php echo JRoute::_('index.php?option=com_users&view=login'); ?>">
                	<?php echo JText::_('JLOGIN'); ?>
                </a>
            </div>
        <?php } else { ?>
            <div id="loginform_menus">
                <div><a class="btn  btn-block" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=profile'); ?>"><?php echo JText::_('MOD_JSTAR_SHOP_LOGIN_PROFILE'); ?></a></div>
                <div><a class="btn  btn-block" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=orders'); ?>"><?php echo JText::_('MOD_JSTAR_SHOP_LOGIN_ORDERS'); ?></a></div>
                <div><a class="btn  btn-block" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=user_interests'); ?>"><?php echo JText::_('MOD_JSTAR_SHOP_LOGIN_INIT'); ?></a></a></div>
                <div><a class="btn  btn-block" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=recommend'); ?>"><?php echo JText::_('MOD_JSTAR_SHOP_LOGIN_COMMENTS'); ?></a></div>
            </div>
        <?php } ?>
    </div>
</div>