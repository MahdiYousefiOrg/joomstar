<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class modJstar_shop_tagsHelper
{
    static function getTags($id)
    {
        $db = JFactory::getDBO();
		$id = $db->escape($id);
        $query = "SELECT `tag2` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
        $db->setQuery($query);
        $tag = $db->LoadResult();
        return $tag;
    }

}
