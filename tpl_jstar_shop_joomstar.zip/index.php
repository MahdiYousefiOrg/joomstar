<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$doc             = JFactory::getDocument();
$doc->setHtml5(true);
$view = JFactory::getApplication()->input->get('view'); 
$db = JFactory::getDBO();
JHtml::_('jquery.framework');
JHtml::_('bootstrap.framework');
if($this->direction == 'rtl') {
	$doc->addStyleSheet($this->baseurl . '/templates/' . $this->template . '/css/template_rtl.css');
	JHtml::_('bootstrap.loadCss', true, 'rtl');
	$logo = 'joomstar_logo_rtl';
} else {
	$doc->addStyleSheet($this->baseurl . '/templates/' . $this->template . '/css/template.css');
	JHtml::_('bootstrap.loadCss', true, 'ltr');
	$logo = 'joomstar_logo_ltr';
}

JHtml::_('script', 'media/system/core.js', true, true);
if($view == 'category'){ 
 $catID = JFactory::getApplication()->input->get('id'); 
 $catID = $db->escape( $catID ) ;
 function getparents3(){
	 $db				= JFactory::getDbo();
	 $view = JFactory::getApplication()->input->get('view');  
		if($view == 'category'){ 
		    $catID = JFactory::getApplication()->input->get('id'); 
		} 
		$query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` "; 
		$db->setQuery( $query );
		$parentid = $db->LoadColumn();
		return $parentid;
 }
	    $parentids = getparents3();
    	$catids = implode(',',$parentids);
	
	$table = $db->quoteName( '#__jstar_shop_customfields' );
	$query = "SELECT * FROM $table WHERE `catid` IN ($catids) AND `published` = 1 AND `search` = '1' AND `type` != '1' AND `type` != '4' AND `type` != '5'";
	$db->setQuery( $query );
	$rows = $db->LoadObjectList();
	
	$query = "SELECT `description` FROM `#__categories` WHERE `id` = '$catID'";
	$db->setQuery( $query );
	$cat_desc = $db->LoadResult();
}
$span= '12';
$userid  = JFactory::getUser()->id;?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="fa-ir" dir="rtl" xml:lang="fa-ir" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />   
    <jdoc:include type="head" />
    <link rel="icon" href="<?php echo JURi::root() . '/templates/'. $this->template . '/favicon.png'; ?>">
    <?php $lang = JFactory::getLanguage();
		 $lang = $lang->getTag();
		 if($lang != 'fa-IR'){ ?>
    <style>.js-search-input{border-radius:7px 0 0 7px !important}#smal_amazing .nav-tabs{float:left !important; text-align:left !important}#smal_amazing .tab-content{float:right !important;}
	#menu,.address,ul.mod-list,#cat_description,table{direction:ltr;}.address{margin-left:20px !important}div.limit{float:right !important;}
	#main_product{border-left:1px solid #bbb !important; border-right:none !important}.multicost2{float:left !important; margin-left:6px !important;}
	#store-info-service{margin-left:20px !important; margin-top:20px !important;}#tab_group_idContent{direction:ltr;}#comment_txt{float:left !important;margin-right:15px !important; margin-left:0 !important;}div#buttom,div.check{float:left;}
	.td1{text-align:right !important}.td2{text-align:left !important}#txt_login{float:left !important} #component{direction:ltr;}#status{float:right !important}.type_post ul li{text-align:left !important}
	input.js-search-input{text-align:left !important;}.c-price{float:none !important;}#wrapper{float:left !important;}#main_product{float:right !important}
	ul.main_f_u{text-align:left !important;}.title_best{text-align:left !important; padding-right:0 !important; padding-left:40px !important}
	@media (min-width: 1200px){
		#main_body{
			padding-right:0 !important;
		}
	}	
	</style>
    <?php } ?>
<meta property="og:title" content="joomstar | eCommerce For joomla" />
<meta property="og:type" content="website" />
<meta property="og:url" content="http://joomstar.ir" />
</head>
<body>
	<div id="top">
        <div class="row-fluid">
            <div id="logo" class="span2"><img src="<?php echo $this->baseurl . '/templates/' . $this->template . '/images/'.$logo.'.png'; ?>" alt="joomstar" /></div>
            <div class="span6"><jdoc:include type="modules" name="search_txt" style="none" /></div>
            <div class="span4">
                <div id="login2"><jdoc:include type="modules" name="login" style="none" /></div>
                <div id="bagcart">
                    <jdoc:include type="modules" name="bagcart" style="none" />
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
         </div>
    </div><!-- top /-->
    <?php if(is_numeric($userid) && $userid != 0) { ?>
        <div id="usermenu">
            <jdoc:include type="modules" name="usermenu" style="none" />
            <div class="clear"></div>
        </div><!-- usermenu /-->
    <?php } ?>
    <div id="menu">
        <jdoc:include type="modules" name="mainmenu" style="none" />
        <div class="clear"></div>
    </div><!-- menu /-->

    <div id="mobile_menu"><jdoc:include type="modules" name="mobile_menu" style="none" /></div>
    <?php if ($this->countModules('slider')) {?>
    <div id="header">
    	<jdoc:include type="modules" name="slider" style="none" />
    </div><!-- header -->
    <?php } ?>

	<?php if ($this->countModules('amazing') && $view == 'categories') { ?>
        <jdoc:include type="modules" name="amazing" style="rounded" />
    <?php } ?>
    <?php if ($this->countModules('page1_txt1')) {?>
        <div id="page1_txt1">
            <jdoc:include type="modules" name="page1_txt1" style="none" />
        </div>
    <?php } ?>
    <div id="main_body" class="row-fluid">
    	<div class="span12">
        <?php if(!empty($rows)){ $span = 9; ?>
        	<div class="span3" id="right">
            	<jdoc:include type="modules" name="right" style="none" />
            </div>
        <?php } ?>
            <div id="component" class="span<?php echo $span; ?>">
            	<jdoc:include type="message" />
            	<div id="compare_main"><jdoc:include type="modules" name="compare" style="none" /></div>
                <jdoc:include type="component" />
            </div>
        </div>
      </div>
      
      
		<?php if ($this->countModules('best1') && $view == 'categories') { ?>
            <jdoc:include type="modules" name="best1" style="none" />
        <?php } 
        $lang = JFactory::getLanguage();
		$lang = $lang->getTag();
		if($lang == 'fa-IR'){
		?>
        <div id="menus_2" class="row-fluid">
        	<div class="span4" id="smal_span4">
            	<jdoc:include type="modules" name="submenu1" style="rounded" />
            </div>
        	<div class="span4">
            	<jdoc:include type="modules" name="submenu2" style="rounded" />
            </div>
        	<div class="span4 address">
            	<jdoc:include type="modules" name="submenu3" style="none" />
            </div>
        </div>
      
      
      
		<?php if ($this->countModules('page1_txt1')) { ?>
        <div class="row-fluid">
            <div id="page1_txt1">
                <jdoc:include type="modules" name="page1_txt1" style="none" />
            </div>
        </div>
        <?php } ?>
        <div class="row-fluid">
        <div id="cat_description" class="span12">
        	<jdoc:include type="modules" name="page1_txt2" style="none" />
        </div>
        </div>
        <?php } ?>
        <div id="footer">
            <jdoc:include type="modules" name="footer" style="none" />
        </div>
    </div>
    <!-- main_body -->
</body>
</html>