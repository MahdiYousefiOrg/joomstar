<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_jstar_shop_cart/assets/css/cart.css');
$document->addScript('modules/mod_jstar_shop_cart/assets/js/cart.js');
$id = JFactory::getApplication()->input->get('id');
$view = JFactory::getApplication()->input->get('view');
$arr_pid = @$_SESSION['product'];
@$arr_pid = array_filter($arr_pid);
$amazing = @$_SESSION['amazing'];
@$amazing = array_filter($amazing);
$uri = JFactory::getURI();
$link = JRoute::_('index.php?option=com_jstar_shop&view=cart', false);
?>
<div id="cart_bag">
    <div id="cart_icon"></div>
    <div id="cart_text"><?php echo JText::_('MOD_JSTAR_SHOP_CART'); ?></div>
    <div id="cart_count">
        <div id="cart_count_txt"><?php echo @count(@array_unique(@$_SESSION['product'])) + @count(@array_unique(@$_SESSION['amazing'])); ?></div>
    </div>
    <div class="clear"></div>
</div>
<?php if ($view != 'cart' && $view != 'factor') { ?>
    <?php if ((isset($arr_pid) && $arr_pid != NULL) || (isset($amazing) && $amazing != NULL)) { ?>
        <div id="shoping_cart">
            <ul id="bag">
                <?php
                if (isset($arr_pid) && $arr_pid != NULL) {
                    $rows = modJstar_shop_cartHelper::getProductsCart();
                    foreach ($rows as $row) { ?>
                        <li>
                            <div class="ajax_remove"><a id="cart_remove"
                                                        href="index.php?option=com_jstar_shop&task=cart.unset_product&pid_remove=<?php echo $row->id; ?>&url=<?php echo $uri; ?>"></a>
                            </div>
                            <div class="ajax_title"><?php echo $row->title; ?></div>
                            <div class="clear"></div>
                        </li>
                    <?php }
                }
                if (isset($amazing) && $amazing != NULL) {
                    $rows = modJstar_shop_cartHelper::getAmazingsCart();
                    foreach ($rows as $row2) { ?>
                        <li>
                            <div class="ajax_remove"><a id="cart_remove"
                                                        href="index.php?option=com_jstar_shop&task=cart.unset_amazing&pid_remove=<?php echo $row2->id; ?>&url=<?php echo $uri; ?>"></a>
                            </div>
                            <div class="ajax_title"><?php echo $row2->title; ?></div>
                            <div class="clear"></div>
                        </li>
                    <?php }
                }
                ?>
            </ul>

            <div id="buy"><a class="btn btn-success btn-block"
                             href="<?php echo $link; ?>"><?php echo JText::_('MOD_JSTAR_SHOP_CART_END_BUY'); ?></a>
            </div>

        </div>
    <?php }
} ?>

