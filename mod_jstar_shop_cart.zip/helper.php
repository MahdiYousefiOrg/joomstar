<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class modJstar_shop_cartHelper
{
    static function getProductsCart()
    {
        $arr_pid = @$_SESSION['product'];
        @$arr_pid = array_filter($arr_pid);
        $db = JFactory::getDBO();
        $pids = implode(',', $arr_pid);
        $pids = $db->escape($pids);
        $table = $db->quoteName('#__jstar_shop_products');
        $query = "SELECT `id`,`title`,`price` FROM $table WHERE `id` IN ($pids)";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();
        return $rows;
    }

    static function getAmazingsCart()
    {
        $amazing = @$_SESSION['amazing'];
        @$amazing = array_filter($amazing);
        $db = JFactory::getDBO();
        $amazings = implode(',', $amazing);
        $aids = $db->escape($amazings);
        $table = $db->quoteName('#__jstar_shop_amazings');
        $query = "SELECT `id`,`title`,`cost2` FROM $table WHERE `id` IN ($aids)";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();
        return $rows;
    }
}
