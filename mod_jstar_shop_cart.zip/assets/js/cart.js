function add_cart(pid){
    
	var str=pid;
	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200 )
		{
		 var jsondata=eval("("+xmlhttp.responseText+")");
		 var rssentries=jsondata.items;
			   var node = document.createElement("li"); 
			   
			   /*var div1 = document.createElement("div"); 
			   div1.className = "ajax_title";
			   var textnode = document.createTextNode(jsondata.items['title']);
			   div1.appendChild(textnode);
			   node.appendChild(div1);
			   var div5 = document.createElement("div"); 
			   div5.className = "clear";
			   node.appendChild(div5);

		  	   document.getElementById("shoping_cart").appendChild(node);
			  window.open("http://goharweb.ir/demo/index.php?option=com_jstar_shop&view=cart");*/
		}
	  }
	  
	xmlhttp.open("GET",'index.php?option=com_jstar_shop&view=product&format=raw&pid='+str ,true);
	xmlhttp.send();
    /*document.getElementById("alert").style.display = "block";
    setTimeout(function() 
        { 
        document.getElementById("alert").style.display = "none"; 
        }, 
        10000);  	*/
}
