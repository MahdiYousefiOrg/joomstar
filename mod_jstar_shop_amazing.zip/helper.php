<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
 
class modJstar_shop_amazingHelper {
	static function fa_digits2($text){
		$lang = JFactory::getLanguage();
		$lang = $lang->getTag();
		if($lang == 'fa-IR'){
			$persian_digits = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
		} else {
			$persian_digits = array('0','1','2','3','4','5','6','7','8','9');
		}
		$english_digits = array('0','1','2','3','4','5','6','7','8','9');
		$text = str_replace($english_digits, $persian_digits, $text);
		return $text;
	}
	static function getItems(){
	    $db = JFactory::getDbo();
        $config = JFactory::getConfig();
        $offset = $config->get('offset');
        $tz = new DateTimeZone($offset);
        $date = JFactory::getDate('now', $tz);
        $query = "SELECT DISTINCT `a`.`off`,`a`.`pids` FROM `#__jstar_shop_amazings` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON FIND_IN_SET(`b`.`id`,`a`.`pids`) WHERE '$date' >= `a`.`date1`  AND '$date' <= `a`.`date2` AND `a`.`module` = '1'";
        $db->setQuery($query);
        $amazings = $db->LoadObjectList();
        $i = 0;
        foreach ($amazings as $amazing){
            $arr_temp = explode(',',$amazing->pids);
            foreach ($arr_temp as $temp){
                $arr[$i.'-'.$amazing->off] = $temp;
                $i++;
            }

        }
        $Amazings = array_unique($arr);
        if(!empty($Amazings)) {
            $query = 'SELECT `id`,`title`,`price`,`off`, `img1` FROM `#__jstar_shop_products` WHERE `id` IN (' . implode(',', $Amazings) . ') ORDER BY `ordering`';
            $db->setQuery($query);
            $rows = $db->LoadObjectList();
            return $rows;
        } else { return true; }
	}

}
