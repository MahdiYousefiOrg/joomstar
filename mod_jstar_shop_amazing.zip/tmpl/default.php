<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$image = $params->get('image');
$doc = JFactory::getDocument();
$doc->addStyleSheet('modules/mod_jstar_shop_amazing/assets/css/main.css');

if(is_array($rows) && !empty($rows)){
    $config = JFactory::getConfig();
    $offset = $config->get('offset');
    $tz = new DateTimeZone($offset);
	date_default_timezone_set($tz);
	$cdate = date('H,i,s,m,d,Y'); 
	$cdate = explode(',',$cdate);
	$cdate = mktime((int)$cdate[0],(int)$cdate[1],(int)$cdate[2],(int)$cdate[3],(int)$cdate[4],(int)$cdate[5]);
    $amazings = Jstar_shop_CHeckupHelper::getAmazings();
?>

<div class="row-fluid">
    <div id="amazing_module" class="span12">
    <div class="span3" id="larg_amazing">
   	<?php if($image) { ?>
            <a href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=amazings'); ?>"><img src="<?php echo JURI::root().$image; ?>" /></a>

    <?php } ?>
    </div>
	<div class="span9" id="smal_amazing">
        <div class="container">
          <div id="tab-carousel">
              <div class="test">
                <ul class="nav nav-tabs">
					<?php
                    $k = 0;
                    foreach($rows as $i => $item){ $k++; if($k == 1) {$class = 'active';} else { $class = ''; }
                        $date01 = $item->date1;
                        $date01 = explode(' ',$date01);
                        $date1 = $date01[0];
                        $time1 = $date01[1];
                        
                        $date02 = $item->date2;
                        $date02 = explode(' ',$date02);
                        $date2 = $date02[0];
                        $time2 = $date02[1]; 
                                
                        $date1 = explode('-',$date1);
                        $time1 = explode(':',$time1);
                        $cdate1 = mktime((int)$time1[0],(int)$time1[1],(int)$time1[2],(int)$date1[1],(int)$date1[2],(int)$date1[0]);
                        
                        $date2 = explode('-',$date2);
                        $time2 = explode(':',$time2);
                        $cdate2 = mktime((int)$time2[0],(int)$time2[1],(int)$time2[2],(int)$date2[1],(int)$date2[2],(int)$date2[0]);
                        
                        
                        if( $cdate > $cdate1 && $cdate < $cdate2){
                            $link = JRoute::_('index.php?option=com_jstar_shop&view=amazing&aid='.$item->id);
                            $showdate1 = str_replace('-','/',$item->date1);
                            $showdate2 = str_replace('-','/',$item->date2);
                    
                        }  ?>
                        <li class="<?php echo $class; ?>">
                            <a href="#<?php echo $item->id; ?>"><?php echo $item->title; ?></a>
                        </li>
                        <?php } ?>
                </ul>
            </div><!-- test /-->
            <div class="tab-content">
				<?php $k=0; foreach($rows as $i => $item){  $k++; if($k == 1) {$class = ' active';} else { $class = ' test'; }
                $link = JRoute::_('index.php?option=com_jstar_shop&view=product&id='.$item->id);
                    $off = array_search($item->id, $amazings);
                    $off = explode('-', $off)[1];
                ?>
                <div class="tab-pane<?php echo $class; ?>" id="<?php echo $item->id; ?>">
                    <div id="title_amazing">
                    <?php echo $item->title; ?>
                </div>
                <a class="amazin_link_slide" href="<?php echo $link; ?>"><?php echo JText::_('MOD_JSTAR_SHOP_AMAZING_SHOW'); ?></a>
                <div id="img_amazin">
                    <img src="<?php echo $item->img1; ?>" />
                </div>
                <div class="c-promotion_discount">
                    <span><?php echo '%'.modJstar_shop_amazingHelper::fa_digits2($off); ?> <?php echo JText::_('MOD_JSTAR_SHOP_AMAZING_OFF'); ?></span>
                </div>
                <div id="product_price">
                    <div class="c-price">
                        <div class="main_amazin_price"><?php echo modJstar_shop_amazingHelper::fa_digits2(@number_format($item->off-round($item->off*$off/100))).'  '.JText::_('MOD_JSTAR_SHOP_AMAZING_TOMAN'); ?></div>
                    </div>

                    <div class="c-price2">
                        <del id="price_product"><?php echo modJstar_shop_amazingHelper::fa_digits2(@number_format($item->off)); ?></del>
                    </div>

                </div><!-- product_price /-->
          </div><!-- tab-content /-->
<?php } ?>
        </div><!-- container /-->
        <div class="clear"></div>
      </div>
    </div>
</div>
</div>
</div>
  <script src='<?php echo JURI::base(true) . '/modules/mod_jstar_shop_amazing/assets/js/jquery.min.js'; ?>'></script>
  <script src='<?php echo JURI::base(true) . '/modules/mod_jstar_shop_amazing/assets/js/bootstrap.min.js'; ?>'></script>
  <script src='<?php echo JURI::base(true) . '/modules/mod_jstar_shop_amazing/assets/js/timer.js'; ?>'></script>
<?php } ?>







