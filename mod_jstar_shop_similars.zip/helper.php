<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class modJstar_shop_similarsHelper
{
    static function getCatid($id)
    {
        $db = JFactory::getDBO();
        $id = $db->escape($id);
        $query = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
        $db->setQuery($query);
        $catid = $db->LoadResult();
        return $catid;

    }

    static function getArr($id, $catid)
    {
        $db = JFactory::getDBO();
        $id = $db->escape($id);
        $catid = $db->escape($catid);
        $query = "SELECT a.id FROM `#__jstar_shop_products` AS a LEFT JOIN `#__jstar_shop_similars` AS b ON find_in_set (a.id,b.products_id) WHERE find_in_set(a.id,b.products_id) AND a.id != '$id' AND a.catid = '$catid'";
        $db->setQuery($query);
        $arr = $db->LoadColumn();
        return $arr;
    }

    static function getItems($id, $catid, $pids)
    {
        $db = JFactory::getDBO();
        $id = $db->escape($id);
        $catid = $db->escape($catid);
        $pids = $db->escape($pids);

        $query = "SELECT a.id,a.off,a.title,a.img1 FROM `#__jstar_shop_products` AS a LEFT JOIN `#__jstar_shop_similars` AS b ON find_in_set (a.id,b.products_id) WHERE find_in_set(a.id,b.products_id) AND a.id != '$id' AND a.catid = '$catid' AND a.id IN ($pids)";
        $db->setQuery($query);
        $result = $db->LoadObjectList();
        return $result;
    }
}
