function setPrice(id, pid, off) {
  var price = 0;
  var xmlhttp;
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp = new XMLHttpRequest();
  } else {
    // code for IE6, IE5
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      var jsondata = eval("(" + xmlhttp.responseText + ")");
      var rssentries = jsondata.items;
      document.getElementById("price_product").innerHTML =
        '<del><span id="cost1">' +
        numberWithCommas(rssentries["cost1"]) +
        "</span></del>";
      document.getElementById("price_product2").innerHTML = numberWithCommas(
        rssentries["cost2"] - Math.round((rssentries["cost2"] * off) / 100)
      );
      var all = document.getElementsByClassName("multicost2");
      for (var i = 0; i < all.length; i++) {
        all[i].style.background = "none";
        all[i].style.border = "#cccccc 1px solid";
        all[i].style.color = "#89979a";
      }
      document.getElementById("multicost" + id).style.background = "#ee5662";
      document.getElementById("multicost" + id).style.color = "#ffffff";
      document.getElementById("multicost" + id).style.border =
        "#5d183a 1px solid";
    }
  };
  xmlhttp.open(
    "GET",
    "index.php?option=com_jstar_shop&view=multicosts&format=raw&pid=" +
      pid +
      "&fieldid=" +
      id,
    true
  );
  xmlhttp.send();
}
function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
