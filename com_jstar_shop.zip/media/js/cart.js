function getSubcits() {
  var str = document.getElementById("state1").value;
  var xmlhttp;
  if (str == 0) {
    document.getElementById("city1").innerHTML = "";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp = new XMLHttpRequest();
  } else {
    // code for IE6, IE5
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      document.getElementById("city1").innerHTML =
        '<option value="0">- Select -</option>';
      var jsondata = eval("(" + xmlhttp.responseText + ")");
      var rssentries = jsondata.items;
      var output = "";
      for (var i = 0; i < rssentries.length; i++) {
        output +=
          '<option value="' +
          rssentries[i].id +
          '">' +
          rssentries[i].city +
          "</option>";
      }
      document.getElementById("city1").innerHTML += output;
    }
  };
  xmlhttp.open(
    "GET",
    "index.php?option=com_jstar_shop&view=cart&format=raw&parentcit=" + str,
    true
  );
  xmlhttp.send();
}
