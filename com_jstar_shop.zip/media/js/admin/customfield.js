function showgroup()
{ 
	var str=document.getElementById('jform_catid').value;
	var xmlhttp;
	if (str.length==0)
	  { 
	  document.getElementById("jform_group_id").innerHTML="";
	  return;
	  }
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		 var jsondata=eval("("+xmlhttp.responseText+")");
		  var rssentries=jsondata.items;
		  var output='';
		 for (var i=0; i<rssentries.length; i++){
			 output+='<option value="'+jsondata.items[i]['id']+'">'+jsondata.items[i]['title']+'</option>';
		 }
		   document.getElementById("jform_group_id").innerHTML=output
		}
  }
xmlhttp.open("GET",'index.php?option=com_jstar_shop&view=group_fields&format=raw&catid='+str ,true);
xmlhttp.send();
}
