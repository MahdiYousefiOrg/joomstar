function showlimits()
{
	var str=document.getElementById('jform_size').value;
	var xmlhttp;
	if (str.length==0)
	  { 
	  document.getElementById("jform_posts").innerHTML="";
	  return;
	  }
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		 var jsondata=eval("("+xmlhttp.responseText+")");
		  var rssentries=jsondata.items;
		  var output='<fieldset id="jform_posts" class="checkboxes">';
		 for (var i=0; i<rssentries.length; i++){
			 output+='<label for="jform_posts' +jsondata.items[i]['id']+ '" class="checkbox">' +jsondata.items[i]['type_post']+'-'+jsondata.items[i]['title'];
			 output+='<input id="jform_posts' +jsondata.items[i]['id']+ '" type="checkbox" name="jform[posts][]" value="' +jsondata.items[i]['id']+ '" />'
		 }
		   document.getElementById("jform_posts").innerHTML=output
		}
		output+='</fieldset>';
  }
xmlhttp.open("GET",'index.php?option=com_jstar_shop&view=posts&format=raw&size='+str ,true);
xmlhttp.send();
}
