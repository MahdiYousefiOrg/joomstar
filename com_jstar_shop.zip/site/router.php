<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;

function Jstar_shopBuildRoute(&$query)
{
    $segments = array();
    if (isset($query['id'])) {
        if (@$query['view'] == 'category') {
            $db = JFactory::getDbo();
            $aquery = "SELECT alias FROM `#__categories` WHERE `id` = '$query[id]'";
            $db->setQuery($aquery);
            $obj = $db->LoadObject();
            $segments[] = $obj->alias;
            $segments[] = 'category';
        }
        if (@$query['view'] == 'product') {
            $db = JFactory::getDbo();
            $aquery = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$query[id]'";
            $db->setQuery($aquery);
            $obj = $db->LoadObject();
            @$alias = str_replace(" ", "_", $obj->title);
            $segments[] = $alias;
            $segments[] = 'product';
            if (@$query['comment'] == 1) {
                $segments[] = 'comment';
                unset($query['comment']);
            }
        }
        unset($query['id']);
    }
    if (isset($query['aid'])) {
        if (@$query['view'] == 'amazing') {
            $segments[] = $query['aid'];
            $segments[] = 'amazing';
            unset($query['aid']);
        }
    }
    if (isset($query['pid'])) {
        if (@$query['view'] == 'interest') {
            $segments[] = $query['pid'];
            $segments[] = 'interest';
            unset($query['pid']);
        }
        if (@$query['view'] == 'comment') {
            $segments[] = $query['pid'];
            $segments[] = 'comment';
            unset($query['comment']);
            unset($query['pid']);
        }
    }
    if (@$query['view'] == 'orderinfo') {
        if (isset($query['sh'])) {
            $segments[] = $query['sh'];
            $segments[] = 'orderinfo';
            unset($query['sh']);
        }
    }
    if (@$query['view'] == 'cart') {
        $segments[] = 'cart';
        $segments[] = 'cart';
    }
    if (@$query['view'] == 'amazings') {
        $segments[] = 'offers';
        $segments[] = 'amazings';
    }
    if (@$query['view'] == 'licencekey') {
        $segments[] = 'active';
        $segments[] = 'licencekey';
    }
    if (@$query['view'] == 'recommend') {
        $segments[] = 'user';
        $segments[] = 'recommend';
    }
    if (@$query['view'] == 'factor') {
        $segments[] = 'cart';
        $segments[] = 'factor';
    }
    if (@$query['view'] == 'register') {
        $segments[] = 'user';
        $segments[] = 'register';
    }
    if (@$query['view'] == 'profile') {
        $segments[] = 'user';
        $segments[] = 'profile';
    }
    if (@$query['view'] == 'searched') {
        $segments[] = 'products';
        $segments[] = 'searched';
    }
    if (@$query['view'] == 'user_interests') {
        $segments[] = 'user';
        $segments[] = 'user_interests';
    }
    if (@$query['view'] == 'orders') {
        $segments[] = 'user';
        $segments[] = 'orders';
    }
    unset($query['view']);
    return $segments;
}

function Jstar_shopParseRoute($segments)
{
    $segments[0] = str_replace(':', '-', $segments[0]);
    $vars = array();
    switch (@$segments[1]) {
        case 'category':
            $vars['view'] = 'category';
            $db = JFactory::getDbo();
            $aquery = "SELECT `id` FROM `#__categories` WHERE `alias` = '$segments[0]'";
            $db->setQuery($aquery);
            $obj = $db->LoadObject();
            $vars['id'] = $obj->id;
            break;
        case 'product':
            $vars['view'] = 'product';
            $db = JFactory::getDbo();
            $segments[0] = str_replace("_", " ", $segments[0]);
            $aquery = "SELECT `id` FROM `#__jstar_shop_products` WHERE `title` = '$segments[0]'";
            $db->setQuery($aquery);
            $obj = $db->LoadObject();
            $vars['id'] = $obj->id;
            if (isset($segments[2])) {
                $vars['comment'] = 'comment';
            }
            break;
        case 'cart':
            $vars['view'] = 'cart';
            $vars['id'] = 'cart';
            break;
        case 'orderinfo':
            $vars['view'] = 'orderinfo';
            $vars['sh'] = $segments[0];
            break;
        case 'interest':
            $vars['view'] = 'interest';
            $vars['pid'] = $segments[0];
            break;
        case 'comment':
            $vars['view'] = 'comment';
            $vars['pid'] = $segments[0];
            break;
        case 'amazing':
            $vars['view'] = 'amazing';
            $vars['aid'] = $segments[0];
            break;
        case 'register':
            $vars['view'] = 'register';
            break;
        case 'amazings':
            $vars['view'] = 'amazings';
            break;
        case 'recommend':
            $vars['view'] = 'recommend';
            break;
        case 'user_interests':
            $vars['view'] = 'user_interests';
            break;
        case 'searched':
            $vars['view'] = 'searched';
            break;
        case 'factor':
            $vars['view'] = 'factor';
            break;
        case 'orders':
            $vars['view'] = 'orders';
            break;
        case 'profile':
            $vars['view'] = 'profile';
            break;
        case 'licencekey':
            $vars['view'] = 'licencekey';
            break;
    }
    return $vars;
}

