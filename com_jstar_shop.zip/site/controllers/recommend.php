<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerRecommend extends JControllerLegacy
{
	public function getModel($name = 'recommend', $prefix = 'Jstar_shopModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function save2(){
		$data = JRequest::get('post');
		$model = $this->getModel();
		$check = $model->save2($data);
		$redirectTo = JRoute::_('index.php',false);
		if($check){
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_RECOMMEND_SAVWD") );
		} else {
			$redirectTo = JRoute::_('index.php?option=com_jstar_shop&view=recommend',false);
			$this->setRedirect( $redirectTo);
		}
	}
}
