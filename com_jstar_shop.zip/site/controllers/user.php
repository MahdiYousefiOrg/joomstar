<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerUser extends JControllerLegacy
{
	public function getModel($name = 'user', $prefix = '', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function cancel(){
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=comment',false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_NOT_REGISTER"));
	}
	public function register() {
		$model = $this->getModel();
		$data = JRequest::get('post');
		$data=$data['jform'];
		$check = $model->register($data);
		if(!$check){
			$this->cancel();
		} elseif($check == 2) {
			$redirectTo = JRoute::_('index.php',false);
		} elseif($check == 3){
				$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cart' ,false);
		} elseif($check == 4){
				$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=profile' ,false);
		}
		else
		{
			$pid = $check;
			$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=comment&pid='.$pid ,false);
		} 
		if(!isset($redirectTo)) $redirectTo =  JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=profile' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_USER_REGISTER"));
	}
	public function login(){
		$model = $this->getModel();
		$data = JRequest::get('post');
		$model->login($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cart' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_LOGINED"));
	}
}
