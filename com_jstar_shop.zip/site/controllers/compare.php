<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerCompare extends JControllerLegacy
{
	public function unset_product(){ 
		$pid = JFactory::getApplication()->input->get('pid', 0, 'int');
		$url = JFactory::getApplication()->input->get('url', null, 'string');
		unset($_SESSION['compare'][$pid]);
		$redirectTo = JRoute::_($url,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_UNSET_COMPARE"));
	}
}
