<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerPayment extends JControllerLegacy
{
	public function getModel($name = 'peyment', $prefix = 'Jstar_shopModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function setbank() {
			$payment = JFactory::getApplication()->input->get('payment', 'nobank', 'string');
			$model = $this->getModel();
			$model->save_order($payment);
			$redirectTo = JRoute::_('index.php' ,false);
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_ORDER_SAVE"));
	}
	
	public function call_back() {
			$orderid = JFactory::getApplication()->input->get('sh');
			$payment = JFactory::getApplication()->input->get('payment', 'nobank', 'string');
			JPluginHelper::importPlugin( 'jstar_shop_payments', $payment );
			$dispatcher = JEventDispatcher::getInstance();
			$params = array($orderid,$payment); 
			$results = $dispatcher->trigger( 'OnCallBack', array($orderid,$payment) );
	}
	public function gotobank_AfterOrderConfirm() {
			$payment = JFactory::getApplication()->input->get('payment', 'nobank', 'string');
			$model = $this->getModel(); 
			$model->gotobank($payment);
	}
}