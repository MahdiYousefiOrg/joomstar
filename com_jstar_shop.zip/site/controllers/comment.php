<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerComment extends JControllerLegacy
{
	public function getModel($name = 'comment', $prefix = '', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function save() {
		$model = $this->getModel();
		$data = JRequest::get('post');
		$data=$data['jform']; 
		$check = $model->save($data);
		if(!$check){
			$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string') ,false);
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_PROBLEM_SAVE"));
		}
		else
		{	$pid = $check;
			$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=product&id='.$pid.'&comment=1' ,false);
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_COMMENT_SAVE"));
		} 
	}
}
