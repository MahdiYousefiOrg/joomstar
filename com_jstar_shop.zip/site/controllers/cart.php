<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerCart extends JControllerLegacy
{
	public function unset_product(){
		$pid_remove = JFactory::getApplication()->input->get('pid_remove', null, 'string');
		$url = JFactory::getApplication()->input->get('url', null, 'string');
		$view =JFactory::getApplication()->input->get('view', '', 'string');
		$userid = JFactory::getUser()->id;
		if($view == 'cart'){
			$url.='&pid_remove='.$pid_remove;
		}
		unset($_SESSION['product'][$pid_remove]);
		if(!isset($url)){
			$redirectTo = JRoute::_('index.php?option=com_jstar_shop&view=cart',false);
		} else {
			$redirectTo = JRoute::_($url,false);
		}
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_UNSET_PRODUCT")); 
	}
	public function unset_amazing(){ 
		$pid_remove = JFactory::getApplication()->input->get('pid_remove', null, 'string');
		$url = JFactory::getApplication()->input->get('url', null, 'string');
		$view =JFactory::getApplication()->input->get('view', null, 'string');
		if($view == 'cart'){
			$url.='&pid_remove='.$pid_remove;
		}
		unset($_SESSION['amazing'][$pid_remove]);
		if(!isset($url)){
			$redirectTo = JRoute::_('index.php?option=com_jstar_shop&view=cart',false);
		} else {
			$redirectTo = JRoute::_($url,false);
		}
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_UNSET_PRODUCT")); 
	}
}
