<?php
/**
 * @package    StarShop for Joomla!
 * @version    1.0.9
 * @author    joomstar.ir
 * @copyright    (C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license    GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$id = JFactory::getApplication()->input->get('id', '0', 'int');
$categories = JCategories::getInstance('jstar_shop');
$db = JFactory::getDbo();
$cat = $categories->get($id);
$children = $cat->hasChildren();
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/category.css');
$params = JComponentHelper::getParams('com_jstar_shop');

if (isset($this->meta->metakey) && $this->meta->metakey != NULL && $this->meta->metakey != '') {
    $doc->setMetaData('keywords', $this->meta->metakey, true);
}
if (isset($this->meta->metadesc) && $this->meta->metadesc != NULL && $this->meta->metadesc != '') {
    $doc->setMetaData('discription', $this->meta->metadesc, true);
}
$link_cat = 'index.php?option=com_jstar_shop&view=category&id=' . $this->parentcat;
@$pid = JFactory::getApplication()->input->get('id', '0', 'int');
if (is_array($this->items) && !empty($this->items)) {
    @$fields = $_SESSION['search2'];
    ?>
    <script type="text/javascript">
        function order(column, dirn) {
            document.getElementById("filter_order").value = column;
            document.getElementById("filter_order_Dir").value = dirn;
            document.getElementById("adminForm").submit();
        }
    </script>
    <div id="search_left">
        <form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=category'); ?>" method="post"
              name="adminForm" id="adminForm">
            <div class="row-fluid pagn-order">
                <?php echo $this->pagination->getListFooter(); ?>
            </div>
            <div id="ordering" class="row-fluid">
                <a class="order" id="order_chip"
                   onclick="order('off','ASC')"><?php echo JText::_('COM_JSTAR_SHOP_CHIP'); ?></a>
                <a class="order" id="order_exp"
                   onclick="order('off','DESC')"><?php echo JText::_('COM_JSTAR_SHOP_EXP'); ?></a>
                <a class="order" id="order_pop"
                   onclick="order('view','DESC')"><?php echo JText::_('COM_JSTAR_SHOP_POP'); ?></a>
                <a class="order" id="order_sales"
                   onclick="order('sales','DESC')"><?php echo JText::_('COM_JSTAR_SHOP_SALES'); ?></a>
                <div class="clear"></div>
            </div>
            <div class="row-fluid">
                <?php foreach ($this->items as $i => $item) {
                    $link = JRoute::_('index.php?option=com_jstar_shop&view=product&id=' . $item->id);
                    ?>
                    <div id="product1" class="span4">
                        <div class="intro_product">
                            <?php if ($off = array_search($item->id, $this->Amazing)) {
                                $off = explode('-', $off)[1];
                                ?>
                                <div class="c-promotion__discount">
                                    <span><?php echo '%' . $off; ?></span>
                                </div>
                            <?php } ?>
                            <div id="product_img"><a style="display:block" href="<?php echo $link; ?>"><img
                                            src="<?php echo $item->img1; ?>"/></a></div>
                            <div id="product_title"><a href="<?php echo $link; ?>"><?php echo $item->title; ?></a></div>
                            <div id="product_price">
                                <?php if ($item->multicost == 1) {
                                    $Model = $this->getModel();
                                    $result = $Model->getMulticost($item->id);
                                    @$cost1 = $result->cost1;
                                    @$cost2 = $result->cost2;
                                    ?>
                                    <div class="c-price">
                                        <?php if ($off = array_search($item->id, $this->Amazing)) {
                                            $off = explode('-', $off)[1];
                                            ?>
                                            <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format(($cost2 - round($cost2 * ($off / 100))))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                                        <?php } else { ?>
                                            <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($cost2)) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                                        <?php } ?>
                                    </div>

                                <?php } else { ?>
                                    <div class="c-price">
                                        <?php if ($off = array_search($item->id, $this->Amazing)) {
                                            $off = explode('-', $off)[1];
                                            ?>
                                            <div class=""><?php echo @number_format($item->off - round($item->off * ($off / 100))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                                        <?php } else { ?>
                                            <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format(round($item->off))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                                <div id="add_comp1"><a
                                            onclick="add_compare(<?php echo $item->id; ?>)"><?php echo JText::_('COM_JSTAR_SHOP_ADD_COMPARE'); ?></a>
                                    <span id="status" class="span_status">
									<?php switch ($item->status) {
                                        case 0:
                                            echo '<span style="color:orangered;">' . JText::_('COM_JSTAR_SHOP_STATUS0') . '</span>';
                                            break;
                                        case 1:
                                            echo '<span style="color:green;">' . JText::_('COM_JSTAR_SHOP_STATUS1') . '</span>';
                                            break;
                                        case 2:
                                            echo '<span style="color:red;">' . JText::_('COM_JSTAR_SHOP_STATUS2') . '</span>';
                                            break;
                                        case 3:
                                            echo '<span style="color:purple;">' . JText::_('COM_JSTAR_SHOP_STATUS3') . '</span>';
                                            break;
                                        case 4:
                                            echo '<span style="color:black;">' . JText::_('COM_JSTAR_SHOP_STATUS4') . '</span>';
                                            break;
                                    }
                                    ?>
                				</span>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
            <?php
            if (!empty($fields)) {
                foreach ($fields as $field) { ?>
                    <input type="hidden" name="search[]" value="<?php echo $field; ?>"/>
                <?php }
            }
            ?>
            <input type="hidden" id="filter_order" name="filter_order" value=""/>
            <input type="hidden" id="filter_order_Dir" name="filter_order_Dir" value=""/>
        </form>
    </div>
    <?php
} else {
    echo '<div class="alert alert-no-items">' . JText::_('COM_JSTAR_SHOP_NO_PRODUCT') . '</div>';
} ?>
<div class="clear"></div>
</div>
