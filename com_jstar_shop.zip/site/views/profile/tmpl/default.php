<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$user = JFactory::getUser();
$userId = $user->id;
if (isset($userId) && $userId != '' && $userId != NULL) {
    $doc = JFactory::getDocument();
    $doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
    $doc->addStyleSheet('media/com_jstar_shop/css/profile.css');
    $doc->addScript('media/com_jstar_shop/js/cart.js');
    $link = JRoute::_('index.php?option=com_jstar_shop&task=profile.edit2', false);
    $Model = $this->getModel();
    $address = $Model->getUserinfo($userId);
    @$states = $Model->getState2();
    @$cits = $Model->getCits($address->state);
    ?>
    <form action="<?php echo $link ?>" method="post" enctype="multipart/form-data">
        <table class="plainrows">
            <tr>
                <td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_NAME_FAMILY') ?></td>
                <td class="td2"><input type="text" name="name_family" size="30"
                                       value="<?php echo @$this->item->name ?>"/></td>
            </tr>
            <tr>
                <td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_MOBILE') ?></td>
                <td class="td2"><input type="text" name="mobile" size="30" value="<?php echo @$this->item->mobile ?>"/>
                </td>
            </tr>

            <tr>
                <td class="td1">
                    <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_STATE'); ?></label>
                </td>
                <td class="td2">
                    <select name="state" id="state1" onchange="getSubcits()">
                        <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_STATE'); ?></option>
                        <?php foreach ($states as $cit) {
                            if ($address->state == $cit->id) {
                                $selected = 'selected="SELECTED"';
                            } else {
                                $selected = '';
                            }
                            ?>
                            <option <?php echo $selected; ?>
                                    value="<?php echo $cit->id; ?>"><?php echo $cit->city; ?></option>
                        <?php } ?>
                    </select>
                </td>
            </tr>

            <tr>
                <td class="td1">
                    <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_CITY'); ?></label>
                </td>
                <td class="td2">
                    <select name="city" id="city1">
                        <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_CITY'); ?></option>
                        <?php
                        foreach ($cits as $cit) {
                            if ($address->city == $cit->id) {
                                $selected = 'selected="SELECTED"';
                            } else {
                                $selected = '';
                            }
                            ?>
                            <option <?php echo $selected; ?>
                                    value="<?php echo $cit->id; ?>"><?php echo $cit->city; ?></option>
                        <?php } ?>

                    </select>
                </td>
            </tr>


            <tr>
                <td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_POSTAL_CODE') ?></td>
                <td class="td2"><input type="text" name="postal_code" size="30"
                                       value="<?php echo @$this->item->postal_code ?>"/></td>
            </tr>
            <tr>
                <td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_ADDRESS') ?></td>
                <td class="td2"><textarea name="address"><?php echo @$this->item->address; ?></textarea>
                </td>
            </tr>
            <tr>
                <td colspan="2"><input class="buttom btn-success" type="submit"
                                       value="<?php echo JText::_('COM_JSTAR_SHOP_SAVE') ?>"/>
                </td>
            </tr>
        </table>
        <?php echo JHtml::_('form.token'); ?>
    </form>
<?php } else {
    $app = JFactory::getApplication();
    $link = JURI::base() . 'index.php';
    $msg = JText::_('COM_JSTAR_SHOP_LOGOUT');
    $app->redirect($link, $msg);
} ?>


