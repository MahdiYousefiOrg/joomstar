<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/licencekey.css');
?>
<div class="licence">
<p><?php echo Jtext::_('COM_JSTAR_SHOP_HAVETO_ACTIVE'); ?></p>
<p>
	<a class="btn btn-success" target="_blank" href="https://www.joomstar.ir"><?php echo Jtext::_('COM_JSTAR_SHOP_CLICK_ACTIVE'); ?></a>
</p>
<div class="support row-fluid">
	<div class="span6">
        <a class="btn btn-primary tell" href="tel:+989356426227">09356426227</a>
    </div>
    <div class="span6">
        <a class="btn btn-primary tell" href="mailto:yousefi.data@gmail.com">yousefi.data@gmail.com</a>
    </div>
</div>
</div>