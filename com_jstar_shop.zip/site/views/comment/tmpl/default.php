<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$product_id = JFactory::getApplication()->input->get('pid');
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
JPluginHelper::importPlugin('captcha');
$dispatcher = JDispatcher::getInstance();
$dispatcher->trigger('onInit', 'dynamic_recaptcha_1');
$user = JFactory::getUser();
$user_id = $user->id;
?>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop'); ?>" method="post" enctype="multipart/form-data"
      name="adminForm" id="adminForm" class="form-validate form-vertical">
    <table id="comment_tabale">
        <?php
        foreach ($this->form->getFieldset() as $fieldset) { ?>
            <tr>
                <td class="formelm1">
                    <?php echo $fieldset->label ?>
                </td>
                <td class="formelm2">
                    <?php echo $fieldset->input ?>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <td id="dynamic_recaptcha_1"></td>
        </tr>
        <tr>
            <td colspan="2">
                <div class="btn">
                    <div class="">
                        <input style="border:none; background:none;" type="submit" name="send"
                               value="<?php if (isset($user_id) && $user_id != NULL) {
                                   echo JText::_('COM_JSTAR_SHOP_SEND');
                               } else {
                                   echo JText::_('COM_JSTAR_SHOP_REGISTER');
                               } ?>"/>
                    </div>
                </div>
            </td>
        </tr>
    </table>

    <?php if (isset($user_id) && $user_id != NULL) { ?>
        <input type="hidden" name="task" value="comment.save"/>
    <?php } else { ?>
        <input type="hidden" name="task" value="user.register"/>
    <?php } ?>
    <input type="hidden" name="jform[pid]" value="<?php echo $product_id; ?>"/>
    <?php echo JHtml::_('form.token'); ?>
</form>
