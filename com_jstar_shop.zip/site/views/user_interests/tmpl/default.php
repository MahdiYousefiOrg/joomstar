<?php
/**
 * @package    StarShop for Joomla!
 * @version    1.0.9
 * @author    joomstar.ir
 * @copyright    (C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license    GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/category.css');
$amazings = Jstar_shop_CHeckupHelper::getAmazings();
if (is_array($this->items) && !empty($this->items)) {
    ?>
    <div id="search_left" style="padding:20px">

        <form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=user_interests'); ?>" method="post"
              name="adminForm" id="adminForm" class="user_int">
            <div class="row-fluid pagn-order">
                <?php echo $this->pagination->getListFooter(); ?>
            </div>
            <div class="row-fluid">
                <?php foreach ($this->items as $i => $item) {
                    $link = JRoute::_('index.php?option=com_jstar_shop&view=product&id=' . $item->pid);
                    ?>
                    <div id="product1" class="span4">
                        <div class="intro_product">
                            <?php if ($off = array_search($item->pid, $amazings)) {
                                $off = explode('-', $off)[1];
                                ?>
                                <div class="c-promotion__discount">
                                    <span><?php echo '%' . $off; ?></span>
                                </div>
                            <?php } else {
                                $off = 0;
                            } ?>
                            <div id="product_img"><a style="display:block;padding-top: 15px;"
                                                     href="<?php echo $link; ?>"><img src="<?php echo $item->img1; ?>"/></a>
                            </div>
                            <div id="product_title"><a href="<?php echo $link; ?>"><?php echo $item->title; ?></a></div>
                            <div id="product_price">
                                <?php if ($item->multicost == 1) {
                                    $Model = $this->getModel();
                                    $result = $Model->getMulticost($item->pid);
                                    @$cost1 = $result->cost1;
                                    @$cost2 = $result->cost2;
                                    ?>
                                    <span class="c-price">
                        <span class=""><?php if ($item->status == 1) {
                                echo Jstar_shop_Fa_digits::fa_digits(@number_format($cost2 - round($cost2 * $off / 100))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN');
                            } ?></span>
                     </span>
                                <?php } else { ?>
                                    <span class="c-price">
                        <span class=""><?php if ($item->status == 1) {
                                echo @$item->off - round($item->off * $off / 100) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN');
                            } ?></span>
                     </span>
                                <?php } ?>
                                <span id="status" class="span_status">
			    <?php switch ($item->status) {
                    case 0:
                        echo '<span style="color:orangered;">' . JText::_('COM_JSTAR_SHOP_STATUS0') . '</span>';
                        break;
                    case 1:
                        echo '<span style="color:green;">' . JText::_('COM_JSTAR_SHOP_STATUS1') . '</span>';
                        break;
                    case 2:
                        echo '<span style="color:red;">' . JText::_('COM_JSTAR_SHOP_STATUS2') . '</span>';
                        break;
                    case 3:
                        echo '<span style="color:purple;">' . JText::_('COM_JSTAR_SHOP_STATUS3') . '</span>';
                        break;
                    case 4:
                        echo '<span style="color:black;">' . JText::_('COM_JSTAR_SHOP_STATUS4') . '</span>';
                        break;
                }
                ?>
			</span>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <input type="hidden" id="filter_order" name="filter_order" value=""/>
            <input type="hidden" id="filter_order_Dir" name="filter_order_Dir" value=""/>
        </form>
    </div>
    <?php
} else {
    echo '<div class="alert alert-no-items">' . JText::_('COM_JSTAR_SHOP_NO_PRODUCT') . '</div>';
} ?>
<div class="clear"></div>
</div>
