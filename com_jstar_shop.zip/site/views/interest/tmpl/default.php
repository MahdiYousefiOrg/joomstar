<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
$add = JFactory::getApplication()->input->get('add');
$userid = JFactory::getUser()->id;
$app = JFactory::getApplication();
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/interest.css');
$db = JFactory::getDbo();
if (isset($userid) && $userid != 0 && $add == 2) {
    $query = "DELETE FROM `#__jstar_shop_interests` WHERE `userid` = " . $db->quote($db->escape($userid)) . " AND `pid` = " . $db->quote($db->escape($pid));
    $db->setQuery($query);
    $db->execute();

    $js = "javascript:window.parent.location.href=window.parent.location;window.parent.SqueezeBox.close();";
    $doc->addScriptDeclaration($js);
}
if (!isset($userid) || $userid == 0) {
    JHtml::_('behavior.keepalive');
    JHtml::_('bootstrap.tooltip');
    $login = JFactory::getApplication()->input->get('login');
    if (isset($login)) {
        $data = $_POST;
        $credentials = array('username' => $data['username'], 'password' => $data['password']);
        if (true !== JFactory::getApplication()->login($credentials, $options = array())) {
            $data['username'] = '';
            $data['password'] = '';
            $app->redirect(JRoute::_('index.php?option=com_jstar_shop&view=interest&pid=' . $db->quote($db->escape($pid)) . '&tmpl=component&add=1', false));
        } else {
            // true login
            $userid = JFactory::getUser()->id;
            $query = "SELECT `id` FROM `#__jstar_shop_interests` WHERE `pid` = " . $db->quote($db->escape($pid)) . " AND `userid` = " . $db->quote($db->escape($userid));
            $db->setQuery($query);
            $check_interested = $db->LoadResult();
            if (!isset($check_interested) || $check_interested == NULL) {
                $date = JFactory::getDate()->Format('Y-m-d');
                $query = "INSERT INTO `#__jstar_shop_interests` (`id`, `userid`, `pid`, `date`) VALUES (NULL, " . $db->quote($db->escape($userid)) . ", " . $db->quote($db->escape($pid)) . ", " . $db->quote($db->escape($date)) . ")";
                $db->setQuery($query);
                $db->execute();
                $js = "javascript:window.parent.location.href=window.parent.location;window.parent.SqueezeBox.close();";
                $doc->addScriptDeclaration($js);
            } else { ?>
                <div class="login-forms"
                     style="margin: 25% 10%;color: #FFF;"><?php echo JText::_('COM_JSTAR_SHOP_ADDED_BEFOR'); ?></div>
            <?php }
        }
    } else {


        ?>
        <form action="" method="post" id="login-form" class="login-forms form-inline"
              style="color: #fff !important;width: 320px !important;min-width: 220px !important;max-width: 500px !important;height: 270px !important;min-height: 200px !important;max-height: 500px !important;margin: auto !important;position: absolute;top: 0 !important;left: 0 !important;right: 0 !important;bottom: 0 !important;text-align: center;">
            <div class="userdata">
                <div id="form-login-username" class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <input id="modlgn-username" type="text" name="username" class="input-small" tabindex="0"
                                   size="18" placeholder="<?php echo JText::_('COM_JSTAR_SHOP_VALUE_USERNAME'); ?>"/>
                        </div>
                    </div>
                </div>
                <div id="form-login-password" class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <input id="modlgn-passwd" type="password" name="password" class="input-small" tabindex="0"
                                   size="18" placeholder="<?php echo JText::_('JGLOBAL_PASSWORD'); ?>"/>
                        </div>
                    </div>
                </div>
                <?php if (JPluginHelper::isEnabled('system', 'remember')) : ?>
                    <div id="form-login-remember" class="control-group checkbox">
                        <label for="modlgn-remember"
                               class="control-label"><?php echo JText::_('COM_JSTAR_SHOP_REMEMBER_ME'); ?></label>
                        <input id="modlgn-remember" type="checkbox" name="remember" class="inputbox" value="yes"
                               size="float:none;"/>
                    </div>
                <?php endif; ?>
                <div id="form-login-submit" class="control-group">
                    <div class="controls">
                        <input type="submit" name="login" value="<?php echo JText::_('JLOGIN'); ?>" tabindex="0"
                               class="btn btn-primary login-button"/>
                    </div>
                </div>
                <?php
                $usersConfig = JComponentHelper::getParams('com_users'); ?>
                <ul class="unstyled">
                    <?php if ($usersConfig->get('allowUserRegistration')) : ?>
                        <li>
                            <a class="logina"
                               href="<?php echo JRoute::_('index.php?option=com_users&view=registration'); ?>">
                                <?php echo JText::_('COM_JSTAR_SHOP_LOGIN_REGISTER'); ?> <span class=""></span></a>
                        </li>
                    <?php endif; ?>
                    <li>
                        <a class="logina" href="<?php echo JRoute::_('index.php?option=com_users&view=remind'); ?>">
                            <?php echo JText::_('COM_JSTAR_SHOP_LOGIN_FORGOT_YOUR_USERNAME'); ?></a>
                    </li>
                    <li>
                        <a class="logina" href="<?php echo JRoute::_('index.php?option=com_users&view=reset'); ?>">
                            <?php echo JText::_('COM_JSTAR_SHOP_LOGIN_FORGOT_YOUR_PASSWORD'); ?></a>
                    </li>
                </ul>
                <?php echo JHtml::_('form.token'); ?>
            </div>
        </form>


        <?php
    }
} elseif (isset($userid) && $userid != 0 && $add == 1) { 
    // logined
    $userid = JFactory::getUser()->id;
    $query = "SELECT `id` FROM `#__jstar_shop_interests` WHERE `pid` = " . $db->quote($db->escape($pid)) . " AND `userid` = " . $db->quote($db->escape($userid));
    $db->setQuery($query);
    $check_interested = $db->LoadResult();
    if (!isset($check_interested) || $check_interested == NULL) {
        $date = JFactory::getDate()->Format('Y-m-d');
        $query = "INSERT INTO `#__jstar_shop_interests` (`id`, `userid`, `pid`, `date`) VALUES (NULL, " . $db->quote($db->escape($userid)) . ", " . $db->quote($db->escape($pid)) . ", " . $db->quote($db->escape($date)) . ")";
        $db->setQuery($query);
        $db->execute();
        $js = "javascript:window.parent.location.href=window.parent.location;window.parent.SqueezeBox.close();";
        $doc->addScriptDeclaration($js);
    } else { ?>
        <div><?php echo JText::_('COM_JSTAR_SHOP_ADDED_BEFOR'); ?></div>
    <?php }

}
?>
