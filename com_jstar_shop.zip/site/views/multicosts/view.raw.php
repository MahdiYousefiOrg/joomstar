<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopViewMulticosts extends JViewLegacy
{
	public function display($tpl = null)
	{
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int'); 
		$fieldid = JFactory::getApplication()->input->get('fieldid', '', 'string');
		$_SESSION['multicost'][$pid] = $fieldid;
		$db = JFactory::getDBO();
		$query = "SELECT * FROM `#__jstar_shop_multicosts` WHERE `id` = ".$db->quote($db->escape($fieldid))." AND `pid` = ".$db->quote($db->escape($pid));
		$db->setQuery( $query );
		$rows = $db->LoadObject();
		echo '{items:'.json_encode($rows).'}';
	}

}
