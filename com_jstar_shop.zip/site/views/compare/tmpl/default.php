<?php
/**
 * @package    StarShop for Joomla!
 * @version    1.0.9
 * @author    joomstar.ir
 * @copyright    (C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license    GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
JHtml::_('behavior.modal');
$session = JFactory::getSession();
$db = JFactory::getDBO();
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/compare.css');
if (isset($this->items) && !empty($this->items)) {
    $config = JComponentHelper::getParams('com_jstar_shop');
    //$mony = $config->get('mony');
    $amazings = Jstar_shop_CHeckupHelper::getAmazings();
    ?>
    <table cellpadding="2" cellspacing="2" id="product_compare">
        <tr>
            <td class="comptitle"><?php echo JText::_('COM_JSTAR_SHOP_COMPARE'); ?></td>
            <?php $k = 1;
            foreach ($this->items as $item) {
                $pids[] = $item->id;
                ?>
                <td class="ptitle"><?php echo $item->title; ?></td>
                <?php $k++;
            } ?>
        </tr>
        <tr>
            <td class="pricetitle">
                <?php echo JText::_('COM_JSTAR_SHOP_PRICE'); ?>
            </td>
            <?php foreach ($this->items as $item) {
                if ($off = array_search($item->id, $amazings)) {
                    $off = explode('-', $off)[1];
                } else {
                    $off = 0;
                } ?>
                <td>
                    <?php
                    if ($item->multicost == 1) {
                        $Model = $this->getModel();
                        $result = $Model->getCost($item->id);
                        if ($result->cost2 != -1) {
                            @$cost1 = $result->cost1;
                            @$cost2 = $result->cost2;
                            //@$off = $cost1 - $cost2;
                        } else {
                            @$cost2 = $item->off;
                            @$cost1 = $item->price;
                            //@$off = $item->price - $item->off;
                            $fieldid = NULL;
                        }
                        ?>
                        <div class="c-price2">
                            <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format(@$cost2-($cost2*$off/100))); ?></div>
                            <del><?php
                                if (isset($cost1) && $cost1 != 0) {
                                    echo Jstar_shop_Fa_digits::fa_digits(@number_format(@$cost1));
                                }
                                ?></del>
                        </div>
                    <?php } else { ?>
                        <div class="c-price">
                            <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($item->off-($item->off*$off/100))); ?></div>
                            <del><?php
                                if (isset($item->price) && $item->price != 0) {
                                    echo Jstar_shop_Fa_digits::fa_digits(@number_format($item->price));
                                }
                                ?></del>
                        </div>
                    <?php } ?>
                </td>
            <?php } ?>
        </tr>
        <?php $j = 0;
        foreach ($this->fields as $field) {

            if ($j == 0) { ?>
                <tr>
                    <td class="comptitle2" colspan="<?php echo $k; ?>"><?php echo $field->group2; ?></td>
                </tr>
            <?php } elseif ($this->fields[$j - 1]->group2 != $this->fields[$j]->group2) { ?>
                <tr>
                    <td class="comptitle2" colspan="<?php echo $k; ?>"><?php echo $field->group2; ?></td>
                </tr>
            <?php }
            $j++; ?>
            <tr>
                <td class="ftitle"><?php echo $field->title; ?></td>

                <?php $i = 0;
                foreach ($this->items as $item) {
                    $db = JFactory::getDbo();
                    $query = "SELECT `b`.*,`c`.`title`,`c`.`type` AS `typefield` FROM `#__jstar_shop_feilds_products` AS `b` LEFT JOIN `#__jstar_shop_customfields` AS `c` ON `b`.`field_id` = `c`.`id`  WHERE `b`.`field_id` = " . $db->quote($db->escape($field->id)) . " AND `b`.`product_id` = " . $db->quote($db->escape($item->id)) . " ORDER BY `b`.`product_id` ASC";
                    $db->setQuery($query);
                    $rows = $db->LoadObjectList();
                    if (trim(@$rows[$i]->values) != '' && @$rows[$i]->values != NULL) {
                        if (@$rows[$i]->typefield == 5) {
                            $colors_arr = explode(',', $rows[$i]->values);
                            echo '<td>';
                            foreach ($colors_arr as $list) {
                                if ($list != '') { ?>
                                    <div class="check color" style="background:<?php echo $list; ?>"></div>
                                <?php }
                            }
                            echo '</td>';
                        } else {
                            ?>
                            <td>
                                <?php echo @$rows[$i]->values; ?>
                            </td>

                            <?php
                        }
                    } else { ?>
                        <td>
                            -
                        </td>

                    <?php }

                } ?>
            </tr>
            <?php $i++;
        } ?>
    </table>
    <?php foreach ($pids as $unset) {
        unset($_SESSION['compare'][$unset]);
    }
} else echo '<div class="alert alert-no-items">' . JText::_('COM_JSTAR_SHOP_NO_PRODUCT') . '</div>'; ?>
