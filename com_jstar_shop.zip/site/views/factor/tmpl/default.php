<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
?>
    <script type="text/javascript">
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        function addpricepost(str2){
            var str=document.getElementById('total_price').value;
            var sum = parseInt(str) + parseInt(str2);
            document.getElementById("total_price2").innerHTML=(numberWithCommas(sum))+'<?php echo JText::_('COM_JSTAR_SHOP_TOMAN'); ?>';
        }

        function removepricepost(){
            var str=document.getElementById('total_price').value;
            document.getElementById("total_price2").innerHTML=(numberWithCommas(str))+'<?php echo JText::_('COM_JSTAR_SHOP_TOMAN'); ?>';
        }

    </script>
<?php
$db = JFactory::getDBO();
$user = JFactory::getUser();
$userid = $user->id;
if (isset($userid) && $userid != 0) {
    $Model = $this->getModel();
    $params = JComponentHelper::getParams('com_jstar_shop');
    $steppay = $params->get('steppay');
    @$name = JFactory::getApplication()->input->post->get('name_family','','string');
    @$mobile = JFactory::getApplication()->input->get('mobile','','string');
    @$state = JFactory::getApplication()->input->get('state','','string');
    @$city = JFactory::getApplication()->input->get('city','','string');
    @$address = JFactory::getApplication()->input->get('address','','string');
    @$postal_code = JFactory::getApplication()->input->get('postal_code','','string');
    if (!isset($name) || !isset($mobile) || !isset($state) || !isset($city) || !isset($address)) {
        $app = JFactory::getApplication();
        $link = JRoute::_('index.php?option=com_jstar_shop&view=cart', false);
        $app->redirect($link);
    }
    @$coupon = JFactory::getApplication()->input->get('coupon');
    $doc = JFactory::getDocument();
    $doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
    if (empty($this->items)) { ?>
        <div class="alert alert-no-items">
            <?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
        </div>
    <?php } else {
        $sum_count = 0;
        $sum_weight = 0;
        $pay_type = 0;
        $link = JRoute::_('index.php?option=com_jstar_shop&task=payment.setbank'); ?>
        <form class="form-validate form-horizontal well" action="<?php echo $link; ?>" method="post"
              enctype="multipart/form-data">
            <table cellpadding="2" cellspacing="2" id="table_cart">
                <tr>
                    <th><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
                    <th><?php echo JText::_('COM_JSTAR_SHOP_PRICE_UNIT'); ?></th>
                    <th><?php echo JText::_('COM_JSTAR_SHOP_COUNT'); ?></th>
                    <th><?php echo JText::_('COM_JSTAR_SHOP_PAY_PRICE'); ?></th>
                </tr>
                <?php
                if (!empty($this->items)) {
                    $amazings = Jstar_shop_CHeckupHelper::getAmazings();
                    foreach ($this->items as $i => $item) :
                        if($item->store_id != 0){
                            $pay_type = 1;
                        }
                        $gid = JFactory::getApplication()->input->get('gid_' . $item->id, null, 'array');
                        $_SESSION['gid_' . $item->id] = $gid;
                        $gid = @implode(',', $gid);

                        if (!empty($gid)) {
                            $giftsid = $Model->getGifts($gid, $item->id);
                            $gift_price = @array_sum($giftsid);
                        } else {
                            $gift_price = 0;
                        }
                        $count = JFactory::getApplication()->input->get('count_buy_' . $item->id);
                        $sum_count = $sum_count+$count;

                        $sum_weight+=$sum_count*$item->w;



                        $result = $Model->getCost($item->id);
                        if ($off_amazing = array_search($item->id, $amazings)) {
                            $off_amazing = explode('-', $off_amazing)[1];
                        } else {
                            $off_amazing = 0;
                        }
                        if ($result->cost2 != -1) {
                            $cost1 = $result->cost1;
                            $cost2 = $result->cost2;
                            $price_main = $cost2;
                            if($off_amazing == 0) {
                                $off = $cost1 - $cost2;
                            } else {
                                $off = round(($cost2*$off_amazing/100))+($cost1 - $cost2);
                            }
                            $price_show = $cost1;
                            $payable = ($cost1-$off);
                        } else {
                            $cost2 = 0;
                            $cost1 = 0;
                            if($off_amazing == 0) {
                                @$off = $item->price - $item->off;
                            } else {
                                $off =  round(($item->off*$off_amazing/100))+($item->price - $item->off);
                            }
                            $price_main = $item->off;
                            $price_show = $item->price;
                            $payable = ($item->price-$off);
                            $fieldid = NULL;
                        }
                        $prices[] = $count * ($payable) + $count * ($gift_price) - $count * ($payable * $this->coupon / 100) - $count * ($payable * $this->usercoupon / 100);//+($count*$costPost);
                        ?>
                        <tr>
                            <td><?php echo $item->title; ?></td>
                            <td>
                                <ul>
                                    <li>
                                        <?php echo JText::_('COM_JSTAR_SHOP_COST1') . ' : ' . Jstar_shop_Fa_digits::fa_digits(@number_format($price_show)); ?>
                                    </li>
                                    <?php if (!empty($gid)) { ?>
                                        <li>
                                            <?php echo JText::_('COM_JSTAR_SHOP_GIFT') . ' : ' . Jstar_shop_Fa_digits::fa_digits(@number_format($gift_price)); ?>
                                        </li>
                                    <?php } ?>
                                    <li>
                                        <?php echo JText::_('COM_JSTAR_SHOP_OFF') . ':' . Jstar_shop_Fa_digits::fa_digits(@number_format($off)); ?>
                                    </li>
                                    <?php if (isset($this->coupon) && isset($this->coupon) != 0 && isset($this->coupon) != NULL) { ?>
                                        <li>
                                            <?php echo JText::_('COM_JSTAR_SHOP_DISCOUNT_CODE') . ':' . $this->coupon . JText::_('COM_JSTAR_SHOP_PERCENT'); ?>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($this->usercoupon) && isset($this->usercoupon) != 0 && isset($this->usercoupon) != NULL) { ?>
                                        <li>
                                            <?php echo JText::_('COM_JSTAR_SHOP_DISCOUNT_USER') . ':' . $this->usercoupon . JText::_('COM_JSTAR_SHOP_PERCENT'); ?>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </td>
                            <td><?php echo Jstar_shop_Fa_digits::fa_digits($count); ?></td>
                            <td>
                                <?php
                                echo Jstar_shop_Fa_digits::fa_digits(@number_format($count * ($payable) + $count * ($gift_price) - $count * ($payable * ($this->coupon / 100)) - $count * ($payable * ($this->usercoupon / 100))));//+($count*$costPost)));
                                ?>
                            </td>
                        </tr>
                        <input type="hidden" name="count_buy_<?php echo $item->id; ?>" value="<?php echo $count; ?>"/>
                    <?php endforeach;
                }


                @$total_price = @array_sum($prices); ?>
                <?php
                $_SESSION['add_name'] = $name;
                $_SESSION['add_mobile'] = $mobile;
                $_SESSION['add_state'] = $state;
                $_SESSION['add_city'] = $city;
                $_SESSION['add_address'] = $address;
                $_SESSION['add_postal_code'] = $postal_code;
                ?>

                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="coupon" value="<?php echo $coupon; ?>"/>
                <tr>
                    <td colspan="3"><?php echo JText::_('COM_JSTAR_SHOP_TYPE_POST'); ?></td>
                    <td style="text-align:left;">
                        <?php
                        $userCit = $city;
                        $query = "SELECT `b`.`amount`, `b`.`title`, `b`.`type_post`, `b`.`id` FROM `#__jstar_shop_posts` AS `b` LEFT JOIN `#__jstar_shop_cits` AS `c` ON find_in_set(`c`.`id`,`b`.`cits`) WHERE `b`.`w1` <= '$sum_weight' AND `b`.`w2` >= '$sum_weight' AND find_in_set(" . $db->quote($db->escape($userCit)) . ",`b`.`cits`) GROUP BY `b`.`id`";
                        $db->SetQuery($query);
                        $type_posts = $db->LoadObjectList();
                        ?>
                        <ul>
                            <li>
                                <input checked="checked" type="radio" name="typePost"
                                       onclick="removepricepost()"
                                       value="0"/> <?php echo JText::_('COM_JSTAR_SHOP_IN_STORE'); ?>
                            </li>
                            <?php foreach ($type_posts as $type_post) { ?>
                                <li>
                                    <input type="radio" name="typePost"
                                           onclick="addpricepost(<?php echo $type_post->amount; ?>)"
                                           value="<?php echo $type_post->id; ?>"/> <?php echo $type_post->type_post . ' - ' . Jstar_shop_Fa_digits::fa_digits(@number_format($type_post->amount)) . JText::_('COM_JSTAR_SHOP_TOMAN'); ?>
                                </li>

                            <?php } ?>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <input type="hidden" value="<?php echo $total_price; ?>" id="total_price" />
                    <td colspan="3"><?php echo JText::_('COM_JSTAR_SHOP_TOTAL_PRICE'); ?></td>
                    <td id="total_price2">
                        <?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($total_price)) . ' ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?>
                    </td>
                </tr>
                <tr>

                    <td colspan="5">
                        <select name="payment">
                            <?php if ($steppay == 1) { ?>
                                <option value="nobank"><?php echo JText::_('COM_JSTAR_SHOP_ORDER_NOBANK'); ?></option>
                            <?php }
                            if($pay_type == 0){
                                foreach ($this->bank as $bank) { ?>
                                    <option value="<?php echo $bank->element; ?>"><?php echo $bank->name; ?></option>
                                <?php }
                            }?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="5">
                        <button class="btn btn-primary"
                                type="submit"><?php echo JText::_('COM_JSTAR_SHOP_END_BUY'); ?></button>
                    </td>
                </tr>
            </table>
        </form>
    <?php }
} else {
    $app = JFactory::getApplication();
    $link = JRoute::_('index.php?option=com_jstar_shop', false);
    $app->redirect($link, JText::_('COM_JSTAR_SHOP_U_LOG_OUT'));
}
?>