<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopViewProduct extends JViewLegacy
{
	protected $item;
	protected $fields;
	protected $values;
	protected $comments;
	public function display($tpl = null)
	{ 
		$this->item         = $this->get('Item'); 
		$this->fields		= Jstar_shop_CHeckupHelper::getFields2();
		$this->fieldsmulti		= Jstar_shop_CHeckupHelper::getFieldsmulti();
		$this->values		= Jstar_shop_CHeckupHelper::getValues2();
		$this->comments		= $this->get('comments');
		// Check for errors.
		if (@count($errors = $this->get('Errors')))
		{
			JFactory::getApplication()->enqueueMessage(implode("\n", $errors), 'error');

			return false;
		}
		parent::display($tpl);
	}
}
