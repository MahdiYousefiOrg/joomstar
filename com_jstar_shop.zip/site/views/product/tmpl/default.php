<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$userid = JFactory::getUser()->id;
if(isset($userid) && $userid != 0){ ?>
    <style>
    #sbox-window, #sbox-content{
        display:none !important;
    }
    </style>
<?php }
$Model = $this->getModel();
JHtml::_('behavior.modal');
jimport('joomla.application.module.helper');
$product_id = JFactory::getApplication()->input->get('id');
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/product.css');
$doc->addStyleSheet('media/com_jstar_shop/css/example.css');
$doc->addStyleSheet('media/com_jstar_shop/css/easyzoom.css');
$doc->addScript('media/com_jstar_shop/js/product.js');
$params = JComponentHelper::getParams('com_jstar_shop');
$amazings = Jstar_shop_CHeckupHelper::getAmazings();
if ($off = array_search($product_id, $amazings)) {
    $off = explode('-', $off)[1];
} else {
    $off = 0;
}
if (isset($this->item->metakey) && $this->item->metakey != NULL && $this->item->metakey != '') {
    $doc->setMetaData('keywords', $this->item->metakey, true);
}
if (isset($this->item->metadesc) && $this->item->metadesc != NULL && $this->item->metadesc != '') {
    $doc->setMetaData('discription', $this->item->metadesc, true);
}
$params = JComponentHelper::getParams('com_jstar_shop');
$images = array(0 => $this->item->img1, 1 => $this->item->img2, 2 => $this->item->img3, 3 => $this->item->img4);
$images = array_filter($images);
$amazings = Jstar_shop_CHeckupHelper::getAmazings();

?>
<!--[if IE]>
<style>
    .easyzoom img {
        max-height: 400px;
    }
</style>
<![endif]-->
<div id="pro_bac">
    <div id="product" class="row-fluid container">
        <div class="span6" id="screen-width">
            <?php if ($off = array_search($product_id, $amazings)) {
                $off = explode('-', $off)[1];
                ?>
                <div class="c-promotion__discount">
                    <span><?php echo '%' . $off; ?></span>
                </div>
            <?php } else {
                $off = 0;
            } ?>
            <div class="easyzoom easyzoom--overlay easyzoom--with-thumbnails">
                <a href="<?php echo JURi::root() . $this->item->img1; ?>">
                    <img src="<?php echo JURi::root() . $this->item->img1; ?>" alt="" width="400" height="300"/>
                </a>
            </div>

            <ul class="thumbnails">
                <?php foreach ($images as $img) { ?>
                    <li>
                        <a href="<?php echo JURi::root() . $img; ?>" data-standard="<?php echo JURi::root() . $img; ?>">
                            <img src="<?php echo JURi::root() . $img; ?>" alt=""/>
                        </a>
                    </li>
                <?php } ?>
            </ul>

        </div>
        <div id="screen-mini">
            <?php if ($off = array_search($product_id, $amazings)) {
                $off = explode('-', $off)[1];
                ?>
                <div class="c-promotion__discount">
                    <span><?php echo '%' . $off; ?></span>
                </div>
            <?php } else {
                $off = 0;
            } ?>
        	<img src="<?php echo JURi::root() . $this->item->img1; ?>" alt="" />
        </div>

        <div id="main_product" class="span6">
            <div id="title_product"><?php echo $this->item->title; ?></div>
            <div>
                <?php if (isset($this->fieldsmulti) && $this->fieldsmulti != NULL) {
                    $multicost = $Model->checkMulticost($product_id);
                    if ($multicost == 1) {
                        $rows = $Model->getMulticost($product_id);
                        foreach ($rows as $row) { ?>
                            <div class="multicost2" id="multicost<?php echo $row->id; ?>"
                                 onclick="setPrice(<?php echo $row->id . ',' . $product_id .',' . $off ?>)"><?php echo $row->values; ?></div>
                        <?php }
                    }
                }  // if fields
                ?>
                <div class="clear"></div>
            </div>
            <div id="product_price">


                <?php $interest = $Model->checkinterest($this->item->id);
                if (!isset($interest) || trim($interest) == '' || $interest == 0 || $interest == NULL) { ?>
                    <span id="interest"><a class="favorite_imgs_page modal"
                                           rel="{handler: 'iframe', size: {x: 460, y: 350}}"
                                           href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=interest&pid=' . $this->item->id . '&tmpl=component&add=1'); ?>"
                                           title="<?php echo JText::_('COM_JSTAR_SHOP_INTERESTED'); ?>"></a></span>
                <?php } else { ?>
                    <span id="interest"><a class="favorited_imgs_page modal"
                                           rel="{handler: 'iframe', size: {x: 460, y: 350}}"
                                           href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=interest&pid=' . $this->item->id . '&tmpl=component&add=2'); ?>"
                                           title="<?php echo JText::_('COM_JSTAR_SHOP_INTERESTED'); ?>"></a></span>
                <?php } ?>
                <?php if ($this->item->multicost == 1) {
                    $result = $Model->getCost($product_id);
                    @$cost1 = $result->cost1;
                    @$cost2 = $result->cost2;
                    ?>
                    <div class="c-price2">
                        <div class=""
                             id="price_product2"><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($cost2-round($cost2*($off/100)))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                        <del id="price_product"><?php if (isset($cost1) && $cost1 != 0) {
                                echo Jstar_shop_Fa_digits::fa_digits(@number_format($cost1));
                            } ?></del>
                    </div>
                <?php } else { ?>
                    <div class="c-price2">
                        <div class=""
                             id="price_product2"><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($this->item->off-round($this->item->off*($off/100)))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                        <del id="price_product"><?php if (isset($item->price) && $item->price != 0) {
                                echo Jstar_shop_Fa_digits::fa_digits(@number_format($this->item->price));
                            } ?></del>
                    </div>
                <?php } ?>
                <span class="add_compare7"><a class="compare_imgs_page span_add_comp1a" title="<?php echo JText::_('COM_JSTAR_SHOP_COMPARE'); ?>"
                                              onclick="add_compare(<?php echo $this->item->id; ?>)"></a></span>
                <div class="clear"></div>
            </div>


            <div>

                <?php if (isset($this->fields) && $this->fields != NULL) {
                    $i = 0;
                    ?>
                    <ul class="main_f_u">
                        <?php
                        foreach ($this->fields as $field) {
                            if ($field->main == 1) { ?>
                                <?php if ($field->type == 5) {
                                    $colors = $Model->getColors($product_id, $field->id);
                                    $check = explode(',', @$colors);
                                    foreach ($check as $list) {
                                        if ($list != '') { ?>
                                            <div class="check color" style="background:<?php echo $list; ?>"></div>
                                        <?php }
                                    } ?>
                                    <div class="clear"></div>
                                <?php } else {
                                    $result = $Model->getMainValue($product_id, $field->id); ?>
                                    <li class="main_field3"><?php echo $field->title . ' : ' . $result; ?></li>
                                <?php } ?>
                            <?php } // if main field
                        } // foreach ?>
                    </ul>
                <?php }  // if fields
                ?>
            </div>
            <div id="add_bag"><a class="add_bag" target="_blank"
                                 href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=cart&pid=' . $product_id); ?>"><?php echo JText::_('COM_JSTAR_SHOP_ADD_CART'); ?></a>
            </div>

            <div id="store-info-service">
                <span id="store-original" class="span6"
                      style="padding: 5px 0;"><?php echo JText::_('COM_JSTAR_SHOP_PRODUCT_TEXT1'); ?></span>
                <span id="store-24-7" class="span6"
                      style="padding: 5px 0;"><?php echo JText::_('COM_JSTAR_SHOP_PRODUCT_TEXT2'); ?></span>
                <span id="store-free-returns" class="span6"
                      style="padding: 5px 0;"><?php echo JText::_('COM_JSTAR_SHOP_PRODUCT_TEXT3'); ?></span>
                <span id="store-free-shipping" class="span6"
                      style="padding: 5px 0;"><?php echo JText::_('COM_JSTAR_SHOP_PRODUCT_TEXT4'); ?></span>
            </div>

        </div>
        <div class="clear"></div>
    </div>
</div>
</div>
<div id="product_tag">
    <?php
    $module = JModuleHelper::getModule('mod_jstar_shop_tag');
    echo JModuleHelper::renderModule($module); ?>
</div>
<div id="tabs7">
    <?php
    $comment = JFactory::getApplication()->input->get('comment');
    if ($comment == '1') {
        $options = array(
            'useCookie' => true,
            'active' => 'tabs_3'
        );
    } else {
        $options = array(
            'useCookie' => true,
            'active' => 'tabs_1'
        );
    }
    echo JHtml::_('bootstrap.startTabSet', 'tab_group_id', $options);
    if (isset($this->fields) && $this->fields != NULL) {
        echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_1', JText::_('COM_JSTAR_SHOP_PRODUCT_TAB1')); ?>
        <table id="table1" cellpadding="2" cellspacing="2">

            <?php
            $i = 0;
            foreach ($this->fields as $field) {
                if ($i == 0) { ?>
                    <tr>
                        <td colspan="2"><?php echo $field->group2; ?></td>
                    </tr>
                <?php } elseif ($this->fields[$i - 1]->group2 != $this->fields[$i]->group2) { ?>
                    <tr>
                        <td colspan="2"><?php echo $field->group2; ?></td>
                    </tr>
                <?php }
                if ($field->fields == 1) {
                    ?>
                    <tr>
                    <td id="field_title"><?php echo $field->title; ?></td>
                    <?php if ($field->id == @$this->values[$i]->field_id) {
                        @$value = @$this->values[$i]->values;
                    }
                    if ($field->type != 4 && $field->type != 5) { ?>
                        <td id="field_value"><?php echo @$value; ?></td>
                    <?php }
                    if ($field->type == 4) { ?>
                        <td id="field_value">
                            <?php $values = explode('-', $field->value);
                            $check = explode(',', @$value);
                            foreach ($values as $list) {
                                if (in_array($list, $check)) { ?>
                                    <div class="check"> <?php echo $list; ?></div><?php } ?>
                            <?php } ?>
                        </td>
                        </tr>
                    <?php }
                    if ($field->type == 5) { ?>
                        <td id="field_value">
                            <?php
                            $check = explode(',', @$value);
                            foreach ($check as $list) {
                                if ($list != '') { ?>
                                    <div class="check color" style="background:<?php echo $list; ?>"></div>
                                <?php }
                            }
                            ?>
                        </td>
                        </tr>
                    <?php }
                }// if fields =1

                $i++;
            } //foreach
            ?>
        </table>
        <?php
        echo JHtml::_('bootstrap.endTab');
    } // end if 2
    if (isset($this->item->text2) && $this->item->text2 != NULL) {
        // Tab 2
        echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_2', JText::_('COM_JSTAR_SHOP_PRODUCT_TAB2'));
        echo $this->item->text2; ?>
        <?php echo JHtml::_('bootstrap.endTab');
    }
    // Tab3
    echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_3', JText::_('COM_JSTAR_SHOP_PRODUCT_TAB3'));
    $link = JRoute::_('index.php?option=com_jstar_shop&view=comment&pid=' . $product_id); ?>
    <div>
        <div id="comment_txt"><?php echo JText::_('COM_JSTAR_SHOP_YOU_CAN_COMMENT'); ?></div>
        <div id="buttom"><a href="<?php echo $link; ?>"><?php echo JText::_('COM_JSTAR_SHOP_ADD_COMMENT'); ?></a></div>
        <div class="clear"></div>
    </div>
    <div id="comments">
        <table id="comments2">
            <?php foreach ($this->comments as $comment2) { ?>
                <tr id="row_comment">
                    <td>
                        <p id="name_comment"><?php echo $comment2->name . ' ( ' . JHtml::date($comment2->date2, 'DATE_FORMAT_LC') . ' ) '; ?>
                            : </p>
                        <p><?php echo $comment2->comment; ?></p>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <?php
    echo JHtml::_('bootstrap.endTab');

    // End Tabs
    echo JHtml::_('bootstrap.endTabSet'); ?>
</div>

</div>
<div id="product_tag">
    <?php
    $module = JModuleHelper::getModule('mod_jstar_shop_similars');
    echo JModuleHelper::renderModule($module); ?>
</div>
<script src="<?php echo JURi::root(); ?>media/com_jstar_shop/js/jquery.js"></script>
<script src="<?php echo JURi::root(); ?>media/com_jstar_shop/js/easyzoom.js"></script>
<script src="<?php echo JURi::root(); ?>media/com_jstar_shop/js/easyzoom2.js"></script>


