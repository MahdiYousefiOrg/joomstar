<?php
/**
 * @package    StarShop for Joomla!
 * @version    1.0.9
 * @author    joomstar.ir
 * @copyright    (C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license    GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
JHtml::_('behavior.modal');
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/cart.css');
$doc->addScript('media/com_jstar_shop/js/cart.js');
$Model = $this->getModel();
if (empty($this->items)) : ?>
    <div class="alert alert-no-items">
        <?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
    </div>
<?php else :
    $user = JFactory::getUser();
    $userid = $user->id;
    if (!empty($this->items)) {
        foreach ($this->items as $i => $item) {
            $giftsid0[] = $Model->getGifts($item->id);
        }
        $giftsid0 = array_filter($giftsid0);
    }
    if (isset($userid) && $userid != 0) {
        $link = JRoute::_('index.php?option=com_jstar_shop&view=factor', false);
    } else {
        $link = '';
        $link2 = JRoute::_('index.php?option=com_jstar_shop&task=user.register', false);
        $link3 = JRoute::_('index.php?option=com_jstar_shop&task=user.login', false);
    }
    ?>
    <form class="form-validate form-horizontal well" action="<?php echo $link; ?>" method="post">
        <table cellpadding="2" cellspacing="2" id="table_cart">
            <tr>
                <th><?php echo JText::_('COM_JSTAR_SHOP_IMG'); ?></th>
                <th><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
                <th><?php echo JText::_('COM_JSTAR_SHOP_COUNT'); ?></th>
                <th><?php echo JText::_('COM_JSTAR_SHOP_PRICE_UNIT'); ?></th>
                <?php if (!empty($giftsid0)) { ?>
                    <th><?php echo JText::_('COM_JSTAR_GIFTS'); ?></th>
                <?php } ?>

                <th><?php echo JText::_('COM_JSTAR_SHOP_DELETE'); ?></th>
            </tr>
            <?php
            if (!empty($this->items)) {
                $amazings = Jstar_shop_CHeckupHelper::getAmazings();
                foreach ($this->items as $i => $item) :
                    $result = $Model->getCost($item->id);
                    if ($off_amazing = array_search($item->id, $amazings)) {
                        $off_amazing = explode('-', $off_amazing)[1];
                    } else {
                        $off_amazing = 0;
                    }
                    if ($result->cost2 != -1) {
                        $cost1 = $result->cost1;
                        $cost2 = $result->cost2;
                        if($off_amazing == 0) {
                            $off = $cost1 - $cost2;
                        } else {
                            $off = round(($cost2*$off_amazing/100))+($cost1 - $cost2);
                        }
                    } else {
                        $cost2 = 0;
                        $cost1 = 0;
                        if($off_amazing == 0) {
                            @$off = $item->price - $item->off;
                        } else {
                            $off =  round(($item->off*$off_amazing/100))+($item->price - $item->off);
                        }
                        $fieldid = NULL;
                    }
                    $giftsid = $Model->checkGifts($item->id);

                    $img = basename($item->img1);

                    ?>


                    <tr>
                        <td><img src="<?php echo $item->img1; ?>"/></td>
                        <td><?php echo $item->title; ?></td>
                        <td><input id="count_<?php echo $item->id; ?>" type="text"
                                   name="count_buy_<?php echo $item->id; ?>" value="1" class="count_cart"/></td>
                        <td id="price_<?php echo $item->id; ?>">
                            <ul>
                                <?php if ($cost2 != 0) { ?>
                                    <li><?php echo JText::_('COM_JSTAR_SHOP_COST2') . ':' . Jstar_shop_Fa_digits::fa_digits(@number_format($cost1)); ?></li>
                                        <li><?php echo JText::_('COM_JSTAR_SHOP_OFF') . ':' . Jstar_shop_Fa_digits::fa_digits(@number_format($off)); ?></li>
                                    <li class="pay_amount"><?php echo JText::_('COM_JSTAR_SHOP_PAY') . Jstar_shop_Fa_digits::fa_digits(@number_format(($cost1 - @$off))); ?></li>
                                <?php } else { ?>
                                    <li><?php echo JText::_('COM_JSTAR_SHOP_COST2') . ':' . Jstar_shop_Fa_digits::fa_digits(@number_format($item->price)); ?></li>
                                        <li><?php echo JText::_('COM_JSTAR_SHOP_OFF') . ':' . Jstar_shop_Fa_digits::fa_digits(@number_format($off)); ?></li>
                                    <li class="pay_amount"><?php echo JText::_('COM_JSTAR_SHOP_PAY') . Jstar_shop_Fa_digits::fa_digits(@number_format(($item->price - @$off))); ?></li>
                                <?php } ?>
                            </ul>
                        </td>
                        <?php if (!empty($giftsid0)) {
                            $colspan = 3; ?>
                            <td class="center">
                                <?php if (!empty($giftsid)) { ?>
                                    <table>
                                        <tr>
                                            <th><?php echo JText::_('COM_JSTAR_SHOP_SELECT'); ?></th>
                                            <th><?php echo JText::_('COM_JSTAR_SHOP_IMG'); ?></th>
                                            <th><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
                                            <th><?php echo JText::_('COM_JSTAR_SHOP_PRICE'); ?></th>
                                        </tr>
                                        <?php foreach ($giftsid as $gift) { ?>
                                            <tr>
                                                <td><input id="cb<?php echo $i; ?>"
                                                           name="gid_<?php echo $item->id; ?>[]"
                                                           value="<?php echo $gift->id; ?>" type="checkbox"></td>
                                                <td><img class="thumnails" src="<?php echo $gift->img; ?>"/></td>
                                                <td><?php echo $gift->title; ?></td>
                                                <td><?php echo $gift->price; ?></td>
                                            </tr>
                                        <?php } ?>
                                    </table>
                                <?php } ?>
                            </td>
                        <?php } else {
                            $colspan = 2;
                        } ?>


                        <td><a id="cart_remove2"
                               href="index.php?option=com_jstar_shop&task=cart.unset_product&pid_remove=<?php echo $item->id; ?>"></a></a>
                        </td>
                    </tr>
                <?php endforeach;
            } ?>
            <?php if (!empty($this->datecoupon)) { ?>
                <tr>
                    <td colspan="3">
                        <?php echo JText::_('COM_JSTAR_SHOP_COUPON_TAKHFIF'); ?>
                    </td>
                    <td colspan="<?php if (isset($colspan)) echo $colspan; else echo '2'; ?>">
                        <input type="text" name="coupon"/>
                    </td>
                </tr>
            <?php } ?>

            <?php if (isset($userid) && $userid != 0 && trim($userid) != '' && $userid != NULL) {
                $address = $Model->getUserinfo($userid);
                @$cits = $Model->getCits();
                ?>
                <tr>
                    <td colspan="6"><?php echo JText::_('COM_JSTAR_SHOP_ADDRESS'); ?></td>
                </tr>
                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_NAME_FAMILY'); ?><span class="star">&nbsp;*</span></label>
                    </td>
                    <td colspan="3">
                        <input type="text" value="<?php echo @$address->name; ?>" aria-required="true" required=""
                               size="25" class="required" id="jform_name_family" name="name_family"/>
                    </td>
                </tr>

                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_MOBILE'); ?></label>
                    </td>
                    <td colspan="3">
                        <input type="text" size="25" value="<?php echo @$address->mobile; ?>" id="jform_mobile"
                               name="mobile"/>
                    </td>
                </tr>

                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_STATE'); ?></label>
                    </td>
                    <td colspan="3">
                        <select name="state" id="state1" onchange="getSubcits()">
                            <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_STATE'); ?></option>
                            <?php foreach ($cits as $cit) {
                                if ($address->state == $cit->id) {
                                    $selected = 'selected="SELECTED"';
                                } else {
                                    $selected = '';
                                }
                                ?>
                                <option <?php echo $selected; ?>
                                        value="<?php echo $cit->id; ?>"><?php echo $cit->city; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_CITY'); ?></label>
                    </td>
                    <td colspan="3">
                        <select name="city" id="city1">
                            <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_CITY'); ?></option>
                            <?php
                            @$checkcits = $Model->checkCits($address->state);
                            foreach ($checkcits as $cit) {
                                if ($address->city == $cit->id) {
                                    $selected = 'selected="SELECTED"';
                                } else {
                                    $selected = '';
                                }
                                ?>
                                <option <?php echo $selected; ?>
                                        value="<?php echo $cit->id; ?>"><?php echo $cit->city; ?></option>
                            <?php } ?>

                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_ADDRESS'); ?></label>
                    </td>
                    <td colspan="3">
                        <textarea id="jform_address2" name="address"><?php echo @$address->address; ?></textarea>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_POSTAL_CODE'); ?></label>
                    </td>
                    <td colspan="3">
                        <input type="text" size="25" value="<?php echo @$address->postal_code; ?>"
                               id="jform_postal_code2" name="postal_code"/>
                    </td>
                </tr>
                <tr>
                    <td colspan="6">
                        <button class="btn btn-primary"
                                type="submit"><?php echo JText::_('COM_JSTAR_SHOP_FACTOR'); ?></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php echo JHtml::_('form.token'); ?>
    </form>
    <?php if (!isset($userid) || $userid == 0) {
    @$cits = $Model->getCits();
    ?>
    <div class="row-fluid" id="cart_form">


        <div id="cart_txt"><?php echo JText::_('COM_JSTAR_SHOP_REGISTER_OR_LOGIN'); ?></div>
        <div class="login span6" id="login">
            <form class="form-validate form-horizontal well" action="<?php echo $link3; ?>" method="post">
                <fieldset>
                    <div class="control-group">
                        <div class="control-label">
                            <label class="required" for="username"
                                   id="username-lbl"><?php echo JText::_('COM_JSTAR_SHOP_USERNAME'); ?><span
                                        class="star">&nbsp;*</span></label>
                        </div>
                        <div class="controls">
                            <input type="text" autofocus="" aria-required="true" required="" size="25"
                                   class="validate-username required" value="" id="username" name="username">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="control-label">
                            <label class="required" for="password"
                                   id="password-lbl"><?php echo JText::_('COM_JSTAR_SHOP_PASSWORD'); ?><span
                                        class="star">&nbsp;*</span></label>
                        </div>
                        <div class="controls">
                            <input type="password" aria-required="true" required="" maxlength="99" size="25"
                                   class="validate-password required" value="" id="password" name="password">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <button class="btn btn-primary"
                                    type="submit"><?php echo JText::_('COM_JSTAR_SHOP_LOGIN'); ?></button>
                        </div>
                    </div>
                </fieldset>

                <?php
                if (!empty($this->items)) {
                    foreach ($this->items as $i => $item) { ?>
                        <input id="count3_<?php echo $item->id; ?>" type="hidden"
                               name="count_buy3_<?php echo $item->id; ?>" value="1"/>
                    <?php }
                }
                echo JHtml::_('form.token'); ?>
            </form>
        </div>


        <div id="register" class="span6">
            <form class="form-validate form-horizontal well" action="<?php echo $link2; ?>" method="post">
                <table cellpadding="2" cellspacing="2" id="table_register">
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_NAME_FAMILY'); ?><span
                                        class="star">&nbsp;*</span></label>
                        </td>
                        <td>
                            <input type="text" aria-required="true" required="" size="25" class="required" value=""
                                   id="jform_name_family" name="jform[name_family]"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_USERNAME'); ?><span
                                        class="star">&nbsp;*</span></label>
                        </td>
                        <td>
                            <input type="text" aria-required="true" required="" size="25" class="required" value=""
                                   id="jform_username" name="jform[username]"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_PASSWORD'); ?><span
                                        class="star">&nbsp;*</span></label>
                        </td>
                        <td>
                            <input type="password" aria-required="true" required="" size="25" class="required" value=""
                                   id="jform_pass" name="jform[pass]"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_MOBILE'); ?></label>
                        </td>
                        <td>
                            <input type="text" size="25" value="" id="jform_mobile" name="jform[mobile]"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_STATE'); ?></label>
                        </td>
                        <td>
                            <select name="jform[state]" id="state1" onchange="getSubcits()">
                                <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_STATE'); ?></option>
                                <?php foreach ($cits as $cit) { ?>
                                    <option value="<?php echo $cit->id; ?>"><?php echo $cit->city; ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_CITY'); ?></label>
                        </td>
                        <td>
                            <select name="jform[city]" id="city1">
                                <option value="0"><?php echo JText::_('COM_JSTAR_SHOP_SELECT_CITY'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_ADDRESS'); ?></label>
                        </td>
                        <td>
                            <textarea id="jform_address" name="jform[address]"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label class="required"><?php echo JText::_('COM_JSTAR_SHOP_POSTAL_CODE'); ?></label>
                        </td>
                        <td>
                            <input type="text" size="25" value="" id="jform_postal_code" name="jform[postal_code]"/>
                        </td>
                    </tr>
                    <tr>
                        <td id="register" colspan="2">
                            <button class="btn btn-primary"
                                    type="submit"><?php echo JText::_('COM_JSTAR_SHOP_REGISTER'); ?></button>
                        </td>
                    </tr>
                </table>
                <input type="hidden" name="jform[cart]" value="1"/>
                <?php
                if (!empty($this->items)) {
                    foreach ($this->items as $i => $item) { ?>
                        <input id="count2_<?php echo $item->id; ?>" type="hidden"
                               name="jform[count_buy2_<?php echo $item->id; ?>]" value="1"/>
                        <?php
                    }
                }
                echo JHtml::_('form.token'); ?>
            </form>
        </div>


        <div class="clear"></div>
    </div>

    </div>
<?php } ?>
<?php endif; ?> 