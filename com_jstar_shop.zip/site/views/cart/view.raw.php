<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopViewCart extends JViewLegacy
{
	public function display($tpl = null)
	{ 
		$db	= JFactory::getDbo(); 
		$parentcit = JFactory::getApplication()->input->get('parentcit', '', 'string');
		$query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE parentid = ".$db->quote($db->escape($parentcit))." 
		UNION 
		SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` IN 
	    (SELECT `id` FROM `#__jstar_shop_cits` WHERE `parentid` = ".$db->quote($db->escape($parentcit)).")"; 
		$db->setQuery( $query );
		$subcits = $db->loadObjectList(); 
		echo '{items:'.json_encode($subcits).'}';
	}

}
