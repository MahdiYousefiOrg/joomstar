<?php
/**
 * @package    StarShop for Joomla!
 * @version    1.0.9
 * @author    joomstar.ir
 * @copyright    (C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license    GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$Model = $this->getModel();
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/amazings.css');
$timezone = JFactory::getApplication()->get('offset', 'GMT');
date_default_timezone_set($timezone);
$cdate = date('H,i,s,m,d,Y');
$cdate = explode(',', $cdate);
$cdate = mktime((int)$cdate[0], (int)$cdate[1], (int)$cdate[2], (int)$cdate[3], (int)$cdate[4], (int)$cdate[5]);
if (is_array($this->items) && !empty($this->items)) {
    foreach ($this->items as $i => $item) {
        if ($item->multicost == 1) {
            $Model = $this->getModel();
            $result = $Model->getMulticost($item->id);
            @$cost1 = $result->cost1;
            @$cost2 = $result->cost2;
        }
        $date01 = $item->date1;
        $date01 = explode(' ', $date01);
        $date1 = $date01[0];
        $time1 = $date01[1];

        $date02 = $item->date2;
        $date02 = explode(' ', $date02);
        $date2 = $date02[0];
        $time2 = $date02[1];

        $date1 = explode('-', $date1);
        $time1 = explode(':', $time1);
        $cdate1 = mktime((int)$time1[0], (int)$time1[1], (int)$time1[2], (int)$date1[1], (int)$date1[2], (int)$date1[0]);

        $date2 = explode('-', $date2);
        $time2 = explode(':', $time2);
        $cdate2 = mktime((int)$time2[0], (int)$time2[1], (int)$time2[2], (int)$date2[1], (int)$date2[2], (int)$date2[0]);


        if ($cdate > $cdate1 && $cdate < $cdate2) {
            $link = JRoute::_('index.php?option=com_jstar_shop&view=product&id=' . $item->id);
            $showdate1 = str_replace('-', '/', $item->date1);
            $showdate2 = str_replace('-', '/', $item->date2);
            ?>
            <script type="text/javascript">
                function dc_<?php echo $item->id; ?>() {
                    var sta = "<?php echo $showdate2; ?> ";
                    var currentTime = new Date();
                    var startDate = new Date(sta)
                    var dif = startDate - currentTime;
                    var s = 1000;
                    var m = 1000 * 60;
                    var h = 1000 * 60 * 60;
                    var d = 1000 * 60 * 60 * 24;

                    var days = Math.floor(dif / d);
                    dif -= days * d;
                    if (dif <= 0) dif = 0;

                    var hours = Math.floor(dif / h);
                    dif -= hours * h;
                    if (dif <= 0) dif = 0;

                    var minutes = Math.floor(dif / m);
                    dif -= minutes * m;
                    if (dif <= 0) dif = 0;

                    var seconds = Math.floor(dif / s);
                    if (days == -1 && hours == 23 && minutes == 59 && seconds == 59) {
                        document.getElementById('d_<?php echo $item->id; ?>').innerHTML = "<?php echo JText::_('COM_JSTAR_SHOP_END_TIME'); ?>";
                    } else if (days != -1) {
                        document.getElementById('d_<?php echo $item->id; ?>').innerHTML = "<?php echo JText::_('COM_JSTAR_SHOP_DAY'); ?>:" + days + "	<?php echo JText::_('COM_JSTAR_SHOP_HOURS'); ?>:" + hours + "	<?php echo JText::_('COM_JSTAR_SHOP_MINITS'); ?>:" + minutes + "	<?php echo JText::_('COM_JSTAR_SHOP_SECONDS'); ?>:" + seconds;
                    }
                }

                setInterval("dc_<?php echo $item->id; ?>()", 1000);
            </script>
            <div id="product1" class="span4 mamazings_box">
                <div class="intro_product">
                    <div class="c-promotion__discount">
                        <span><?php echo '%' . $item->off; ?></span>
                    </div>
                    <div id="product_img"><a href="<?php echo $link; ?>"><img src="<?php echo $item->img1; ?>"/></a>
                    </div>
                    <div id="product_title"><a href="<?php echo $link; ?>"><?php echo $item->title; ?></a></div>
                    <div class="amazings" id="d_<?php echo $item->id; ?>"></div>
                    <div id="product_price">
                        <?php if ($item->multicost == 1) { ?>
                            <div class="c-price">
                                <div class=""><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($cost2 - ($cost2 * $item->off / 100))) . '  ' . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></div>
                            </div>
                        <? } else { ?>
                            <div class="c-price">
                                <div class="c-price2">
                                    <del id="price_product"><?php echo Jstar_shop_Fa_digits::fa_digits(@number_format($item->mainprice)); ?></del>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="clear"></div>
                    </div>
                </div>
            </div>
        <?php }
    }
} else {
    echo '<div class="alert alert-no-items">' . JText::_('COM_JSTAR_SHOP_NO_PRODUCT') . '</div>';
} ?>
<div class="clear"></div>
</div>
