<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/orderinfo.css');
$Model = $this->getModel();
if (empty($this->items)) { ?>
    <div class="alert alert-no-items">
        <?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
    </div>
<?php } else { ?>
    <table cellpadding="2" cellspacing="2" id="table_cart">
        <tr>
            <th><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
            <th><?php echo JText::_('COM_JSTAR_SHOP_PRICE_UNIT'); ?></th>
            <th><?php echo JText::_('COM_JSTAR_SHOP_COUNT'); ?></th>
            <th><?php echo JText::_('COM_JSTAR_SHOP_GIFTS'); ?></th>
            <th><?php echo JText::_('COM_JSTAR_SHOP_PAY_PRICE'); ?></th>
        </tr>
        <?php
        $total_price = 0;
        $total_price1 = 0;
        if (!empty($this->items)) {
            $typePost = $Model->getTypePost($this->items[0]->typePost);
            foreach ($this->items as $i => $item) : $gift_price = 0; ?>
                <tr>
                    <td><?php echo $item->ptitle; ?></td>
                    <td>
                        <ul>
                            <li>
                                <?php if ($item->multicost == 1 && $item->fieldid != 0) {
                                    $result = $Model->getCost($item->fieldid);
                                    $cost1 = $result->cost1;
                                    $cost2 = $result->cost2;
                                    $price_main = $cost2;
                                    $off = round(($cost2*$item->amazing_off/100))+($cost1 - $cost2);
                                    $price_show = $cost1;
                                } else {
                                    $cost2 = 0;
                                    $cost1 = 0;
                                    $off =  round(($item->off*$item->amazing_off/100))+($item->pprice - $item->off);
                                    $price_main = $item->off;
                                    $price_show = $item->pprice;
                                }
                                ?>
                                <del><?php echo $price_show; ?></del>
                                <br/>
                                <span><?php echo $price_main; ?></span>
                            </li>
                            <?php if (!empty($gid)) { ?>
                                <li>
                                    <?php echo JText::_('COM_JSTAR_SHOP_GIFT') . ' : ' . $gift_price; ?>
                                </li>
                            <?php } ?>
                            <?php if (isset($item->coupon) && $item->coupon != 0 && $item->coupon != NULL && trim($item->coupon) != '') { ?>
                                <li>
                                    <?php echo JText::_('COM_JSTAR_SHOP_DISCOUNT_CODE') . ':' . $Model->getCoupon($item->coupon) . JText::_('COM_JSTAR_SHOP_PERCENT'); ?>
                                </li>
                            <?php } ?>
                            <?php if (isset($this->usercoupon) && $this->usercoupon != 0 && $this->usercoupon != NULL && trim($this->usercoupon) != '') { ?>
                                <li>
                                    <?php echo JText::_('COM_JSTAR_SHOP_DISCOUNT_USER') . ':' . $this->usercoupon . JText::_('COM_JSTAR_SHOP_PERCENT'); ?>
                                </li>
                            <?php } ?>
                        </ul>
                    </td>
                    <td><?php echo $item->count2; ?></td>

                    <td>
                        <table>
                            <?php if (!empty($item->giftid) && trim($item->giftid) != '' && $item->giftid != NULL) {
                                $giftsid = $Model->getGifts($item->giftid);
                                $gift_price = 0;
                                foreach ($giftsid as $gprice) {
                                    $gift_price += $gprice->price;
                                    ?>
                                    <tr>
                                        <td><?php echo $gprice->title; ?></td>
                                        <td><?php echo $gprice->price; ?></td>
                                    </tr>
                                <?php }
                            }
                            ?>
                        </table>
                    </td>
                    <?php

                    @$total_price1= ($item->count2*($price_show-$off))+($item->count2*@$gift_price)-$item->count2*(($price_show-$off)*$this->coupon/100)-$item->count2*(($price_show-$off)*@$this->usercoupon/100);
                    @$total_price+= ($item->count2*($price_show-$off))+($item->count2*@$gift_price)-$item->count2*(($price_show-$off)*$this->coupon/100)-$item->count2*(($price_show-$off)*@$this->usercoupon/100);
                    ?>
                    <td><?php echo $total_price1; ?></td>
                </tr>

            <?php endforeach;
        }

        ?>

        <tr>
            <td colspan="3"><?php echo JText::_('COM_JSTAR_SHOP_COST_SEND'); ?></td>
            <td colspan="2"><?php echo @$typePost->type_post.' - '.@($typePost->amount); ?></td>
        </tr>

        <tr>
            <td colspan="3"><?php echo JText::_('COM_JSTAR_SHOP_TOTAL_PRICE'); ?></td>
            <td colspan="2"><?php echo @number_format($total_price+(@$typePost->amount)); ?></td>
        </tr>

    </table>
<?php } ?>