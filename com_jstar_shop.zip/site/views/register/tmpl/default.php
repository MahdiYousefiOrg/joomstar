<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument();
$doc->addStyleSheet('media/com_jstar_shop/css/site.stylesheet.css');
$doc->addStyleSheet('media/com_jstar_shop/css/profile.css');
$link = JRoute::_('index.php?option=com_jstar_shop&task=user.register', false); 
?>
<form action="<?php echo $link ?>" method="post" enctype="multipart/form-data">
<table class="plainrows">
    	<tr>
        	<td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_NAME_FAMILY') ?></td>
            <td class="td2"><input type="text" name="jform[name_family]" size="30" value="" /></td>
        </tr>
    	<tr>
        	<td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_USERNAME') ?></td>
            <td class="td2"><input type="text" name="jform[username]" size="30" value="" /></td>
        </tr>
    	<tr>
        	<td class="td1"><?php echo JText::_('COM_JSTAR_SHOP_PASSWORD') ?></td>
            <td class="td2"><input type="password" name="jform[pass]" size="30" value="" /></td>
        </tr>
        <tr>
        	<input type="hidden" name="jform[reg]" value="1" />
        	<td colspan="2"><input class="buttom btn-success" type="submit" value="<?php echo JText::_('COM_JSTAR_SHOP_REGISTER') ?>" /></td>
        </tr>
</table>
		<?php echo JHtml::_('form.token'); ?>
</form>