<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelSearched extends JModelList
{
	private $_parent = null;
	function __construct()
	{
                $config['filter_fields'] = array(
					'price'
                );
		parent::__construct();
	}
	
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		parent::populateState('id', 'DESC');
	}
	
	

	public function getListQuery()
	{ 
		$db = JFactory::getDBO();
		$publish = $db->quote( $db->escape( 1 ), false );
		$table = $db->quoteName( '#__jstar_shop_products' );
		$cel_id = $db->quoteName( 'id' );
		$cel_title = $db->quoteName( 'title' );
		$cel_price = $db->quoteName( 'price' );
		$cel_multicost = $db->quoteName( 'multicost' );
		$cel_off = $db->quoteName( 'off' );
		$cel_img1 = $db->quoteName( 'img1' );
		$cel_published = $db->quoteName( 'published' );
		@$_SESSION['search_txt'] = $_POST['search_txt'];
		$search = $_SESSION['search_txt'];
		$search = $db->escape($search);
		
		$query = "SELECT $cel_id,$cel_title,$cel_price,$cel_img1,$cel_multicost,$cel_off FROM $table WHERE ($cel_title LIKE '%$search%') AND $cel_published = $publish";
		$db->setQuery( $query );
		$rows = $db->LoadObjectList();
		$order = JFactory::getApplication()->input->get('filter_order');
		if(isset($order) && $order != NULL && trim($order) != ''){
			$dirn = JFactory::getApplication()->input->get('filter_order_Dir');
			$order = $db->escape($order);
			$dirn = $db->escape($dirn);
			$query.=" ORDER BY `$order` $dirn";
		}
		//die($query);
		return $query;
	}
			
	public function getMulticost($pid){
			$db			= JFactory::getDbo();
			$pid = $db->escape( $pid );
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' ORDER BY `cost2` ASC";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
			return $result;
	}
			
}
