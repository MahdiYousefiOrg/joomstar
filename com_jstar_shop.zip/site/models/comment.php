<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;

class Jstar_shopModelComment extends JModelForm
{
    public function getForm($data = array(), $loadData = true)
    {
        $user = JFactory::getUser();
        if (isset($user->id) && $user->id != NULL) {
            $form = $this->loadForm('com_jstar_shop.comment', 'comment', array('control' => 'jform', 'load_data' => $loadData));
        } else {
            $form = $this->loadForm('com_jstar_shop.register', 'register', array('control' => 'jform', 'load_data' => $loadData));
        }
        if (empty($form)) {
            return false;
        }
        return $form;
    }

    public function save($data)
    {
        $db = JFactory::getDBO();
        $table = $db->quoteName('#__jstar_shop_comments');
        $cel_id = $db->quoteName('id');
        $cel_product_id = $db->quoteName('product_id');
        $cel_user_id = $db->quoteName('user_id');
        $cel_comment = $db->quoteName('comment');
        $cel_published = $db->quoteName('published');
        $cel_date2 = $db->quoteName('date2');
        $date2 = $db->escape(JFactory::getDate()->Format('Y-m-d'));
        JSession::checkToken() or die( 'Invalid Token' );
        $user = JFactory::getUser();
        $userid = $user->id;
        $userid = $db->quote($db->escape($userid), false);
        $publish = $db->quote(0, false);
        if (trim($data['comment']) == '') {
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_COMMENT'), 'error');
            return false;
        }
        $pid = $db->quote($db->escape($data['pid']), false);
        $comment = $db->quote($db->escape($data['comment']), false);
        $query = "INSERT INTO " . $table . " ($cel_id, $cel_product_id, $cel_user_id, $cel_comment, $cel_date2, $cel_published) VALUES (NULL, $pid, $userid, $comment,'$date2', $publish)";
        $db->setQuery($query);
        $db->execute();
        return $data['pid'];
    }
}
