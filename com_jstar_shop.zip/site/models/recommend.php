<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelRecommend extends JModelItem
{
	public function __construct($config = array())
	{ 

		parent::__construct($config);
	}
	public function getItem()
	{ 
		$db				= $this->getDbo();
		$query			= $db->getQuery(true);
		$table = $db->quoteName( '#__jstar_shop_users' );
		$table2 = $db->quoteName( '#__users' );
		$cel_user_id = $db->quoteName( 'user_id' );
		$userid  = JFactory::getUser()->id;
		$userid = $db->quote( $db->escape( $userid ), false );
		$query = "SELECT `a`.*,`b`.`email`,`b`.`name` FROM ".$table." AS `a` LEFT JOIN ".$table2." AS `b` ON `a`.`user_id` = `b`.`id` WHERE ".$cel_user_id." = $userid";
		$db->setQuery( $query );
		$row = $db->LoadObject();
		return $row;
	}

	public function save2($data)
	{ 
		$db				= $this->getDbo();
		$userid  = JFactory::getUser()->id;
		$userid = $db->quote( $db->escape( $userid ), false );
		//CHECKED
		JSession::checkToken() or die( 'Invalid Token' );
		if (trim(@$data['name_family']) == '' || trim(@$data['mobile'])=='')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_FIELDS'), 'error');
			return false;
		}
		$table = $db->quoteName( '#__jstar_shop_recommends' );
		$cel_mobile = $db->quoteName( 'mobile' );
		$cel_id = $db->quoteName( 'id' );
		$cel_userid = $db->quoteName( 'userid' );
		$cel_name_family = $db->quoteName( 'name_family' );
		$cel_date = $db->quoteName( 'date' );
		$cel_recommend = $db->quoteName( 'recommend' );
		$name_family = $db->quote( $db->escape( $data['name_family'] ), false );
		$mobile = $db->quote( $db->escape( $data['mobile'] ), false );
		$recommend = $db->quote( $db->escape( $data['recommend'] ), false );
		$date = $db->quote( $db->escape( JFactory::getDate()->Format('Y-m-d') ), false );
		$query = "INSERT INTO ".$table."(".$cel_id.",".$cel_userid.",".$cel_name_family.",".$cel_mobile.", ".$cel_recommend.", ".$cel_date.") VALUES (NULL, ".$userid.", ".$name_family.", ".$mobile.", ".$recommend.", ".$date.")";
		$db->setQuery( $query ); 
		$db->execute();
		return true;
	}
	public function getUserinfo($userId)
	{
		// Create a new query object.
		$db = $this->getDbo();
		$userId = $db->escape($userId);
		$query = "SELECT `a`.*,`b`.`name` FROM `#__jstar_shop_users` AS `a` LEFT JOIN `#__users` AS `b` ON `a`.`user_id` = `b`.`id` WHERE `a`.`user_id` = '$userId'";
		$db->SetQuery( $query );
		$address = $db->LoadObject();
		return $address;
	}

}
?>
