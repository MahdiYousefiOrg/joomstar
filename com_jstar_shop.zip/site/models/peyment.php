<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelPeyment extends JModelLegacy
{
	protected function getOff($coupon = NULL){
		$db = $this->getDbo();
		$user = JFactory::getUser();
		$userid = $user->id;
		$date = date('Y-m-d');
		$date = $db->quote($db->escape($date));
		if($coupon != NULL){
			$query = "SELECT `percent` FROM `#__jstar_shop_coupons` WHERE `code` = '$coupon' AND `date1` <= $date AND `date2` >= $date";
			$db->setQuery( $query );
			$percent1 = $db->LoadResult(); 
		} else {
			$percent1 = 0;
		}
		$query = "SELECT `percent` FROM `#__jstar_shop_coupon_users` WHERE `userid` = '$userid'";
		$db->setQuery( $query );
		$percent2 = $db->LoadResult();
		if(!isset($percent2) || $percent2 == NULL){
			$percent2 = 0;
		} 
		
		$percent = array("percent1" => $percent1,"percent2" => $percent2);		
		return $percent;
	}
	
	protected function getAmount($pid){
		$db = $this->getDbo();
		$one = $db->escape(1);
		$query = "SELECT `b`.`id` FROM `#__jstar_shop_products` AS `a` LEFT JOIN `#__jstar_shop_multicosts` AS `b` ON `a`.`id` = `b`.`pid` WHERE `a`.`id` = '$pid' AND a.multicost = $one ORDER BY `b`.`cost2` ASC";
		$db->setQuery( $query );
		$fieldid = $db->LoadResult(); 
		
		if(isset($_SESSION['multicost'][$pid]) && $_SESSION['multicost'][$pid] != NULL && trim($_SESSION['multicost'][$pid]) != ''){ 
			$fieldid = $_SESSION['multicost'][$pid];
			$fieldid = $db->escape($fieldid);
			$query = "SELECT `cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
			$db->SetQuery( $query );
			$amount = $db->LoadResult();
		} 
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (isset($fieldid) && $fieldid !=0 && $fieldid != NULL && trim($fieldid) != '')){ 
			$fieldid = $fieldid;
			$fieldid = $db->escape($fieldid);
			$query = "SELECT `cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
			$db->SetQuery( $query );
			$amount = $db->LoadResult();
		}
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (!isset($fieldid) || $fieldid == 0 || $fieldid == NULL || trim($fieldid) == '')){ 
			$query3 = "SELECT `off` FROM `#__jstar_shop_products` WHERE `id` = '$pid'";
			$db->setQuery( $query3 );
			$amount = $db->LoadResult();
			$fieldid = NULL;
		}
		$amount = $db->escape($amount);
		$amount_feild = array("amount" => $amount,"fieldid" => $fieldid);		
		return $amount_feild;
	}
	
	
	protected function getGifts($pid){
		$db = $this->getDbo();
		$gids = $_SESSION['gid_'.$pid];
		@$gid = implode(',',$gids);
		$gid = $db->escape($gid);
		$gift_price = 0;
		
		if(!empty($gids) && isset($_SESSION['gid_'.$pid])){
			$query = "SELECT `id` FROM `#__jstar_shop_gifts` WHERE find_in_set($pid,products_id) AND `id` IN ($gid)";
			$db->setQuery( $query );
			$giftsid = $db->LoadColumn();
			$giftsid = implode(',',$giftsid);
			
			$query = "SELECT `price` FROM `#__jstar_shop_gifts` WHERE find_in_set($pid,products_id) AND `id` IN ($gid)";
			$db->setQuery( $query );
			$giftprice = $db->LoadColumn();
			$gift_price = @array_sum($giftprice);
		} else {
			$giftsid = NULL;
			$gift_price = 0;
		}
		$gifts = array("giftsid" => $giftsid,"gift_price" => $gift_price);		
		return $gifts;
	}
	
	
	protected function getCostPost($pid,$type_post,$pay,$city){
		$db = $this->getDbo();
		$query = "SELECT b.id FROM `#__jstar_shop_products` AS a LEFT JOIN `#__jstar_shop_posts` AS b ON find_in_set(b.id,a.posts) LEFT JOIN `#__jstar_shop_cits` AS c ON find_in_set(c.id,b.cits) WHERE a.id = '$pid' AND a.w >= b.w1 AND a.w <= b.w2 AND '$pay' >= b.price1 AND '$pay' <= b.price2 AND find_in_set($city,b.cits) GROUP BY b.id";
		$db->SetQuery($query);
		$type_posts = $db->LoadColumn(); 
		if(!in_array($type_post,$type_posts) && $type_post != 0){ 
			$app = JFactory::getApplication();
			$app->enqueueMessage(JTExt::_('COM_JSTAR_SHOP_NOT_SET_TYPE_POST'), 'error');
			$app->redirect(JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cart',false));
		}
		
		$query = "SELECT `amount` FROM `#__jstar_shop_posts` WHERE `id` = '$type_post'";
		$db->SetQuery($query);
		$costPost = $db->LoadResult();
		return $costPost;
	}
	

	

	
	/* MainFunction --------------------------------------------------------------------*/
	public function save_order($payment) { 
		$db = $this->getDbo();
		$folder = $db->escape('jstar_shop_payments');
		$query = "SELECT `element` FROM #__extensions`` WHERE `folder` = '$folder'";
		$db->setQuery($query);
		$bank			= $db->loadColumn();
		$params = JComponentHelper::getParams('com_jstar_shop');
		$steppay = $params->get('steppay');
		if($steppay == 0 && !in_array($payment,$bank)){
			$app = JFactory::getApplication();
			$link =  JRoute::_('index.php?option=com_jstar_shop',false);
			$msg = JText::_('COM_JSTAR_SHOP_NO_PAYMENT');
			$app->redirect($link, $msg);
		}
		if($payment != 'nobank' && !in_array($payment,$bank)){
			$app = JFactory::getApplication();
			$link =  JRoute::_('index.php?option=com_jstar_shop',false);
			$msg = JText::_('COM_JSTAR_SHOP_NO_PAYMENT');
			$app->redirect($link, $msg);
		}
		
		$user = JFactory::getUser();
		$userid = $user->id;
		$userid = $db->escape($userid);
		$arr_pid = @$_SESSION['product']; 
		if(isset($arr_pid)){
			/* get off -------------------------------------------------------*/
			@$coupon = JFactory::getApplication()->input->get('coupon'); 
			@$coupon = $db->escape($coupon);
			$percent = $this->getOff($coupon);
			$percent1 = $percent['percent1'];
			$percent2 = $percent['percent2'];
            /* get CostPost -------------------------------------------------------*/
            $type_post = JFactory::getApplication()->input->get('typePost');
            $type_post = $db->escape($type_post);
            $query = "SELECT `amount` FROM `#__jstar_shop_posts` WHERE `id` = '$type_post'";
            $db->setQuery( $query );
            $costPost = $db->LoadResult();
            if(!isset($costPost) || trim($costPost) == ''){
                $costPost = 0;
            }
			
			$name = $_SESSION['add_name'];
			$name = $db->escape($name);
			$mobile = $_SESSION['add_mobile'];
			$mobile = $db->escape($mobile);
			$state = $_SESSION['add_state'];
			$state = $db->escape($state);
			$city = $_SESSION['add_city'];
			$city =  $db->escape($city);
			$address = $_SESSION['add_address'];
			$address = $db->escape($address);
			$postal_code = $_SESSION['add_postal_code'];
			$postal_code = $db->escape($postal_code);
			$sh = time().rand(0,9);
			if(isset($arr_pid)) { 
				foreach($arr_pid as $pid){
					$count = JFactory::getApplication()->input->get('count_buy_'.$pid);
					$count = $db->escape($count);
					$pid = $db->escape($pid);
					/* get amount -------------------------------------------------------*/
					$amount_feild = $this->getAmount($pid);
					$amount = $amount_feild['amount'];
                    $amazings = Jstar_shop_CHeckupHelper::getAmazings();
                    if ($off_amazing = array_search($pid, $amazings)) {
                        $off_amazing = explode('-', $off_amazing)[1];
                        $amazing = 1;
                    } else {
                        $off_amazing = 0;
                        $amazing = 0;
                    }
                    $amount = $amount - round($amount*$off_amazing/100);
					$fieldid = $amount_feild['fieldid'];
					/* get gifts -------------------------------------------------------*/
					$gifts = $this->getGifts($pid);
					$giftsid = $gifts['giftsid'];
					$gift_price = $gifts['gift_price'];

					/* do -------------------------------------------------------*/
					$amount = ($count*$amount)+($count*$gift_price)-($amount*$percent1/100)-($amount*$percent2/100);
					$amount = $db->escape($amount);
					$percent2 = $db->escape($percent2);
					@$giftsid = $db->escape($giftsid);
					$date2 = date("Y-m-d"); 
					$query = "INSERT INTO `#__jstar_shop_orders` (`id`, `sh`, `user_id`,`product_id`,`fieldid`, `count2`,`coupon`, `usercoupon`, `amount`,`date2`, `giftid`, `typePost`, `amazing`, `amazing_off`, `ordering`) VALUES (NULL, '$sh', '$userid','$pid','$fieldid', '$count','$coupon', '$percent2','$amount','$date2', '$giftsid', '$type_post', '$amazing', '$off_amazing', '0')";
					$db->setQuery( $query );
					$db->execute();
					$session = JFactory::getSession();
					$session->set( 'product_'.$pid, 'again' );
					unset($_SESSION['count_buy2_'.$pid]);
					unset($_SESSION['gid_'.$pid]);
					unset($_SESSION['multicost'][$pid]);
				}
				$query = "INSERT INTO `#__jstar_shop_order_details` (`id`, `name`, `sh_order`, `state`, `city`, `address`, `postalcode`, `mobile`, `status`) VALUES (NULL, '$name', '$sh', '$state', '$city', '$address', '$postal_code', '$mobile', '-2')";
				$db->setQuery( $query );
				$db->execute();
			}

			unset($_SESSION['product']);
			unset($_SESSION['coupon']);
			unset($_SESSION['add_name']);
			unset($_SESSION['add_mobile']);
			unset($_SESSION['add_state']);
			unset($_SESSION['add_city']);
			unset($_SESSION['add_address']);
			unset($_SESSION['add_postal_code']);
			/*---------------- payments ------------------------------------------------------- */
			if($payment != 'nobank'){ 
				JPluginHelper::importPlugin( 'jstar_shop_payments', $payment );
				$dispatcher = JEventDispatcher::getInstance();
				$params = array($sh,$payment); 
				$results = $dispatcher->trigger( 'OnSubmit', array($sh,$payment) );
			}
		} else {
			$app = JFactory::getApplication();
			$app->enqueueMessage(JText::_('COM_JSTAR_SHOP_PROBLEM_SAVE'), 'error');
			$app->redirect(JRoute::_('index.php'));			
		}
		return true;
	}
	
	public function gotobank(){
			$db = $this->getDbo();
			$payment = JFactory::getApplication()->input->get('payment', 'nobank', 'string');
			JPluginHelper::importPlugin( 'jstar_shop_payments', $payment );
			$dispatcher = JEventDispatcher::getInstance();
			$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
			$sh = $db->escape($sh);
			$params = array($sh,$payment); 
			$results = $dispatcher->trigger( 'OnSubmit', array($sh, $payment) );
	}
}
