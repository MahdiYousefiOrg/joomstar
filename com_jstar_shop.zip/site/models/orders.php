<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelOrders extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
				'name','b.name',
				'product','c.title',
				'payment_method','c.payment_method',
				'count2','orders.count2',
				'percent','orders.percent',
				'amount','orders.amount',
				'date2','orders.date2'
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
			
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
				
		parent::populateState('orders.id', 'DESC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{ 
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);
			$userid  = JFactory::getUser()->id;
			$userid = $db->quote($db->escape($userid));
		// Select the required fields from the table.
				
			$query = "SELECT `a`.`sh`, `a`.`user_id`, `a`.`date2`, SUM(`a`.`count2`) AS `scount2`, SUM(`a`.`coupon`) AS `scoupon`, SUM(`a`.`amount`) `samount`, `b`.`name`, `c`.`status`, `c`.`payment_method`, `d`.`title` FROM `#__jstar_shop_orders` AS `a` LEFT JOIN `#__jstar_shop_order_details` AS `c` ON `a`.`sh` = `c`.`sh_order` LEFT JOIN `#__jstar_shop_products` AS `d` ON `a`.`product_id` = `d`.`id` LEFT JOIN `#__users` AS `b` ON `a`.`user_id` = `b`.`id` WHERE `a`.`user_id` = $userid";
			$search = $this->getState('filter.search');
			if (!empty($search)) {
					$search = $db->Quote('%'.$db->escape($search, true).'%');
					$query.=" AND `d`.`title` LIKE ".$search;
				} 
			$query.=" GROUP BY `a`.`sh` ORDER BY `a`.`id` DESC";
			return $query;
	}
	public function getBanks() {
		$db			= $this->getDbo();
		$folder = $db->escape('jstar_shop_payments');
		$query = "SELECT `name`,`element` FROM #__extensions`` WHERE `folder` = '$folder'";

		$db->setQuery($query);
		$faq			= $db->loadObjectList();

		return $faq;
	}
	
}
?>
