<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;

class Jstar_shopModelCompare extends JModelList
{
    public function __construct($config = array())
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array();
        }

        parent::__construct($config);
    }

    protected function populateState($ordering = null, $direction = null)
    {
        // List state information.
        parent::populateState('a.id', 'asc');

    }

    protected function getListQuery()
    {
        // Create a new query object.
        $db = $this->getDbo();
        $table = $db->quoteName('#__jstar_shop_products');
        $arr_pid2 = @$_SESSION['compare'];

        $parentids = Jstar_shop_CHeckupHelper::getparents4();
        $childids = Jstar_shop_CHeckupHelper::getChildeid();
        $idstr = array_merge($parentids, $childids);
        $idstr = array_unique($idstr);
		$idstr = array_map('intval', $idstr);
        $idstr = $db->escape(implode(',', $idstr));

        if (isset($arr_pid2)) {
			$arr_pid2 = array_map('intval', $arr_pid2);
            $pids2 = implode(',', $arr_pid2);
            $pids2 = $db->escape($pids2);
            $table = $db->quoteName('#__jstar_shop_products');
            $query = "SELECT `id`,`title`,`catid`,`price`,`off`, `multicost` FROM $table WHERE `id` IN ($pids2) AND `catid`  IN ($idstr)";
            $query .= " ORDER BY `id` ASC";
            return $query;
        } else {
            return -1;
        }
    }


    public function getAjax_compare()
    {
        $db = JFactory::getDBO();
        $pid = JFactory::getApplication()->input->get('pid', '0', 'int');
        $session = JFactory::getSession();
        $session->set('compare_' . $pid, $pid);
        $_SESSION['compare'][$pid] = $pid;
        $pid = $db->quote($db->escape($pid), false);
        $table = $db->quoteName('#__jstar_shop_products');
        $query = "SELECT `id`,`title` FROM $table WHERE `id` = $pid";
        $db->setQuery($query);
        $rows = $db->LoadObject();
        return $rows;
    }

    public function getCost($pid)
    {
        $db = $this->getDbo();
        $pid = $db->quote($db->escape($pid), false);
        $one = $db->escape(1);
        $query = "SELECT `b`.`id` FROM `#__jstar_shop_products` AS `a` LEFT JOIN `#__jstar_shop_multicosts` AS `b` ON `a`.`id` = `b`.`pid` WHERE `a`.`id` = $pid AND `a`.`multicost` = $one";
        $db->setQuery($query);
        $fieldid = $db->LoadResult();
        if (isset($_SESSION['multicost'][$pid]) && $_SESSION['multicost'][$pid] != NULL && trim($_SESSION['multicost'][$pid]) != '') {
            $fieldid = $_SESSION['multicost'][$pid];
            $fieldid = $db->quote($db->escape($fieldid), false);
            $query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = $fieldid";
            $db->SetQuery($query);
            $result = $db->LoadObject();
        }
        if ((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (isset($fieldid) && $fieldid != 0 && $fieldid != NULL && trim($fieldid) != '')) {
            $fieldid = $db->escape($fieldid);
            $query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
            $db->SetQuery($query);
            $result = $db->LoadObject();
        }
        if ((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (!isset($fieldid) || $fieldid == 0 || $fieldid == NULL || trim($fieldid) == '')) {
            $result = new stdClass();
            $result->cost2 = -1;
        }
        return $result;
    }
}
