<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR . '/tables');
class Jstar_shopModelUser extends JModelLegacy {
	
	public function register($data)
	{
		$db = JFactory::getDBO();
		$table = $db->quoteName( '#__jstar_shop_users' );
		//CHECKED
		JSession::checkToken() or die( 'Invalid Token' );
		if (trim($data['name_family']) == '')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_NAME_FAMILY'), 'error');
			return false;
		}
		if (trim($data['username']) == '')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_USERNAME'), 'error');
			return false;
		}
		
		if (trim($data['pass']) == '')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_PASSWORD'), 'error');
			return false;
		}
		
		$email = $data['email'] = time().'yousefi.data@gmail.com';
		if (trim($data['email']) == '')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_EMAIL'), 'error');
			return false;
		}
		
		$username = $data['username'];
		$query2="SELECT `username` FROM `#__users` WHERE `username`='$username'";
		$db->setQuery( $query2 );
		$db->query();

		if($db->getNumRows()){
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_DUPLICATE_USERNAME'), 'error');
			 return false;
		}
		
// END CHECKED
		$regdate = JFactory::getDate();
		$sqldate=$regdate->toSQL();
// user register
		require_once JPATH_ROOT.'/components/com_users/models/registration.php';
		$model = new UsersModelRegistration();
		jimport('joomla.mail.helper');
		$lang = JFactory::getLanguage();
		$extension = 'com_users';
		$base_dir = JPATH_SITE;
		$language_tag = 'en-GB';
		$reload = true;
		$lang->load($extension, $base_dir, $language_tag, $reload);
		
		// Attempt to save the data.
		jimport('joomla.user.helper');
		$name = $data['name_family'];
		$pass = $data['pass'];
		$email = $data['email'];
		$reg = array(  'username'=>$data['username'],'name'=>$name,'email1'=>$email,'password1'=>$pass, 'password2'=>$pass, 'block'=>0 );
		$return = $model->register($reg);
		
		
		$query4="SELECT `id`,`activation` FROM `#__users` WHERE username = '".$db->escape($data[username])."'";
		$db->setQuery( $query4 );
		$user=$db->LoadObject();
		$userid = $user->id;

		if(!isset($userid)){
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_NOT_REGISTER'), 'error');
			return false;
		}
		
		if($user->activation){
			$activation = $user->activation;
			JUserHelper::activateUser($activation);
		}
		$mobile = $db->quote( $db->escape( $data['mobile'] ), false );
		$state = $db->quote( $db->escape( $data['state'] ), false );
		$city = $db->quote( $db->escape( $data['city'] ), false );
		$address = $db->quote( $db->escape( $data['address'] ), false );
		$postal_code = $db->quote( $db->escape( $data['postal_code'] ), false );
		$userid = $db->escape($userid);
		$query="INSERT INTO ".$table." (`id`, `user_id`, `mobile`, `state`, `city`, `address`, `postal_code`) VALUES (NULL, '$userid', $mobile, $state, $city, $address, $postal_code)";
		$db->setQuery( $query ); 
		$db->execute();
		
		$credentials = array('username' => $data['username'], 'password' => $pass);
		JFactory::getApplication()->login($credentials, $options=array());
		if(isset($data['pid'])) {
			return $data['pid'];
		} elseif($data['reg'] == 1){
		}
		elseif($data['cart'] == 1) {
			$table = $db->quoteName( '#__jstar_shop_products' );
			$arr_pid = @$_SESSION['product'];
			$arr_pid = array_filter($arr_pid);
			if(isset($arr_pid)) {
				$arr_pid = array_map('intval', $arr_pid);
				$pids = implode(',',$arr_pid);
				$pids = $db->escape( $pids );
				$table = $db->quoteName( '#__jstar_shop_products' );
				$query = "SELECT `id`,`title`,`price`,`img1` FROM $table WHERE `id` IN ($pids)";
				$query.=" ORDER BY `id` ASC";
				$db->setQuery( $query );
				$rows = $db->LoadObjectList();
				foreach ($rows as $row) {
					$_SESSION['count_buy2_'.$row->id] = $data['count_buy2_'.$row->id];
				}
				$_SESSION['coupon'] = $data['coupon'];
			}
			return 3;
		} 
		else {
			return 2;
		}
	}
	public function login($data) {
		$db = JFactory::getDBO();
		$username = $data['username'];
		$pass = $data['password'];
		$credentials = array('username' => $username, 'password' => $pass);
		JFactory::getApplication()->login($credentials, $options=array());
			$table = $db->quoteName( '#__jstar_shop_products' );
			$arr_pid = @$_SESSION['product'];
			if(isset($arr_pid)) {
				$arr_pid = array_map('intval', $arr_pid);
				$pids = implode(',',$arr_pid);
				$pids = $db->escape( $pids );
				$table = $db->quoteName( '#__jstar_shop_products' );
				$query = "SELECT `id`,`title`,`price`,`img1` FROM $table WHERE `id` IN ($pids)";
				$query.=" ORDER BY `id` ASC";
				$db->setQuery( $query );
				$rows = $db->LoadObjectList();
				foreach ($rows as $row) {
					$_SESSION['count_buy2_'.$row->id] = $data['count_buy3_'.$row->id]; 
				}
				$_SESSION['coupon'] = $data['coupon2'];
			}
	}
}
