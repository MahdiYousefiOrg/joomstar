<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelCart extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			);
		}
		@$pid_remove = JFactory::getApplication()->input->get('pid_remove', null, 'string'); 
		@$id = JFactory::getApplication()->input->get('pid', null, 'int');
		@$amazingid = JFactory::getApplication()->input->get('amazingid');
		if(isset($id) && $id != 0 && trim($id) != '' && (!isset($pid_remove))){ 
			$session = JFactory::getSession();
			$session->set( 'product_'.$id, $id );
			$_SESSION['product'][$id] = $id;
		}
		if(isset($amazingid) && $amazingid != 0 && trim($amazingid) != '' && (!isset($pid_remove))){ 
			$session = JFactory::getSession();
			$_SESSION['amazing'][$amazingid] = $amazingid;
		}
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null) 
	{
		// List state information.
		parent::populateState('a.id', 'asc');

	}

	protected function getListQuery()
	{ 
		// Create a new query object.
		$db = $this->getDbo(); 
		$table = $db->quoteName( '#__jstar_shop_products' );
		$arr_pid = @$_SESSION['product'];
		$arr_pid = @array_filter($arr_pid); 
		if(isset($arr_pid)) {
			$arr_pid = array_map('intval', $arr_pid);
			$pids = implode(',',$arr_pid);
			$pids = $db->escape( $pids );
			$table = $db->quoteName( '#__jstar_shop_products' );
			$query = "SELECT `id`,`title`,`price`,`img1`,`off` FROM $table WHERE `id` IN ($pids)";  
			$query.=" ORDER BY `id` ASC"; 
			return $query;
		} else {
			return -1;
		}
	}

	public function getDateCoupon(){
		$db = $this->getDbo();
		$date = date('Y-m-d');
		$date = $db->quote($db->escape($date));
		$query = "SELECT `percent` FROM `#__jstar_shop_coupons` WHERE `date1` <= $date AND `date2` >= $date";
		$db->setQuery( $query );
		$percent = $db->LoadColumn();
		return $percent;
	}
	public function getGifts($pid){
		$db = $this->getDbo();
		$pid = $db->escape( $pid );
		$query = "SELECT `id`,`title`,`price`,`img` FROM `#__jstar_shop_gifts` WHERE find_in_set($pid,`products_id`)";
		$db->setQuery( $query );
		$giftsid0 = $db->LoadObjectList();
		return $giftsid0;
	}
	public function checkGifts($pid){
		$db = $this->getDbo();
		$pid = $db->escape( $pid );
		$query = "SELECT `id`,`title`,`price`,`img` FROM `#__jstar_shop_gifts` WHERE find_in_set($pid,`products_id`)";
		$db->setQuery( $query );
		$giftsid = $db->LoadObjectList(); 
		return $giftsid;
	}
	public function getCost($pid){ 
		$db = $this->getDbo();
		$pid = $db->escape( $pid );
		$one = $db->escape( 1 );
		$query = "SELECT `b`.`id` FROM `#__jstar_shop_products` AS `a` LEFT JOIN `#__jstar_shop_multicosts` AS `b` ON `a`.`id` = `b`.`pid` WHERE `a`.`id` = '$pid' AND `a`.`multicost` = $one ORDER BY `b`.`cost2` ASC";
		$db->setQuery( $query );
		$fieldid = $db->LoadResult(); 
		if(isset($_SESSION['multicost'][$pid]) && $_SESSION['multicost'][$pid] != NULL && trim($_SESSION['multicost'][$pid]) != ''){ 
			$fieldid = $_SESSION['multicost'][$pid];
			$fieldid = $db->quote($db->escape( $fieldid ));
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = $fieldid";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
		} 
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (isset($fieldid) && $fieldid !=0 && $fieldid != NULL && trim($fieldid) != '')){ 
			$fieldid = $db->quote($db->escape($fieldid));
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = $fieldid";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
		}
		
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (!isset($fieldid) || $fieldid == 0 || $fieldid == NULL || trim($fieldid) == '')){ 
			$result = new stdClass(); 
			$result->cost2 = -1; 
		}
		return $result;
	}
	public function getUserinfo($userid){
		$db = $this->getDbo();
		$userid = $db->quote($db->escape($userid));
		$query = "SELECT `a`.*,`b`.`name` FROM `#__jstar_shop_users` AS `a` LEFT JOIN `#__users` AS `b` ON `a`.`user_id` = `b`.`id` WHERE `a`.`user_id` = $userid";
		$db->SetQuery( $query );
		$address = $db->LoadObject(); 
		return $address;
	}
	public function getCits(){
		$db = $this->getDbo();
		$one = $db->escape(1);
		$query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `level` = $one";
		$db->SetQuery($query);
		@$cits = $db->LoadObjectList();
		return $cits;
	}
	public function checkCits($state){
		$db = $this->getDbo();
		$state = $db->quote($db->escape($state));
		$query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` = $state";
		$db->SetQuery( $query );
		@$checkcits = $db->LoadObjectList();
		return $checkcits;
	}

}
