<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelUser_interests extends JModelList
{
	private $_parent = null;
	function __construct()
	{
		parent::__construct();
	}
	
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		parent::populateState('id', 'DESC');
	}
	

	public function getListQuery()
	{ 	
		$db = JFactory::getDBO();
		$table = $db->quoteName( '#__jstar_shop_interests' );
		$cel_id = $db->quoteName( 'id' );
		$userid = JFactory::getUser()->id;		
		
		$query = "SELECT `a`.*,`b`.`title`,`b`.`price`,`b`.`multicost`,`b`.`img1`,`b`.`off`,`b`.`status` FROM $table AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `a`.`pid` = `b`.`id` WHERE `a`.`userid` = '$userid'";
		$db->setQuery( $query );
		$rows = $db->LoadObjectList();
		return $query;
	}
	
	
		
	public function getMulticost($pid){
			$db			= JFactory::getDbo();
			$pid = $db->escape( $pid );
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' ORDER BY `cost2` ASC";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
			return $result;
	}
			
}
