<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelProfile extends JModelItem
{
	public function __construct($config = array())
	{ 

		parent::__construct($config);
	}
	public function getItem()
	{ 
		$db				= $this->getDbo();
		$query			= $db->getQuery(true);
		$table = $db->quoteName( '#__jstar_shop_users' );
		$table2 = $db->quoteName( '#__users' );
		$cel_user_id = $db->quoteName( 'user_id' );
		$userid  = JFactory::getUser()->id;
		$userid = $db->quote( $db->escape( $userid ), false );
		$query = "SELECT `a`.*,`b`.`email`,`b`.`name` FROM ".$table." AS `a` LEFT JOIN ".$table2." AS `b` ON `a`.`user_id` = `b`.`id` WHERE ".$cel_user_id." = $userid";
		$db->setQuery( $query );
		$row = $db->LoadObject();
		return $row;
	}

	public function edit2($data)
	{ 
		$db				= $this->getDbo();
		$userid  = JFactory::getUser()->id;
		$userid = $db->quote( $db->escape( $userid ), false );
		//CHECKED
		JSession::checkToken() or die( 'Invalid Token' );
		if (trim(@$data['name_family']) == '' || trim(@$data['mobile'])=='' || trim(@$data['address']) ==''  || trim(@$data['postal_code']) =='')
		{
			JFactory::getApplication()->enqueueMessage(JText::_('COM_JSTAR_SHOP_REQUIRE_FIELDS'), 'error');
			return false;
		}
		$table = $db->quoteName( '#__jstar_shop_users' );
		$cel_mobile = $db->quoteName( 'mobile' );
		$cel_id = $db->quoteName( 'id' );
		$cel_name_family = $db->quoteName( 'name' );
		$cel_address = $db->quoteName( 'address' );
		$cel_state = $db->quoteName( 'state' );
		$cel_city = $db->quoteName( 'city' );
		$cel_postal_code = $db->quoteName( 'postal_code' );
		$cel_email = $db->quoteName( 'email' );
		$name_family = $db->quote( $db->escape( $data['name_family'] ), false );
		$mobile = $db->quote( $db->escape( $data['mobile'] ), false );
		$bank_cart = $db->quote( $db->escape( $data['bank_cart'] ), false );
		$address = $db->quote( $db->escape( $data['address'] ), false );
		$postal_code = $db->quote( $db->escape( $data['postal_code'] ), false );
		$email = $db->quote( $db->escape( $data['email'] ), false );
		$state = $db->quote( $db->escape( $data['state'] ), false );
		$city = $db->quote( $db->escape( $data['city'] ), false );
		$query = "UPDATE ".$table." SET".$cel_mobile." = ".$mobile.", ".$cel_address." = ".$address.", ".$cel_postal_code." = ".$postal_code.", ".$cel_state." = ".$state.", ".$cel_city." = ".$city." WHERE `user_id` = $userid";
		$db->setQuery( $query );
		$db->execute();
		$query2="UPDATE `#__users` SET ".$cel_email." = ".$email.", ".$cel_name_family." = ".$name_family." WHERE ".$cel_id." = $userid";
		$db->setQuery( $query2 );
		$db->execute();
		return true;
	}
	public function getUserinfo($userId)
	{
		// Create a new query object.
		$db = $this->getDbo();
		$userId = $db->escape($userId);
		$query = "SELECT `a`.*,`b`.`name` FROM `#__jstar_shop_users` AS `a` LEFT JOIN `#__users` AS `b` ON `a`.`user_id` = `b`.`id` WHERE `a`.`user_id` = '$userId'";
		$db->SetQuery( $query );
		$address = $db->LoadObject();
		return $address;
	}
	public function getState2()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `level` = '1'";
		$db->SetQuery($query);
		$state = $db->LoadObjectList();
		return $state;
	}
	public function getCits($state)
	{
		// Create a new query object.
		$db = $this->getDbo();
		$state = $db->escape($state);
		$query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` = '$state'";
		$db->SetQuery( $query );
		@$cits = $db->LoadObjectList();
		return $cits;
	}

}
?>
