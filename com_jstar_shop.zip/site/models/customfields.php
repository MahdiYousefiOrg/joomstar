<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelCustomfields extends JModelList
{
	private $_parent = null;
	function __construct()
	{
		parent::__construct();
	}
	
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		
		$app = JFactory::getApplication();
		$extension = 'com_jstar_shop';
		$app = JFactory::getApplication();
		$limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'));
        $this->setState('list.limit', $limit);

        $limitstart = JFactory::getApplication()->input->get('limitstart', '0', 'int');
        $this->setState('list.start', $limitstart);
	}
	/**
	 * Build an SQL query to load the list data.
	 */

	public function getListQuery()
	{ 	
		$db = JFactory::getDBO();
		$fieldid = JFactory::getApplication()->input->get('id', '0', 'int');
		$value = JFactory::getApplication()->input->get('value');
		$fieldid = $db->quote($db->escape($fieldid));
		$value = $db->quote($db->escape($value));
		$query = "SELECT `a`.`product_id` AS `id`,`b`.`img1`,`b`.`title`,`b`.`price`,`b`.`off`,`b`.`multicost`,`b`.`status` FROM `#__jstar_shop_feilds_products` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `b`.`id` = `a`.`product_id` WHERE `a`.`field_id` = $fieldid AND `a`.`values` = $value"; 
		return $query;
	}
	
	public function getCost($pid){
		$db = JFactory::getDBO(); 
		$pid = $db->quote($db->escape($pid));
		$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = $pid ORDER BY `cost2` ASC";
		$db->SetQuery( $query );
		$result = $db->LoadObject();
		return $result;
	}
	
}
