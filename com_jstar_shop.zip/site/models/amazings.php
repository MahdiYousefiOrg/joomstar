<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelAmazings extends JModelList
{
	private $_parent = null;
	function __construct()
	{
		parent::__construct();
	}
	
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		
		$app = JFactory::getApplication();
		$extension = 'com_jstar_shop';
		$app = JFactory::getApplication();
		$limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'));
        $this->setState('list.limit', $limit);
		$limitstart = JFactory::getApplication()->input->get('limitstart', '0', 'int');
        $this->setState('list.start', $limitstart);
	}
	/**
	 * Build an SQL query to load the list data.
	 */

		
	protected function getListQuery()
	{

        // Select the required fields from the table.
		$query = "SELECT `a`.*,`b`.`id`,`b`.`title`,`b`.`img1`,`b`.`off` AS `mainprice`,`b`.`multicost` FROM `#__jstar_shop_amazings` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON find_in_set(`b`.`id`,`a`.`pids`)";
		return $query;
	}
    public function getMulticost($pid)
    {
        $db = JFactory::getDbo();
        $pid = $db->escape($pid);
        $one = $db->escape(1);
        $query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' AND `status` = $one ORDER BY `cost2` ASC";
        $db->SetQuery($query);
        $result = $db->LoadObject();
        return $result;
    }
			
}
