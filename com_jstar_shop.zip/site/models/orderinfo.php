<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelOrderinfo extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			);
		}

		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('a.id', 'asc');

	}

	public function getFactor()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$table = $db->quoteName( '#__jstar_shop_products' );
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$sh = $db->quote($db->escape($sh));
		$one_m = $db->escape(0);
        $query = "SELECT `a`.*,`b`.`title` AS `ptitle`,`b`.`price` AS `pprice`,`b`.`img1`,`b`.`off`,`b`.`multicost`,`a`.`fieldid`,`a`.`typePost`, `a`.`amazing` FROM `#__jstar_shop_orders` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `a`.`product_id` = `b`.`id` WHERE `a`.`sh` = $sh";
		$db->setQuery($query);
		$orders = $db->LoadObjectList(); 
		return $orders;
	}


	public function getCoupon($coupon = NULL){
		$db = $this->getDbo();
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$table = $db->quoteName( '#__jstar_shop_coupons' );
		$cel_percent = $db->quoteName( 'percent' );
		$cel_coupon = $db->quoteName( 'code' );
		$sh = $db->quote($db->escape($sh));
		$coupon = $db->quote($db->escape($coupon));
		$query = "SELECT `a`.`percent` FROM $table AS `a` LEFT JOIN `#__jstar_shop_orders` AS `b` ON `a`.`code` = `b`.`coupon` WHERE `b`.`sh` = $sh AND `b`.`coupon` = $coupon";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}

	public function getUser_coupon(){ 
		$db = $this->getDbo();
		$userid = JFactory::getApplication()->input->get('userid');
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$sh = $db->quote($db->escape($sh));
		$userid = $db->quote($db->escape($userid));
		$query = "SELECT `usercoupon` FROM `#__jstar_shop_orders` WHERE `user_id` = $userid AND `sh` = $sh";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}
	public function getCost($fieldid)
	{
		// Create a new query object.
		$db = $this->getDbo();
		$fieldid = $db->quote($db->escape($fieldid));
		$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = $fieldid";
		$db->SetQuery( $query );
		$result = $db->LoadObject();
		return $result;
	}
	public function getTypepost($typepost)
	{ 
		// Create a new query object.
		$db = $this->getDbo();
		$typepost = $db->quote($db->escape($typepost));
		$query = "SELECT `amount`,`type_post` FROM `#__jstar_shop_posts` WHERE `id` = $typepost"; 
		$db->SetQuery($query);
		$typePost = $db->LoadObject();
		return $typePost;
	}
	public function getGifts($gifts)
	{
		// Create a new query object.
		$db = $this->getDbo();
		$gifts = $db->escape($gifts);
		$query = "SELECT `title`, `price` FROM `#__jstar_shop_gifts` WHERE `id` IN ($gifts)";
		$db->setQuery( $query );
		$giftsid = $db->LoadObjectList();
		return $giftsid;
	}
	
}
