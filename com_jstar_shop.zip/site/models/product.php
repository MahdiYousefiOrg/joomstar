<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelProduct extends JModelItem
{
	private $_parent = null;
	function __construct()
	{
		parent::__construct();
	}
	

	public function getItem()
	{ 	
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$db			= JFactory::getDbo();
		$id = $db->quote( $db->escape( $id ), false );
		$table = $db->quoteName( '#__jstar_shop_products' );
		$cel_id = $db->quoteName( 'id' );
		$query = "UPDATE $table SET `view` = view+1 WHERE $cel_id = $id";
		$db->setQuery($query);
		$db->execute();
		$query = "SELECT * FROM $table WHERE $cel_id = $id"; 
		$db->setQuery($query);
		$faq			= $db->loadObject();
		return $faq;
	}
	
	public function getComments()
	{
		$db				= $this->getDbo();
		$id = JFactory::getApplication()->input->get('id', '0', 'int'); 
		$id = $db->quote( $db->escape( $id ), false );
		$one = $db->escape( 1 );
		$table = $db->quoteName( '#__jstar_shop_comments' );
		$table2 = $db->quoteName( '#__jstar_shop_products' );
		$table3 = $db->quoteName( '#__users' );
		$query = "SELECT `a`.*,`b`.`name` FROM $table AS `a` LEFT JOIN $table3 AS `b` ON `a`.`user_id` = `b`.`id` LEFT JOIN $table2 AS `c` ON `a`.`product_id` = `c`.`id` WHERE `c`.`id` = $id AND `a`.`published` = '$one'";
		$db->setQuery( $query );
		$rows = $db->LoadObjectList(); 
		return $rows;
	}
	public function checkMulticost($pid){
		$db				= $this->getDbo();
		$pid = $db->escape( $pid );
		$query = "SELECT `multicost` FROM `#__jstar_shop_products` WHERE `id` = '$pid'";
		$db->setQuery( $query ); 
		$multicost = $db->LoadResult();
		return $multicost;
	}
	public function getMulticost($pid){
		$db				= $this->getDbo();
		$one = $db->escape( 1 );
		$pid = $db->escape( $pid );
		$query = "SELECT * FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' AND `status` = $one";
		$db->setQuery( $query ); 
		$rows = $db->LoadObjectList();
		return $rows;
	}
	public function getCost($pid){
		$db				= $this->getDbo();
		$pid = $db->escape( $pid );
		$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' ORDER BY `cost2` ASC";
		$db->SetQuery( $query );
		$result = $db->LoadObject();
		return $result;
	}
	public function getColors($pid,$fid){
		$db				= $this->getDbo();
		$pid = $db->escape( $pid );
		$fid = $db->escape( $fid );
	    $query = "SELECT `values` FROM `#__jstar_shop_feilds_products` WHERE `product_id` = '$pid' AND `field_id` = '$fid'";
	    $db->setQuery( $query ); 
	    $colors = $db->LoadResult();
		return $colors;
	}
	public function getMainValue($pid,$fid){
		$db				= $this->getDbo();
		$pid = $db->escape( $pid );
		$fid = $db->escape( $fid );
		$query = "SELECT `values` FROM `#__jstar_shop_feilds_products` WHERE `product_id` = '$pid' AND `field_id` = '$fid'";
		$db->setQuery( $query ); 
		$result = $db->LoadResult();
		return $result;
	}
	public function checkinterest($pid){
		$db				= $this->getDbo();
		$pid = $db->escape( $pid );
		$user = JFactory::getUser();
		$userid = $user->id;
		$query = "SELECT `id` FROM `#__jstar_shop_interests` WHERE `pid` = '$pid' AND `userid` = '$userid'";
		$db->setQuery( $query ); 
		$interest = $db->LoadResult();
		return $interest;
	}	
}
