<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;

class Jstar_shopModelCategory extends JModelList
{
    private $_parent = null;

    function __construct()
    {
        $config['filter_fields'] = array(
            'price'
        );
        parent::__construct();
    }

    protected function populateState($ordering = null, $direction = null)
    {
        // Initialise variables.
        $app = JFactory::getApplication();

        // Adjust the context to support modal layouts.
        if (JFactory::getApplication()->input->get('layout', null, 'string')) {
            $this->context .= '.' . $layout;
        }
        parent::populateState('id', 'DESC');
    }

    protected function getChildeid()
    {
        $db = $this->getDbo();
		$catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $catID = $db->escape($catID);

        $query = "SELECT `node`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` > `parent`.`lft` AND `node`.`lft` < `parent`.`rgt` AND `parent`.`id` = '$catID' ORDER BY `node`.`lft` ";
        $db->setQuery($query);
        $childid = $db->LoadColumn();
        $childid[] = $catID;
        return $childid;
    }

    protected function getChildeid2()
    {
        $db = $this->getDbo();
        $catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $catID = $db->escape($catID);
        $query = "SELECT `node`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `parent`.`id` = '$catID' ORDER BY `node`.`lft` ";
        $db->setQuery($query);
        $childid = $db->LoadColumn();
        $childid[] = $catID;
        return $childid;
    }

    public function getSubcat()
    {
        $db = $this->getDbo();
        $catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $catID = $db->escape($catID);
        $query = "SELECT `level` FROM `#__categories` WHERE `id` = '$catID'";
        $db->setQuery($query);
        $level = $db->LoadResult();


        $catIds = $this->getChildeid();
        if (!empty($catIds)) {
            $level = $level + 1;
            $level = $db->escape($level);
			$catIds = array_map('intval', $catIds);
            $catIds = implode(',', $catIds);
            $catIds = $db->escape($catIds);
            $query = "SELECT `id`,`title`,`params` FROM `#__categories` WHERE `id` IN ($catIds) AND `level` = '$level'";
            $db->setQuery($query);
            $rows = $db->LoadObjectList();
            return $rows;
        } else {
            return false;
        }
    }


    protected function getListQuery()
    {
        $idstr = $this->getChildeid2();
        $db = JFactory::getDBO();
        $idstr = implode(',', $idstr);

        $search = @$_REQUEST['search'];
        if (isset($search)) {
            $_SESSION['search2'] = $search;
        } else {
            unset($_SESSION['search2']);
            unset($search);
        }
		
		$query = Jstar_shop_CHeckupHelper::getMainCategory(@$search,@$idstr);
		$order = JFactory::getApplication()->input->get('filter_order');
        if (isset($order) && $order != NULL && trim($order) != '') {
			$dirn = JFactory::getApplication()->input->get('filter_order_Dir');
            $order = $db->escape($order);
            $dirn = $db->escape($dirn);
            $query .= " ORDER BY `$order` $dirn";
        }
        return $query;
    }


    public function getMeta()
    {
        $catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $db = JFactory::getDbo();
        $catID = $db->quote($db->escape($catID), false);
        $query = "SELECT `metadesc`,`metakey` FROM `#__categories` WHERE `id` = $catID";
        $db->setQuery($query);
        $objectlist = $db->LoadObject();
        return $objectlist;
    }

    public function getCatname()
    {
        $catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $db = JFactory::getDbo();
        $catID = $db->quote($db->escape($catID), false);
        $query = "SELECT `title` FROM `#__categories` WHERE `id` = $catID";
        $db->setQuery($query);
        $ctitle = $db->LoadResult();
        return $ctitle;
    }



    public function getMenutitle()
    {
        $db = JFactory::getDbo();
        $app = JFactory::getApplication();
        $menu = $app->getMenu();
        $item = $menu->getActive();
        @$id = $item->id;
        $id = $db->escape($id);
        $query = "SELECT `title` FROM `#__menu` WHERE `id` = '$id' ";
        $db->setQuery($query);
        @$faq = $db->LoadResult();
        return $faq;
    }

    public function getParentcat()
    {
        $db = JFactory::getDbo();
        $catID = JFactory::getApplication()->input->get('id', '0', 'int');
        $catID = $db->escape($catID);
        $query = "SELECT `parent_id` FROM `#__categories` WHERE `id` = '$catID' ";
        $db->setQuery($query);
        $faq = $db->LoadResult();
        if ($faq == 1) {
            $faq = $catID;
        }
        return $faq;
    }

    public function getMulticost($pid)
    {
        $db = JFactory::getDbo();
        $pid = $db->escape($pid);
        $one = $db->escape(1);
        $query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `pid` = '$pid' AND `status` = $one ORDER BY `cost2` ASC";
        $db->SetQuery($query);
        $result = $db->LoadObject();
        return $result;
    }

}
