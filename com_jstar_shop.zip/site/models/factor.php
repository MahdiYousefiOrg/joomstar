<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelFactor extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			);
		}

		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('a.id', 'asc');

	}

	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$table = $db->quoteName( '#__jstar_shop_products' );
		$arr_pid = @$_SESSION['product'];
		if(isset($arr_pid)) {
			$arr_pid = array_map('intval', $arr_pid);
			$pids = implode(',',$arr_pid);
			$pids = $db->escape( $pids );
			$table = $db->quoteName( '#__jstar_shop_products' );
			$query = "SELECT `id`,`title`,`price`,`img1`,`off`, `w` FROM $table WHERE `id` IN ($pids)";
			$query.=" ORDER BY `id` ASC";
			return $query;
		} else {
			return -1;
		}
	}
	public function getAmazing(){ 
		if(isset($_SESSION['amazing']) && $_SESSION['amazing'] != NULL && $_SESSION['amazing'] != 0){
			$amazingid = $_SESSION['amazing'];
			$db = $this->getDbo();
			$amazingid = array_map('intval', $amazingid);
			$amazingid = $db->escape(implode(',',$amazingid));
			$query = "SELECT * FROM `#__jstar_shop_amazings` WHERE `id` IN ($amazingid)";
			$db->setQuery( $query );
			$rows = $db->LoadObjectList();
			return $rows;
		} else {
			return -1;
		}
	}
	public function getCoupon(){
		$db = $this->getDbo();
		$date = $db->quote($db->escape(date('Y-m-d')));
		@$coupon = JFactory::getApplication()->input->get('coupon');
		@$coupon = $db->quote( $db->escape( $coupon ), false );
		$table = $db->quoteName( '#__jstar_shop_coupons' );
		$cel_percent = $db->quoteName( 'percent' );
		$cel_coupon = $db->quoteName( 'code' );
		$query = "SELECT $cel_percent FROM $table WHERE $cel_coupon = $coupon AND `date1` <= $date AND `date2` >= $date";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}

	public function getUser_coupon(){
		$db = $this->getDbo();
		$user = JFactory::getUser();
		$userid = $db->escape($user->id);
		$table = $db->quoteName( '#__jstar_shop_coupon_users' );
		$cel_percent = $db->quoteName( 'percent' );
		$cel_userid = $db->quoteName( 'userid' );
		$query = "SELECT $cel_percent FROM $table WHERE $cel_userid = $userid";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}
	public function getBank()
	{  
		// Connect db
		$db			= $this->getDbo();
		$folder = $db->escape('jstar_shop_payments');
		$query = "SELECT `name`,`element` FROM #__extensions`` WHERE `folder` = '$folder'";

		$db->setQuery($query);
		$faq			= $db->loadObjectList();

		return $faq;
	}
	public function getGifts($gid,$pid){
		$db = $this->getDbo();
		$pid = $db->escape($pid);
		$gid = $db->escape($gid);
		$query = "SELECT `price` FROM `#__jstar_shop_gifts` WHERE find_in_set($pid,products_id) AND `id` IN ($gid)";
		$db->setQuery( $query );
		$giftsid = $db->LoadColumn();
		return $giftsid;
	}
	public function getCost($pid){ 
		$db = $this->getDbo();
		$pid = $db->escape($pid);
		$one = $db->escape(1);
		$query = "SELECT `b`.`id` FROM `#__jstar_shop_products` AS `a` LEFT JOIN `#__jstar_shop_multicosts` AS `b` ON `a`.`id` = `b`.`pid` WHERE `a`.`id` = '$pid' AND `a`.`multicost` = $one ORDER BY `b`.`cost2` ASC";
		$db->setQuery( $query );
		$fieldid = $db->LoadResult(); 
		if(isset($_SESSION['multicost'][$pid]) && $_SESSION['multicost'][$pid] != NULL && trim($_SESSION['multicost'][$pid]) != ''){ 
			$fieldid = $_SESSION['multicost'][$pid];
			$fieldid = $db->escape($fieldid);
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
		} 
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (isset($fieldid) && $fieldid !=0 && $fieldid != NULL && trim($fieldid) != '')){ 
			$fieldid = $db->escape($fieldid);
			$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
			$db->SetQuery( $query );
			$result = $db->LoadObject();
		}
		if((!isset($_SESSION['multicost'][$pid]) || $_SESSION['multicost'][$pid] == NULL || trim($_SESSION['multicost'][$pid]) == '') && (!isset($fieldid) || $fieldid == 0 || $fieldid == NULL || trim($fieldid) == '')){ 
			$result = new stdClass();
			$result->cost2 = -1;
		}
		return $result;
	}
	public function getPost($type_post){
		$db = $this->getDbo();
		$type_post = $db->escape($type_post);
		$query = "SELECT `amount` FROM `#__jstar_shop_posts` WHERE `id` = '$type_post'";
		$db->SetQuery($query);
		$costPost = $db->LoadResult();
		return $costPost;
	}
}
