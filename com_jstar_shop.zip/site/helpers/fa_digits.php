<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shop_Fa_digits extends JHelperContent
{
	static function fa_digits($text){
		$lang = JFactory::getLanguage();
		$lang = $lang->getTag();
		if($lang == 'fa-IR'){
			$persian_digits = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
		} else {
			$persian_digits = array('0','1','2','3','4','5','6','7','8','9');
		}
		$english_digits = array('0','1','2','3','4','5','6','7','8','9');
		$text = str_replace($english_digits, $persian_digits, $text);
		return $text;
	}

}
