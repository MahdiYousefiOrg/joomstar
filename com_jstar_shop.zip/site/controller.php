<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;

class Jstar_shopController extends JControllerLegacy
{
	public function display($cachable = false, $urlparams = false)
	{
		$vName = JFactory::getApplication()->input->get('view', 'categories', 'string');
		JFactory::getApplication()->input->set('view',$vName);
		
		return parent::display($cachable, $urlparams);
	}
}
