<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopControllerMulticost extends JControllerForm
{ 
	public function add(){
		$pid = JFactory::getApplication()->input->get('pid', 0, 'int');
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicost&layout=edit&pid='.$pid ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_MULTI_COST_DO").$ptitle);
	}
	public function edit($key = NULL, $urlVar = NULL){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$cids = JFactory::getApplication()->input->get('cid', null, 'array');
		$id = $cids[0];
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicost&layout=edit&pid='.$pid.'&id='.$id ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_MULTI_COST_DO").$ptitle);
	}
	public function cancel($key = NULL){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicosts&&pid='.$pid ,false);
		$this->setRedirect( $redirectTo );
	}
	public function apply2(){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$id = $db->escape($id);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$data = JFactory::getApplication()->input->post->get('jform', array(), 'array');
		$values = '';
		foreach($data as $index =>$value){
			if(strpos($index,'field_') !== false){
				$values.=substr($index,6).':'.$value.'-';
			}
		}
		if($values != ''){
			$values = substr($values,0,-1);
		}
		$values = $db->escape($values);
		$data[cost1] = $db->escape($data[cost1]);
		$data[cost2] = $db->escape($data[cost2]);
		$data[status] = $db->escape($data[status]);
		if(isset($id) && $id != NULL && trim($id) != '' && $id != 0){
			$query = "UPDATE `#__jstar_shop_multicosts` SET `values` = '$values', `cost1` = '$data[cost1]', `cost2` = '$data[cost2]', `status` = '$data[status]' WHERE `id` = '$id'";
			$db->SetQuery( $query );
			$db->execute();
		} else {
			$query = "INSERT INTO `#__jstar_shop_multicosts` (`id`,`pid`,`values`,`cost1`,`cost2`, `status`, `ordering`) VALUES (NULL, '$pid', '$values', '$data[cost1]', '$data[cost2]', '$data[status]', 0)"; 
			$db->SetQuery( $query );
			$db->execute();
			$id = $db->insertid();
		}
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicost&layout=edit&pid='.$pid.'&id='.$id ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED") );
	}
	public function save2(){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$id = $db->escape($id);
		
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$data = JFactory::getApplication()->input->post->get('jform', array(), 'array');
		$values = '';
		foreach($data as $index =>$value){
			if(strpos($index,'field_') !== false){
				$values.=substr($index,6).':'.$value.'-';
			}
		}
		if($values != ''){
			$values = substr($values,0,-1);
		}
		$values = $db->escape($values);
		$data[cost1] = $db->escape($data[cost1]);
		$data[cost2] = $db->escape($data[cost2]);
		$data[status] = $db->escape($data[status]);
		if(isset($id) && $id != NULL && trim($id) != '' && $id != 0){
			$query = "UPDATE `#__jstar_shop_multicosts` SET `values` = '$values', `cost1` = '$data[cost1]', `cost2` = '$data[cost2]', `status` = '$data[status]' WHERE `id` = '$id'";
			$db->SetQuery( $query );
			$db->execute();
		} else {
			$query = "INSERT INTO `#__jstar_shop_multicosts` (`id`,`pid`,`values`,`cost1`,`cost2`, `status`, `ordering`) VALUES (NULL, '$pid', '$values', '$data[cost1]', '$data[cost2]', '$data[status]', 0)"; 
			$db->SetQuery( $query );
			$db->execute();
			$id = $db->insertid();
		}
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicosts&pid='.$pid ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED") );
	}
	public function save2new2(){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$id = $db->escape($id);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$data = JFactory::getApplication()->input->post->get('jform', array(), 'array');
		$values = '';
		foreach($data as $index =>$value){
			if(strpos($index,'field_') !== false){
				$values.=substr($index,6).':'.$value.'-';
			}
		}
		if($values != ''){
			$values = substr($values,0,-1);
		}
		$values = $db->escape($values);
		$data[cost1] = $db->escape($data[cost1]);
		$data[cost2] = $db->escape($data[cost2]);
		$data[status] = $db->escape($data[status]);
		if(isset($id) && $id != NULL && trim($id) != '' && $id != 0){
			$query = "UPDATE `#__jstar_shop_multicosts` SET `values` = '$values', `cost1` = '$data[cost1]', `cost2` = '$data[cost2]', `status` = '$data[status]' WHERE `id` = '$id'";
			$db->SetQuery( $query );
			$db->execute();
		} else {
			$query = "INSERT INTO `#__jstar_shop_multicosts` (`id`,`pid`,`values`,`cost1`,`cost2`, `status`, `ordering`) VALUES (NULL, '$pid', '$values', '$data[cost1]', '$data[cost2]', '$data[status]', 0)"; 
			$db->SetQuery( $query );
			$db->execute();
			$id = $db->insertid();
		}
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicost&layout=edit&pid='.$pid ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED") );
	}
}
