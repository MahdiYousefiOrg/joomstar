<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopControllerSimilar extends JControllerForm
{ 
	public function getModel($name = 'similar', $prefix = 'Jstar_shopModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function addproducts(){
		$cids = JFactory::getApplication()->input->get('cid', null, 'array');
		$model = $this->getModel();
		$model->addproducts($cids);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=similars',false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_PRODUCTS_ADDED"));
	}
}
