<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerCits extends JControllerAdmin
{
	public function __construct($config = array())
	{ 
		parent::__construct($config); 
	}
	public function getModel($name = 'cit', $prefix = 'Jstar_shopModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function saveOrderAjax()
	{
	$input = JFactory::getApplication()->input;
	$pks = $input->post->get('cid', array(), 'array');
	$order = $input->post->get('order', array(), 'array');
	JArrayHelper::toInteger($pks);
	JArrayHelper::toInteger($order);
	$model = $this->getModel();
	$return = $model->saveorder($pks, $order);
	if ($return)
	{
	echo "1";
	}
	JFactory::getApplication()->close();
	}
}
