<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopControllerCit extends JControllerForm
{ 
	public function apply2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$id = $model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cit&layout=edit&id='.$id ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
	public function save2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cits' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
	public function save2new2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=cit&layout=edit' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
}
