<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopControllerProduct extends JControllerForm
{ 
	public function apply2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$id = $model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=product&layout=edit&id='.$id ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
	public function save2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=products' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
	public function save2new2() {
     	$data = JFactory::getApplication()->input->get('jform', array(), 'array');
		$model = $this->getModel();
		$model->apply2($data);
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=product&layout=edit' ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_SAVED"));
	}
	public function multi() { 
		$cids = JFactory::getApplication()->input->get('cid', null, 'array');
		$pid = $cids[0];
		$db = JFactory::getDBO();
		$pid = $db->escape($pid);
		$query = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$pid'";
		$db->SetQuery($query);
		$catid = $db->LoadResult();

		$idstr = $this->getparents($catid); 
		$idstr = array_map('intval', $idstr);
		$idstr = implode(',',$idstr); 
		$query = "SELECT `id` FROM `#__jstar_shop_customfields` WHERE `catid` IN ($idstr) AND multi = 1"; 
		$db->setQuery( $query );
		$rows = $db->LoadColumn();
		if(empty($rows)){
			$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=products' ,false);
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_NO_PRO_MULTI_FIELD"));
		} else {
			$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
			$db->SetQuery($query);
			$ptitle = $db->LoadResult();
			$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicosts&pid='.$pid ,false);
			$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_MULTI_COST_LIST").$ptitle);
		}
	}
	public function getparents($catID){
		$db = JFactory::getDBO();
		$catID = $db->escape($catID);
		$query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` ";
		$db->setQuery( $query );
		$parentid = $db->LoadColumn();
		return $parentid;
	}
}
