<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopControllerMulticosts extends JControllerAdmin
{
	public function getModel($name = 'multicost', $prefix = 'Jstar_shopModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}
	public function saveOrderAjax()
	{
	$input = JFactory::getApplication()->input;
	$pks = $input->post->get('cid', array(), 'array');
	$order = $input->post->get('order', array(), 'array');
	JArrayHelper::toInteger($pks);
	JArrayHelper::toInteger($order);
	$model = $this->getModel();
	$return = $model->saveorder($pks, $order);
	if ($return)
	{
	echo "1";
	}
	JFactory::getApplication()->close();
	}
	public function delete(){
		$pid = JFactory::getApplication()->input->get('pid', '0', 'int');
		$db = JFactory::getDBO();
		$cids = JFactory::getApplication()->input->get('cid', null, 'array');
		$cids = array_map('intval', $cids);
		$query4 = ' DELETE FROM `#__jstar_shop_multicosts` WHERE `id` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query4 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting comments'), 'error');
		}
		$pid = $db->escape($pid);
		$query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` = '$pid'"; 
		$db->SetQuery($query);
		$ptitle = $db->LoadResult();
		$redirectTo = JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=multicosts&&pid='.$pid ,false);
		$this->setRedirect( $redirectTo, JText::_("COM_JSTAR_SHOP_DELETED") );
	}
}
