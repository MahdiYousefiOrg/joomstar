<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelProducts_amazings  extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
					'ordering','products.ordering',
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
		
		$catsearch = $this->getUserStateFromRequest($this->context.'.filter.categoryid', 'filter_categoryid');
		$this->setState('filter.categoryid', $catsearch);
		
		parent::populateState('products.ordering', 'ASC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);
			@$id = JFactory::getApplication()->input->get('id', '0', 'int');
			@$form = JFactory::getApplication()->input->get('form', null, 'string');
			if(!isset($form)){
			unset($_SESSION['amazing']);
			}
			if((isset($id) && $id != 0 && $id != NULL && trim($id) != '')){ 
					$id = $db->escape($id);
					$query2 = "SELECT `pids` FROM `#__jstar_shop_amazings` WHERE `id` = '$id'";
					$db->setQuery( $query2 );
					$pids = $db->LoadResult();
					$pids = explode(',',$pids);
					foreach($pids as $pid){
						$_SESSION['amazing'][$pid] = 1;
					}
			} if((!isset($id) || $id == 0 || $id == NULL || trim($id) == '') && !isset($form)) {
				unset($_SESSION['amazing']);
			}

		// Select the required fields from the table.
				
			$query->select( '`products`.*' );
			$query->from( '`#__jstar_shop_products` as `products`' );
			$query->select('`b`.`title` AS `category`')
				 ->join('LEFT', '`#__categories` AS `b` on `b`.`id` = `products`.`catid`');
    	// Filter by search in title
    	$search = $this->getState('filter.search');
    	if (!empty($search)) {
    			$search = $db->Quote('%'.$db->escape($search, true).'%');
    			$query->where('(
    					`products`.`title` LIKE '.$search.'
						OR `products`.`price` LIKE '.$search.'
    			)');
    		}
			
		$catsearch			= $this->getState('filter.categoryid');
		if ($catsearch !='' ) {
				$catsearch = $db->quote($db->escape($catsearch, true));
				$query->where('`catid` = '.$catsearch);
		} 
		
			
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
}
?>
