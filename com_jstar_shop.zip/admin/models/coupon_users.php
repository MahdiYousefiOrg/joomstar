<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelCoupon_users extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
				'ordering','coupon_users.ordering',
				'name','b.name',
				'percent','coupon_users.percent'
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
				
		parent::populateState('coupon_users.ordering', 'ASC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
				
			$query->select( '`coupon_users`.*' );
			$query->from( '`#__jstar_shop_coupon_users` as `coupon_users`' );
			$query->select('`b`.`name` AS `name`')
				 ->join('LEFT', '`#__users` AS `b` on `b`.`id` = `coupon_users`.`userid`');
    	// Filter by search in title
    	$search = $this->getState('filter.search');
    	if (!empty($search)) {
    			$search = $db->Quote('%'.$db->escape($search, true).'%');
    			$query->where('(
    					`coupon_users`.`percent` LIKE '.$search.'
						OR `b`.`name` LIKE '.$search.'
    			)');
    		}
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
}
?>
