<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelUser extends JModelAdmin
{
	public function getTable($type = 'users', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.user', 'user', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.user.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}
	
	
	public function delete2($cids) {
		$db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
		$query = 'SELECT `user_id` FROM `#__jstar_shop_users` WHERE `id` IN (' . implode( ',', $cids ) . ') '; 
		$db->setQuery( $query );
		$userids = $db->LoadColumn();
		$userids = array_map('intval', $userids);
		$query2 = ' DELETE FROM `#__jstar_shop_comments` WHERE `user_id` IN (' . implode( ',', $userids ) . ') ';
		$db->setQuery( $query2 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting comments'), 'error');
		}
		$query3 = ' DELETE FROM `#__jstar_shop_coupon_users` WHERE `userid` IN (' . implode( ',', $userids ) . ') ';
		$db->setQuery( $query3 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error coupon fields'), 'error');
		}
		$query4 = ' DELETE FROM `#__jstar_shop_orders` WHERE `user_id` IN (' . implode( ',', $userids ) . ') ';
		$db->setQuery( $query4 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting orders'), 'error');
		}
		$query5 = ' DELETE FROM `#__jstar_shop_users` WHERE `id` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query5 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting users'), 'error');
		}
		$query6 = ' DELETE FROM `#__users` WHERE `id` IN (' . implode( ',', $userids ) . ') ';
		$db->setQuery( $query6 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting users'), 'error');
		}
	}
}
