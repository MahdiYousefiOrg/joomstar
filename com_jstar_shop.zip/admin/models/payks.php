<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelPayks extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
				'ordering','payks.ordering',
				'code','payks.code',
				'name_family','payks.name_family',
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
				
		parent::populateState('payks.ordering', 'ASC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
				
			$query->select( '`payks`.*' );
			$query->from( '`#__jstar_shop_payks` as `payks`' );
    	// Filter by search in title
    	$search = $this->getState('filter.search');
    	if (!empty($search)) {
    			$search = $db->Quote('%'.$db->escape($search, true).'%');
    			$query->where('(
    					`payks`.`code` LIKE '.$search.'
						OR `payks`.`name_family` LIKE '.$search.'
    			)');
    		}
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
}
?>
