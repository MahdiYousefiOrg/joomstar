<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelPost extends JModelAdmin
{
	public function getTable($type = 'posts', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.post', 'post', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.post.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		} 

		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}

	public function apply2($data) {
		$db = JFactory::getDBO();
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$data['cits'] = array_map('intval', $data['cits']);
		$cits = implode(',',$data['cits']);
		$data[title] = $db->escape($data[title]);
		$data[type_post] = $db->escape($data[type_post]);
		$data[price1] = $db->escape($data[price1]);
		$data[price2] = $db->escape($data[price2]);
		$data[w1] = $db->escape($data[w1]);
		$data[w2] = $db->escape($data[w2]);
		$data[amount] = $db->escape($data[amount]);
		$data[comment] = $db->escape($data[comment]);
		if(!isset($id) || $id == 0 || $id == NULL || trim($id) == ''){ 
			$query = "INSERT INTO `#__jstar_shop_posts` (`id`,`title`,`type_post`,`cits`, `price1`, `price2`, `w1`, `w2`, `amount`, `comment`, `ordering`) VALUES (NULL, '$data[title]', '$data[type_post]', '$cits', '$data[price1]', '$data[price2]', '$data[w1]', '$data[w2]', '$data[amount]', '$data[comment]', 0)";
			$db->setQuery( $query );
			$db->execute();
			$id = $db->insertid();

		} else{
			$id = $db->escape($id);
			$query = "UPDATE `#__jstar_shop_posts` SET `title` = '$data[title]', `type_post` = '$data[type_post]', `cits` = '$cits', `price1` = '$data[price1]', `price2` = '$data[price2]', `w1` = '$data[w1]', `w2` = '$data[w2]', `amount` = '$data[amount]', `comment` = '$data[comment]' WHERE `id` = '$id'";
			$db->setQuery( $query );
			$db->execute();
		}
		return $id;
	}
}
