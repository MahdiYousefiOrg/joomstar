<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelValues extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	public function getValues()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);
			$session = JFactory::getSession();
			$fieldid = $session->get('fieldid');

		// Select the required fields from the table.
				
			$query->select( '`fields`.`value`' );
			$query->from( '`#__jstar_shop_customfields` as `fields`' );
			$query->where('`id` = '.$fieldid);
			$db->setQuery($query);
			$rows = $db->LoadResult();
			return $rows;
	}
	
}
?>
