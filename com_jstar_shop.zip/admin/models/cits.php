<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class Jstar_shopModelCits extends JModelList
{
    public function __construct($config = array())
    {
        $config['filter_fields'] = array(
            'ordering', 'a.ordering',

        );
        parent::__construct($config);
    }

    protected function populateState($ordering = null, $direction = null)
    {
        // Initialise variables.
        $app = JFactory::getApplication();

        // Adjust the context to support modal layouts.
        if (JFactory::getApplication()->input->get('layout', null, 'string')) {
            $this->context .= '.' . $layout;
        }
        $cit = $this->getUserStateFromRequest($this->context . '.filter.cit', 'filter_cit');
        $this->setState('filter.cit', $cit);


        parent::populateState('a.ordering', 'ASC');
    }

    /**
     * Build an SQL query to load the list data.
     */

    public function getQuery2()
    {
        // Create a new query object.
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        // Select the required fields from the table.

        $query = "SELECT `a`.`city` AS `text`, `a`.`id` AS `value`, `a`.`parentid` as `parentid`,`a`.`level` AS `level` FROM `#__jstar_shop_cits` AS `a`";
        $cit = $this->getState('filter.cit');
        if ($cit != '') {
            $cit = $db->escape($cit);
            $query = "SELECT `id` AS `value`,`city` AS `text`, `parentid` AS `parentid`, `level` AS `level` FROM `#__jstar_shop_cits` WHERE `parentid` = '$cit' 
					UNION 
					SELECT `id` AS `value`,`city` AS `text`, `parentid` AS `parentid`, `level` AS `level` FROM `#__jstar_shop_cits` WHERE `parentid` IN 
					(SELECT `id` FROM `#__jstar_shop_cits` WHERE `parentid` = '$cit')";
            $db->setQuery($query);
            $parentss = $db->loadObjectList();
            return $parentss;
        }
        $db->setQuery($query);
        $parentss = $db->loadObjectList();
        $tree = array();
        $text = '';
        $tree = $this->ParentTreeOption($parentss, $tree, 0, $text, 1);
        return $tree;
    }

    public function ParentTreeOption($data, $tree, $id = 0, $text = '', $currentId)
    {

        foreach ($data as $key) {
            $show_text = $text . $key->text;

            if ($key->parentid == $id) {
                $tree[$key->value] = new JObject();
                $tree[$key->value]->text = $show_text;
                $tree[$key->value]->value = $key->value;
                $tree[$key->value]->level = $key->level;
                $tree = $this->ParentTreeOption($data, $tree, $key->value, $show_text . " --> ", $currentId);
            }
        }
        return ($tree);
    }

    public function getSubcits()
    {
        $db = $this->getDbo();
		$parentcit = JFactory::getApplication()->input->get('parentcit', '', 'string');
        $parentcit = $db->escape($parentcit);
        $query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` = '$parentcit' 
		UNION 
		SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` IN 
	    (SELECT `id` FROM `#__jstar_shop_cits` WHERE `parentid` = '$parentcit')";
        $db->setQuery($query);
        $subcits = $db->loadObjectList();

        $query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `id` = '$parentcit'";
        $db->setQuery($query);
        $row = $db->LoadObject();
        $subcits[] = $obj = new stdClass;
        $obj->id = $row->id;
        $obj->city = $row->city;

        return $subcits;
    }

    public function getCits_level()
    {
        $db = $this->getDbo();

        $query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `level` = '1'";
        $db->setQuery($query);
        $cit_level = $db->loadObjectList();

        return $cit_level;
    }

}

?>
