<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelOrders extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
				'name','b.name',
				'product','c.title',
				'count2','orders.count2',
				'percent','orders.percent',
				'amount','orders.amount',
				'date2','orders.date2'
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
			
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
		
		$payk = $this->getUserStateFromRequest($this->context.'.filter.payk', 'filter_payk');
		$this->setState('filter.payk', $payk);
				
				
		parent::populateState('orders.id', 'DESC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);
			$status = JFactory::getApplication()->input->get('status', null, 'array');
			if(!empty($status)){
				$status = array_map('intval', $status);
				foreach($status as $index => $value){
					$value = $db->escape($value);
					$query = "UPDATE `#__jstar_shop_order_details` SET `status` = '$value' WHERE `sh_order` = '$index'";
					$db->setQuery( $query );
					$db->execute();
				}
			}
			$payments = JFactory::getApplication()->input->get('payments', null, 'array');
			if(!empty($payments)){
				$payments = array_map('intval', $payments);
				foreach($payments as $index => $value){
					$value = $db->escape($value);
					$query = "UPDATE `#__jstar_shop_order_details` SET `payment_method` = '$value' WHERE `sh_order` = '$index'";
					$db->setQuery( $query );
					$db->execute();
				}
			}
			$payks = JFactory::getApplication()->input->get('payks', null, 'array');
			if(!empty($payks)){
				$payks = array_map('intval', $payks);
				foreach($payks as $index => $value){
					if($value != -1){
						$query = "INSERT INTO `#__jstar_shop_payks_orders` (`factor`,`payk_id`) VALUES ('$index','$value') ON DUPLICATE KEY UPDATE `payk_id` = '$value'";
						$db->setQuery( $query );
						$db->execute();
					} else {
						$query = "DELETE FROM `#__jstar_shop_payks_orders` WHERE `factor` = '$index'";
						$db->setQuery( $query );
						$db->execute();
					}
				}
			}

		// Select the required fields from the table.
				
			$query = "SELECT `a`.`sh`, `a`.`user_id`, `a`.`date2`, `b`.`name`, `c`.`status`, `c`.`payment_method`, `d`.`title` FROM `#__jstar_shop_orders` AS `a` LEFT JOIN `#__jstar_shop_order_details` AS `c` ON `a`.`sh` = `c`.`sh_order` LEFT JOIN `#__jstar_shop_products` AS `d` ON `a`.`product_id` = `d`.`id` LEFT JOIN `#__users` AS `b` ON `a`.`user_id` = `b`.`id` LEFT JOIN `#__jstar_shop_payks_orders` AS `e` ON `a`.`sh` = `e`.`factor`  WHERE 1=1";
			$search = $this->getState('filter.search');
			if (!empty($search)) {
					$search = $db->Quote('%'.$db->escape($search, true).'%');
					$query.=" AND `d`.`title` LIKE ".$search;
					$query.=" OR `b`.`name` LIKE ".$search;
				} 
			$payk = $this->getState('filter.payk');
			if (!empty($payk)) {
					$payk = $db->escape($payk, true);
					$query.=" AND `e`.`payk_id` = '$payk'";
				} 
			$query.=" GROUP BY `a`.`sh` ORDER BY `a`.`id` DESC"; 
			return $query;
	}
	public function delete2($cids) {
		$db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
		$query2 = ' DELETE FROM `#__jstar_shop_orders` WHERE `sh` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query2 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting products:'), 'error');
		}
		$query2 = ' DELETE FROM `#__jstar_shop_order_details` WHERE `sh_order` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query2 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting products'), 'error');
		}
	}
}
?>
