<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class Jstar_shopModelComments extends JModelList
{
    public function __construct($config = array())
    {
        $config['filter_fields'] = array(
            'name', 'b.name',
            'comment', 'a.comment'
        );
        parent::__construct($config);
    }

    protected function populateState($ordering = null, $direction = null)
    {
        // Initialise variables.
        $app = JFactory::getApplication();

        // Adjust the context to support modal layouts.
        if (JFactory::getApplication()->input->get('layout', null, 'string')) {
            $this->context .= '.' . $layout;
        }

        parent::populateState('a.id', 'ASC');
    }

    /**
     * Build an SQL query to load the list data.
     */

    protected function getListQuery()
    {
        // Create a new query object.
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $id = $db->escape($id);
        // Select the required fields from the table.

        $query->select('`a`.*');
        $query->from('`#__jstar_shop_comments` as `a`');
        $query->select('`b`.`name` AS `name`')
            ->join('LEFT', '`#__users` AS `b` on `a`.`user_id` = `b`.`id`');
        $query->where('(
					`a`.`product_id` = ' . $id . '
			)');
        $orderCol = $this->state->get('list.ordering');
        $orderDirn = $this->state->get('list.direction');
        $query->order($db->escape($orderCol . ' ' . $orderDirn));
        return $query;
    }

    public function delete($cids)
    {
        $db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
        $query = ' DELETE FROM `#__jstar_shop_comments` WHERE `id` IN (' . implode(',', $cids) . ') ';
        $db->setQuery($query);
        if (!$db->query()) {
            $errorMessage = $this->getDBO()->getErrorMsg();
            JFactory::getApplication()->enqueueMessage(JText::_('Error deleting comments'), 'error');
        }
    }

    public function publish($cids)
    {
        $db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
        $query = "UPDATE `#__jstar_shop_comments` SET `published` = '1' WHERE `id` IN (" . implode(',', $cids) . ") ";
        $db->setQuery($query);
        if (!$db->query()) {
            $errorMessage = $this->getDBO()->getErrorMsg();
            JFactory::getApplication()->enqueueMessage(JText::_('Error published comments'), 'error');
        }
    }

    public function unpublish($cids)
    {
        $db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
        $query = "UPDATE `#__jstar_shop_comments` SET `published` = '0' WHERE `id` IN (" . implode(',', $cids) . ") ";
        $db->setQuery($query);
        if (!$db->query()) {
            $errorMessage = $this->getDBO()->getErrorMsg();
            JFactory::getApplication()->enqueueMessage(JText::_('Error unpublished comments'), 'error');
        }
    }
}

?>
