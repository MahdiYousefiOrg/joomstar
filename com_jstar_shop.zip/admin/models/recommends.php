<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelRecommends extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
				'ordering','recommends.ordering',
				'name_family','recommends.name_family',
				'date','recommends.date'
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
				
		parent::populateState('recommends.id', 'DESC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
				
			$query->select( '`recommends`.*' );
			$query->from( '`#__jstar_shop_recommends` as `recommends`' );
    	// Filter by search in title
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
}
?>
