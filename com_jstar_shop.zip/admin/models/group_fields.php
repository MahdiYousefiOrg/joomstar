<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelGroup_fields extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
					'ordering','group_fields.ordering',
					'category','b.title',
					'title','group_fields.title'
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);
		
		$catsearch = $this->getUserStateFromRequest($this->context.'.filter.categoryid', 'filter_categoryid');
		$this->setState('filter.categoryid', $catsearch);
		
		
		parent::populateState('group_fields.ordering', 'ASC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{ 
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
				
			$query->select( '`group_fields`.*' );
			$query->from( '`#__jstar_shop_group_fields` as `group_fields`' );
			$query->select('`b`.`title` AS `category`')
				 ->join('LEFT', '`#__categories` AS `b` on `b`.`id` = `group_fields`.`catid`');
    	// Filter by search in title
    	$search = $this->getState('filter.search');
    	if (!empty($search)) {
    			$search = $db->Quote('%'.$db->escape($search, true).'%');
    			$query->where('(
    					`group_fields`.`title` LIKE '.$search.'
    			)');
    		}
			
		$catsearch			= $this->getState('filter.categoryid');
		if ($catsearch !='' ) {
				$catsearch = $db->quote($db->escape($catsearch, true));
				$query->where('`catid` = '.$catsearch);
		} 
		
			
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
	
 public function getparents($catid )
    {
		$db				= $this->getDbo();
		$categories = JCategories::getInstance('jstar_shop');
		$category = $categories->get($catid);
		$p = $category->getParent()->id; 
		if($p != 'root'){
			$parentid[] = $p;
		} else {
			$parentid[] = $catid ;
		} 
		while($p != 'root'){
			$category = $categories->get($p);
			$p = $category->getParent()->id;
			if($p != 'root'){
				$parentid[] = $p;
			}
		} 
		$parentid[] = $catid;
        return $parentid;
    }
	
	public function getGroupfields(){ 
		$db				= $this->getDbo();
		$catID = JFactory::getApplication()->input->get('catid');
		$idstr = $this->getparents($catID );
		$idstr = array_map('intval', $idstr);
		$idstr = implode(',',$idstr);
		$query = "SELECT * FROM `#__jstar_shop_group_fields` WHERE `catid` IN ($idstr)"; 
		$db->setQuery( $query );
		$rows = $db->LoadObjectList();
		return $rows;
	}
}
?>
