<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelPrice_category extends JModelAdmin
{
	public function getTable($type = 'price_categories', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.price_category', 'price_category', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.price_category.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}

	public function apply2($data) {
		$db = JFactory::getDBO();
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		if(!isset($id) || $id == 0 || $id == NULL || trim($id) == ''){
			$data[catid] = $db->escape($data[catid]);
			$data[type] = $db->escape($data[type]);
			$data[value] = $db->escape($data[value]);
			$query = "INSERT INTO `#__jstar_shop_price_categories` (`id`,`catid`,`type`,`value`) VALUES (NULL,'$data[catid]','$data[type]',$data[value])";
			$db->setQuery( $query );
			$db->execute();
			
			$query_id = "SELECT `id` FROM `#__jstar_shop_price_categories` ORDER BY `id` DESC";
			$db->setQuery( $query_id );
			$id = $db->LoadResult();
			
			$catID = $data['catid'];
			$query="SELECT `node`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `parent`.`id` = '$catID' ORDER BY `node`.`lft` ";
			$db->setQuery( $query );
			$childid = $db->LoadColumn();
			$childid[] = $data['catid'];
			$childid = array_map('intval', $childid);
			$childid = implode(',',$childid);
			
			
			
			
			if($data['type']==2){
				$query = "UPDATE `#__jstar_shop_multicosts` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `a`.`pid` = `b`.`id` SET `a`.`cost1` = (a.cost1+a.cost1*$data[value]/100), `a`.`cost2` = (a.cost2+a.cost2*$data[value]/100) WHERE `b`.`catid` IN ($childid) AND `b`.`multicost` = '1'";
				$query_update = "UPDATE `#__jstar_shop_products` SET `price` = (price+price*$data[value]/100), `off` = (off+off*$data[value]/100) WHERE `catid` IN ($childid) AND (`multicost` != 1)";
			} elseif($data['type']==1) {
				$query = "UPDATE `#__jstar_shop_multicosts` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `a`.`pid` = `b`.`id` SET `a`.`cost1` = (a.cost1+$data[value]), `a`.`cost2` = (a.cost2+$data[value]) WHERE `b`.`catid` IN ($childid) AND `b`.`multicost` = '1'";
				$query_update = "UPDATE `#__jstar_shop_products` SET `price` = (price+$data[value]), `off` = (off+$data[value]) WHERE `catid` IN ($childid) AND (`multicost` != 1)";
			}
			$db->setQuery( $query );
			$db->execute();
			$db->setQuery( $query_update );
			$db->execute();
			return $id;
		} 
	}
	
}
