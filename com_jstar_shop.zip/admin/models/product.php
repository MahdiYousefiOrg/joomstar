<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelProduct extends JModelAdmin
{
	public function getTable($type = 'products', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.product', 'product', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.product.data', array());

		if (empty($data))
		{ 
			$data = $this->getItem();
			// Prime some default values.
		}
		
		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}

	
	public function apply2($data) {
		$db = JFactory::getDBO();
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');
		$params = JComponentHelper::getParams('com_jstar_shop');
		$data['posts'] = array_map('intval', $data['posts']);
		$posts = implode(',',$data['posts']);
		$date = date('Y-m-d');
		$data[catid] = $db->escape($data[catid]);
		$data[title] = $db->escape($data[title]);
		$data[multicost] = $db->escape($data[multicost]);
		$data[price] = $db->escape($data[price]);
		$data[off] = $db->escape($data[off]);
		$data[img1] = $db->escape($data[img1]);
		$data[img2] = $db->escape($data[img2]);
		$data[img3] = $db->escape($data[img3]);
		$data[img4] = $db->escape($data[img4]);
		$data[text2] = $db->escape($data[text2]);
		$data[metadesc] = $db->escape($data[metadesc]);
		$data[metakey] = $db->escape($data[metakey]);
		$data[status] = $db->escape($data[status]);
		$data[published] = $db->escape($data[published]);
		$data[size] = $db->escape($data[size]);
		$data[w] = $db->escape($data[w]);
		$data[posts] = $db->escape($data[posts]);
		$data[tag1] = $db->escape($data[tag1]);
		$data[tag2] = $db->escape($data[tag2]);
		$data[counttag] = $db->escape($data[counttag]);
		$data[best] = $db->escape($data[best]);
		if(!isset($id) || $id == 0 || $id == NULL || trim($id) == ''){ 
			$query = "INSERT INTO `#__jstar_shop_products` (`id`,`catid`,`title`,`multicost`, `price`,`off`,`img1`,`img2`,`img3`,`img4`,`text2`,`metadesc`,`metakey`,`status`,`published`, `size`, `w`, `posts`, `tag1`, `tag2`, `counttag`, `date`, `best`, `ordering`) VALUES (NULL,'$data[catid]','$data[title]','$data[multicost]','$data[price]','$data[off]','$data[img1]','$data[img2]','$data[img3]','$data[img4]','$data[text2]','$data[metadesc]','$data[metakey]','$data[status]','$data[published]', '$data[size]', '$data[w]', '$posts', '$data[tag1]', '$data[tag2]', '$data[counttag]', '$date', '$data[best]' ,0)";
			$db->setQuery( $query );
			$db->execute();
///--------------------------- CUSTOM FIELDS
			$query_id = "SELECT `id` FROM `#__jstar_shop_products` ORDER BY `id` DESC";
			$db->setQuery( $query_id );
			$id = $db->LoadResult();
			
			$rows = Jstar_shop_CHeckupHelper::getFields($id);

			$k=0;
			foreach($rows as $row){
				$field_id = $row->id;
				if($row->type != 4 && $row->type != 5){
					$value = $data['field'.$k];
				} else {
					$data['field'.$k] = array_filter($data['field'.$k]);
					$value = implode(',',$data['field'.$k]);
				}
				$query_insert = "INSERT INTO `#__jstar_shop_feilds_products` (`id`,`product_id`,`field_id`,`values`) VALUES (NULL,'$id','$field_id','$value')";
				$db->setQuery( $query_insert );
				$db->execute();
				$k++;
			}
			return $id;
		} else {
			$id = $db->escape($id);
			$query2 = "UPDATE `#__jstar_shop_products` SET `title` = '$data[title]', `multicost` = '$data[multicost]', `price` = '$data[price]', `off` = '$data[off]', `img1` = '$data[img1]',`img2` = '$data[img2]',`img3` = '$data[img3]',`img4` = '$data[img4]', `text2` = '$data[text2]', `metadesc`='$data[metadesc]', `status` = '$data[status]', `metakey`= '$data[metakey]',  `published` = '$data[published]', `size` = '$data[size]', `w` = '$data[w]', `posts` = '$posts', `tag1` = '$data[tag1]', `tag2` = '$data[tag2]', `counttag` = '$data[counttag]', `best` = '$data[best]'  WHERE `id` = '$id'";
			$db->setQuery( $query2 );
			$db->execute(); 
//---------------- CUSTOM FEILDS			
			$rows = Jstar_shop_CHeckupHelper::getFields($id);

			$query_dell = "DELETE FROM `#__jstar_shop_feilds_products` WHERE `product_id` ='$id'";
			$db->setQuery( $query_dell );
			$db->execute();

			$k=0;
			foreach($rows as $row){
				$field_id = $row->id;
				if($row->type != 4 && $row->type != 5){
					$value = $data['field'.$k];
				} else {
					$data['field'.$k] = array_filter($data['field'.$k]);
					$value = implode(',',$data['field'.$k]);
				}
				
				$query_insert = "INSERT INTO `#__jstar_shop_feilds_products` (`id`,`product_id`,`field_id`,`values`) VALUES (NULL,'$id','$field_id','$value')";
				$db->setQuery( $query_insert );
				$db->execute();
				$k++;
			} 
			return $id;
		}
	}
	
	public function delete2($cids) {
		$db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
		$query2 = ' DELETE FROM `#__jstar_shop_products` WHERE `id` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query2 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting products'), 'error');
		}
		$query3 = ' DELETE FROM `#__jstar_shop_feilds_products` WHERE `product_id` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query3 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting fields'), 'error');
		}
		$query4 = ' DELETE FROM `#__jstar_shop_comments` WHERE `product_id` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query4 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting comments'), 'error');
		}
		$query5 = ' DELETE FROM `#__jstar_shop_multicosts` WHERE `pid` IN (' . implode( ',', $cids ) . ') ';
		$db->setQuery( $query5 );
		if( !$db->query() )
		{
			$errorMessage = $this->getDBO()->getErrorMsg();
			JFactory::getApplication()->enqueueMessage(JText::_('Error deleting comments'), 'error');
		}
	}
	
}
