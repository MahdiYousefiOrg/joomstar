<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class Jstar_shopModelAmazing extends JModelAdmin
{
    public function getTable($type = 'amazings', $prefix = 'Jstar_shopTable', $config = array())
    {
        return JTable::getInstance($type, $prefix, $config);
    }

    public function getForm($data = array(), $loadData = true)
    {
        // Get the form.
        $form = $this->loadForm('com_jstar_shop.amazing', 'amazing', array('control' => 'jform', 'load_data' => $loadData));
        if (empty($form)) {
            return false;
        }
        return $form;
    }

    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.amazing.data', array());

        if (empty($data)) {
            $data = $this->getItem();
            // Prime some default values.
        }

        return $data;
    }

    public function getItem($pk = null)
    {
        return parent::getItem($pk);
    }

    public function apply2($data)
    {
        $db = JFactory::getDBO();
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $id = $db->escape($id);
        if ((!isset($id) || $id == 0 || $id == NULL || trim($id) == '') && !isset($_SESSION['amazing'])) {
            $app = JFactory::getApplication();
            $redirectTo = JRoute::_('index.php?option=com_jstar_shop&view=amazing&layout=edit&id=' . @$id, false);
            $app->Redirect($redirectTo, JText::_("COM_JSTAR_SHOP_NO_PRODUCTS_SELECTED"), 'error');
        }
        if (isset($id) && $id != 0 && $id != NULL && trim($id) != '' && !isset($_SESSION['amazing'])) {
            $query2 = "SELECT `pids` FROM `#__jstar_shop_amazings` WHERE `id` = '$id'";
            $db->setQuery($query2);
            $pids = $db->LoadResult();
            $pids = explode(',', $pids);
            foreach ($pids as $pid) {
                $_SESSION['amazing'][$pid] = 1;
            }
        }
        $pids = $_SESSION['amazing'];
        foreach ($pids as $index => $pid) {
            if ($pid == 1) {
                $pids2[] = $index;
            }
        }
        $pids2 = array_filter(array_unique($pids2));
        if (empty($pids2)) {
            $app = JFactory::getApplication();
            $redirectTo = JRoute::_('index.php?option=com_jstar_shop&view=amazing&layout=edit&id=' . @$id, false);
            $app->Redirect($redirectTo, JText::_("COM_JSTAR_SHOP_NO_PRODUCTS_SELECTED"), 'error');
        }
		$pids2 = array_map('intval', $pids2);
        $pids2 = implode(',', $pids2);
        $pids2 = $db->escape($pids2);
        $data[title] = $db->escape($data[title]);
        $data[date1] = $db->escape($data[date1]);
        $data[date2] = $db->escape($data[date2]);
        $data[off] = $db->escape($data[off]);
        $data[text] = $db->escape($data[text]);

        if (!isset($id) || $id == 0 || $id == NULL || trim($id) == '') {
            $query = "INSERT INTO `#__jstar_shop_amazings` (`id`,`title`,`pids`,`date1`, `date2`, `off`, `text`, `module`, `ordering`) VALUES (NULL, '$data[title]', '$pids2', '$data[date1]', '$data[date2]', '$data[off]', '$data[text]', '$data[module]', 0)";
            $db->setQuery($query);
            $db->execute();
            $id = $db->insertid();

        } else {
            $query = "UPDATE `#__jstar_shop_amazings` SET `title` = '$data[title]', `pids` = '$pids2', `date1` = '$data[date1]', `date2` = '$data[date2]', `off` = '$data[off]', `text` = '$data[text]', `module` = '$data[module]' WHERE `id` = '$id'";
            $db->setQuery($query);
            $db->execute();
        }
        unset($_SESSION['amazing']);
        return $id;
    }
}
