<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopModelFactor extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			);
		}

		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('a.id', 'asc');

	}

	public function getFactor()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$table = $db->quoteName( '#__jstar_shop_products' );
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$sh = $db->escape($sh);
		$query = "SELECT `a`.*,`b`.`title` AS `ptitle`,`b`.`price` AS `pprice`,`b`.`img1`,`b`.`off`,`b`.`multicost`,`a`.`fieldid`,`a`.`typePost`, `a`.`amazing` FROM `#__jstar_shop_orders` AS `a` LEFT JOIN `#__jstar_shop_products` AS `b` ON `a`.`product_id` = `b`.`id` WHERE `a`.`sh` = '$sh'";
		$db->setQuery($query);
		$orders = $db->LoadObjectList();
        return $orders;
	}

	public function getCoupon(){
		$db = $this->getDbo();
		$date = date('Y-m-d');
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$sh = $db->escape($sh);
		$date = $db->escape($date);
		$table = $db->quoteName( '#__jstar_shop_coupons' );
		$cel_percent = $db->quoteName( 'percent' );
		$cel_coupon = $db->quoteName( 'code' );
		$query = "SELECT `a`.`percent` FROM $table AS `a` LEFT JOIN `#__jstar_shop_orders` AS `b` ON `a`.`code` = `b`.`coupon` WHERE `b`.`sh` = '$sh' AND `a`.`date1` <= '$date' AND `a`.`date2` >= '$date'";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}

	public function getUser_coupon(){
		$db = $this->getDbo();
		$sh = JFactory::getApplication()->input->get('sh', '0', 'int');
		$sh = $db->escape($sh);
		$query = "SELECT `usercoupon` FROM `#__jstar_shop_orders` WHERE `sh` = '$sh'";
		$db->setQuery($query);
		$percent = $db->LoadResult();
		return $percent;
	}
	public function getCost($fieldid){
		$db = $this->getDbo();
		$fieldid = $db->escape($fieldid);
		$query = "SELECT `cost1`,`cost2` FROM `#__jstar_shop_multicosts` WHERE `id` = '$fieldid'";
		$db->SetQuery( $query );
		$result = $db->LoadObject();
		return $result;
	}
	public function getTypePost($typepost){
		$db = $this->getDbo();
		$typepost = $db->escape($typepost);
		$query = "SELECT `amount`,`type_post` FROM `#__jstar_shop_posts` WHERE `id` = '$typepost'"; 
		$db->SetQuery($query);
		$typePost = $db->LoadObject();
		return $typePost;
	}
	public function getGifts($giftid){
		$db = $this->getDbo();
		$giftid = explode(',',$giftid);
		$giftid = array_map('intval', $giftid);
		$giftid = implode(',',$giftid);
		$giftid = $db->escape($giftid);
		$query = "SELECT `title`, `price` FROM `#__jstar_shop_gifts` WHERE `id` IN (".$giftid.")"; 
		$db->setQuery( $query );
		$giftsid = $db->LoadObjectList();
		return $giftsid;
		
	}
}
