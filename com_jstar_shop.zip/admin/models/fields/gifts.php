<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldGifts extends JFormField
{
    public $type = 'Gifts';

    protected function getInput()
    {
        $cat2 = 'com_jstar_shop';
        $catid = JFactory::getApplication()->input->get('catid');
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $db = JFactory::getDBO();
        if (isset($id) && trim($id) != '' && $id != 0 && !isset($catid)) {
            $id = $db->escape($id);
            $query = "SELECT `catid` FROM `#__jstar_shop_gifts` WHERE `id` = '$id'";
            $db->setQuery($query);
            $catid = $db->LoadResult();
        }
        $cat2 = $db->escape($cat2);
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__categories');
        $query .= " WHERE `extension` = '$cat2' AND `published` = 1 ORDER BY `lft`";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();

        $output = '<select name="catid" onchange="form.submit()" id="jform_gifts" aria-required="true" required="required">';
        $output .= '<option value="">----------</option>';
        foreach ($rows as $value) {
            if ($catid == $value->id) {
                $select = "selected = selected";
            } else {
                $select = "";
            }
            if ($value->level > 1) {
                for ($m = 1; $m < $value->level; $m++) {
                    @$space .= '- ';
                }
            }
            $output .= '<option value="' . $value->id . '"' . $select . '">' . @$space . $value->title . '</option>';
            @$space = '';
        }
        $output .= '</select>';
        return $output;
    }
}

?>