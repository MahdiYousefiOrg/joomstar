<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die(); ?>
    <script type="text/javascript">
        function show2() {
            var val = document.getElementById('jform_type').value;
            if (val == 1) {
                document.getElementById('jform_value-lbl').style.display = 'none';
                document.getElementById('jform_value').style.display = 'none';
                document.getElementById('jform_multi-lbl').style.display = 'none';
                document.getElementById('jform_multi').style.display = 'none';
            }
            if (val == 2 || val == 3 || val == 4 || val == 5) {
                document.getElementById('jform_value-lbl').style.display = 'block';
                document.getElementById('jform_value').style.display = 'block';
            }
            if (val == 4 || val == 5) {
                document.getElementById('jform_search-lbl').style.display = 'none';
                document.getElementById('jform_search').style.display = 'none';
                document.getElementById('jform_multi-lbl').style.display = 'none';
                document.getElementById('jform_multi').style.display = 'none';
            }
            if (val == 2 || val == 3) {
                document.getElementById('jform_search-lbl').style.display = 'block';
                document.getElementById('jform_search').style.display = 'block';
                document.getElementById('jform_multi-lbl').style.display = 'block';
                document.getElementById('jform_multi').style.display = 'block';
            }
            if (val == 2 || val == 3 || val == 5) {
                document.getElementById('jform_multi-lbl').style.display = 'block';
                document.getElementById('jform_multi').style.display = 'block';
            }
        }
    </script>
<?php

class JFormFieldType1 extends JFormField
{
    public $type = 'Type1';

    protected function getInput()
    {

        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        if (isset($id) && $id != NULL && trim($id) != '') {
            $db = JFactory::getDBO();
            $id = $db->escape($id);
            $query = $db->getQuery(true);
            $query = "SELECT `type` FROM `#__jstar_shop_customfields` WHERE `id` = '$id'";
            $db->setQuery($query);
            $type = $db->LoadResult();
        }

        $output = '<select id="jform_type" name="jform[type]" onchange="show2()">';
        if (@$type == 1) {
            $output .= '<option value="1" selected="selected" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        if (@$type == 2) {
            $output .= '<option value="1" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" selected="selected" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        if (@$type == 3) {
            $output .= '<option value="1" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" selected="selected" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        if (@$type == 4) {
            $output .= '<option value="1" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" selected="selected" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        if (@$type == 5) {
            $output .= '<option value="1" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" selected="selected" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        if (!isset($type) || @$type == NULL) {
            $output .= '<option value="1" >' . JText::_('COM_JSTAR_SHOP_TEXT') . '</option>';
            $output .= '<option value="2" >' . JText::_('COM_JSTAR_SHOP_LISTBOX') . '</option>';
            $output .= '<option value="3" >' . JText::_('COM_JSTAR_SHOP_RADIO') . '</option>';
            $output .= '<option value="4" >' . JText::_('COM_JSTAR_SHOP_CHECKBOX') . '</option>';
            $output .= '<option value="5" >' . JText::_('COM_JSTAR_SHOP_COLOR') . '</option>';
        }
        $output .= '</select>';
        return $output;
    }
}

?>