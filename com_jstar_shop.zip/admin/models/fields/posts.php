<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldPosts extends JFormField
{
    public $type = 'Posts';

    function getChildren($parent)
    {
        $db = JFactory::getDBO();
        $parent = $db->escape($parent);
        $query = "SELECT * FROM `#__jstar_shop_cits` WHERE `parentid` = '$parent'";
        $db->SetQuery($query);
        $rows = $db->LoadObjectList();
        $children = array();
        $i = 0;
        foreach ($rows as $row) {
            $children[$i] = array();
            $children[$i]['id'] = $row->id;
            $children[$i]['name'] = $row->city;
            $children[$i]['children'] = $this->getChildren($row->id);
            $i++;
        }
        return $children;
    }

    protected function getInput()
    { ?>
        <script type="text/javascript">
        </script>
        <style>
            .bonsai,
            .bonsai > li {
                margin: 0;
                padding: 0;
                list-style: none;
            }

            .bonsai > li {
                position: relative;
                padding-right: 1.3em; /* padding for the thumb */
            }

            li .thumb {
                margin: -1px -10px 0 -1em; /* negative margin into the padding of the li */
                position: absolute;
                cursor: pointer;
            }

            li.has-children > .thumb:after {
                content: '▸';
            }

            li.has-children.expanded > .thumb:after {
                content: '▾';
            }

            li.collapsed > ol.bonsai {
                height: 0;
                overflow: hidden;
            }

            .bonsai .all,
            .bonsai .none {
                cursor: pointer;
            }

            label.citname {
                display: inline !important;
                margin-right: 6px;
            }
        </style>
        
        <?php
		$lang = JFactory::getLanguage();
		$dir = $lang->get('rtl');
		if($dir == 0) { ?>
        	<style>
			.bonsai > li {
			padding-left: 1.3em !important; /* padding for the thumb */
            }
			</style>
		<?php }
		$params = JComponentHelper::getParams('com_jstar_shop');
		$cuntry = $params->get('cuntry');
        $db = JFactory::getDBO();
        $finalResult = $this->getChildren('0');
        $query = "";
        $output = '
			<ol id="auto-checkboxes">
			  <li data-name="jform[cits][]" data-value="1">'.$cuntry.'
				<ol>';
        foreach ($finalResult as $cit) {
            $output .= '<li data-value="' . $cit['id'] . '">' . $cit['name'];
            if (!empty($cit['children'])) {
                $subcits = $cit['children'];
                $output .= '<ol>';
                foreach ($subcits as $subcit) {
                    $output .= '<li data-value="' . $subcit['id'] . '">' . $subcit['name'];
                    if (!empty($subcit['children'])) {
                        $subcits2 = $subcit['children'];
                        $output .= '<ol>';
                        foreach ($subcits2 as $subcit2) {
                            $output .= '<li data-value="' . $subcit2['id'] . '">' . $subcit2['name'];

                        }
                        $output .= '</ol>';
                    }
                    $output .= '</li>';
                }
                $output .= '</ol>';
            }
        }
        $output .= '</li></ol></li></ol>';
        return $output;

    }
}

?>