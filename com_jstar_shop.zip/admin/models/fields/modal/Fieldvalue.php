<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('JPATH_BASE') or die;

class JFormFieldModal_Fieldvalue extends JFormField
{
    protected $type = 'Modal_Fieldvalue';

    protected function getInput()
    {
        $script = array();
        // Select button script
        $script[] = '	function jSelectValue_' . $this->id . '(value, object) {';

        $script[] = '		document.getElementById("' . $this->id . '_id").value = value;';
        $script[] = '		document.getElementById("' . $this->id . '_name").value = value;';
        $script[] = '		jQuery("#modalValues' . $this->id . '").modal("hide");';

        if ($this->required) {
            $script[] = '		document.formvalidator.validate(document.getElementById("' . $this->id . '_id"));';
            $script[] = '		document.formvalidator.validate(document.getElementById("' . $this->id . '_name"));';

        }
        $script[] = '	}';
        JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));


        $html = array();
        $link = 'index.php?option=com_jstar_shop&amp;view=values&amp;layout=modal&amp;tmpl=component&amp;function=jSelectValue_' . $this->id;
        $url = $link . '&amp;' . JSession::getFormToken() . '=1';

        if ($this->value != '') {

            try {
                $title = $this->value;
            } catch (RuntimeException $e) {
                JFactory::getApplication()->enqueueMessage($e->getMessage(), 'Warning');
            }
        }

        if (empty($title)) {
            $title = JText::_('COM_JSTAR_SHOP_SELECT_AN_VALUE');
        }
        $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');


        if (0 == (int)$this->value) {
            $value = '';
        } else {
            $value = (int)$this->value;
        }

        $class = '';

        if ($this->required) {
            $class = ' class="required modal-value"';
        }


        $html[] = '<span class="input-append">';
        $html[] = '<input type="text" class="input-medium" id="' . $this->id . '_name" value="' . $title . '" disabled="disabled" size="35" />';
        $html[] = '<a href="#modalValues' . $this->id . '" class="btn hasTooltip" role="button"  data-toggle="modal" title="'
            . JHtml::tooltipText('COM_JSTAR_SHOP_CHANGE_Value') . '">'
            . '<span class="icon-file"></span> '
            . JText::_('JSELECT') . '</a>';

        $html[] = '<input type="hidden" id="' . $this->id . '_id"' . $class . ' name="' . $this->name . '" value="' . $value . '" />';


        $html[] = JHtml::_(
            'bootstrap.renderModal',
            'modalValues' . $this->id,
            array(
                'url' => $url,
                'title' => JText::_('COM_JSTAR_SHOP_CHANGE_VALUE'),
                'width' => '800px',
                'height' => '300px',
                'footer' => '<button class="btn" data-dismiss="modal" aria-hidden="true">'
                    . JText::_("JLIB_HTML_BEHAVIOR_CLOSE") . '</button>'
            )
        );


        return implode("\n", $html);


    }


    protected function getLabel()
    {
        return str_replace($this->id, $this->id . '_id', parent::getLabel());
    }


}
