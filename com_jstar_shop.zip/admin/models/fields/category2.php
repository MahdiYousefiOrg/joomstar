<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldCategory2 extends JFormField
{
    public $type = 'Category2';

    protected function getInput()
    {
        $cat2 = 'com_jstar_shop';
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $db = JFactory::getDBO();
        $cat2 = $db->escape($cat2);
        $id = $db->escape($id);
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__categories');
        $query .= " WHERE `extension` = '$cat2' AND `published` = 1 ORDER BY `lft`";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();

        $query2 = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
        $db->setQuery($query2);
        $cat = $db->LoadResult();

        $output = '<select name="jform[catid]" onchange="showcustom()" id="jform_catid" aria-required="true" required="required">';
        $output .= '<option value="">----------</option>';
        foreach ($rows as $value) {
            if ($cat == $value->id) {
                $select = "selected = selected";
            } else {
                $select = "";
            }
            if ($value->level > 1) {
                for ($m = 1; $m < $value->level; $m++) {
                    @$space .= '-';
                }
            }
            $output .= '<option value="' . $value->id . '"' . $select . '>' . @$space . $value->title . '</option>';
            @$space = '';

        }
        $output .= '</select>';
        return $output;
    }
}

?>