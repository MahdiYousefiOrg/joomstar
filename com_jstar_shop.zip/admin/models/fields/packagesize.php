<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldPackagesize extends JFormField
{
    public $type = 'Packagesize';

    protected function getInput()
    {
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $db = JFactory::getDBO();
        $id = $db->escape($id);
		$query = "SELECT `id`, `title` FROM `#__jstar_shop_limits`";
		$db->SetQuery( $query );
		$rows = $db->LoadObjectList();
		$size = "";
		if(isset($id) && $id != 0 && trim($id) != ''){
			$query = "SELECT `size` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
			$db->setQuery($query);
			$size = $db->LoadResult();
		}
        $output = '<select name="jform[size]" onchange="showlimits()" id="jform_size" aria-required="true" required="required">';
        $output .= '<option value="">----------</option>';
        foreach ($rows as $value) {
            if ($size == $value->id) {
                $select = "selected = selected";
            } else {
                $select = "";
            }
            $output .= '<option value="' . $value->id . '"' . $select . '>' . @$space . $value->title . '</option>';

        }
        $output .= '</select>';
        return $output;
    }
}

?>