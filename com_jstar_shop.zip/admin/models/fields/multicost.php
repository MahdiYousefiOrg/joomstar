<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die(); ?>
    <script type="text/javascript">
        function hideprice() {
            document.getElementById('jform_status-lbl').style.display = "none";
            document.getElementById('jform_status').style.display = "none";
        }

        function showprice() {
            document.getElementById('jform_status-lbl').style.display = "block";
            document.getElementById('jform_status').style.display = "block";
        }
    </script>
<?php

class JFormFieldMulticost extends JFormField
{
    public $type = 'Multicost';

    protected function getInput()
    {

        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        if (isset($id) && $id != NULL && trim($id) != '' && $id != 0) {
            $db = JFactory::getDBO();
            $id = $db->escape($id);
            $query = $db->getQuery(true);
            $query = "SELECT `multicost` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
            $db->setQuery($query);
            $multicost = $db->LoadResult();
        }
        if (isset($id) && $id != 0 && $id != NULL && trim($id) != '') {
            if ($multicost == 1) {
                $class1 = 'btn btn-success';
                $class2 = 'btn';
                $checked1 = 'checked="CHECKED"';
                $checked2 = '"';
            } else {
                $class1 = 'btn';
                $class2 = 'btn btn-danger';
                $checked2 = 'checked="CHECKED"';
                $checked1 = '"';
            }
        } else {
            $class1 = 'btn';
            $class2 = 'btn btn-danger';
            $checked2 = 'checked="CHECKED"';
            $checked1 = '"';
        }

        $output = '<fieldset id="jform_multicost" class="btn-group btn-group-yesno radio">
							<input id="jform_multicost0"' . $checked2 . ' name="jform[multicost]" value="0" type="radio">
							<label for="jform_multicost0" onclick="showprice()" class="' . $class2 . '">' . JText::_('JNO') . '</label>
							<input id="jform_multicost1"' . $checked1 . ' name="jform[multicost]" value="1" type="radio">
							<label for="jform_multicost1" onclick="hideprice()" class="' . $class1 . '">' . JText::_('JYES') . '</label>
					  </fieldset>';

        return $output;
    }
}

?>