<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldProducts extends JFormField
{
    public $type = 'Products';

    protected function getInput()
    {
        JHtml::_('behavior.modal');
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        if (isset($id) && $id != 0 && $id != NULL && trim($id) != '') {
            $db = JFactory::getDBO();
            $id = $db->escape($id);
            $query = "SELECT `pids` FROM `#__jstar_shop_amazings` WHERE `id` = '$id'";
            $db->setQuery($query);
            $pids = $db->LoadResult();
            $pids = $db->escape($pids);
            $query = "SELECT `title` FROM `#__jstar_shop_products` WHERE `id` IN ($pids)";
            $db->setQuery($query);
            $ptitles = $db->LoadColumn();
            if (!empty($ptitles)) {
                $output = '<div id="amazing_products">';
                $output .= '<ul>';
                foreach ($ptitles as $ptitle) {
                    $output .= '<li>' . $ptitle . '</li>';
                }
                $output .= '</ul>';
                $output .= '</div>';
            }
        } else {
            $id = 0;
        }
        @$output .= '<a id="buttom" href="index.php?option=com_jstar_shop&view=products_amazings&tmpl=component&id=' . $id . '" class="modal" rel="{handler: \'iframe\', size: {x: 790, y: 590}}">' . JText::_('COM_JSTAR_SHOP_SELECT_PRODUCTS') . '</a>';
        return $output;

    }
}

?>