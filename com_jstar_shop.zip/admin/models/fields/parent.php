<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die();

class JFormFieldParent extends JFormField
{
    public $type = 'Parent';

    function ParentTreeOption($data, $tree, $id = 0, $text = '', $currentId)
    {

        foreach ($data as $key) {
            $show_text = $text . $key->text;

            if ($key->parentid == $id && $currentId != $id && $currentId != $key->value) {
                $tree[$key->value] = new JObject();
                $tree[$key->value]->text = $show_text;
                $tree[$key->value]->value = $key->value;
                $tree = $this->ParentTreeOption($data, $tree, $key->value, $show_text . " --> ", $currentId);
            }
        }
        return ($tree);
    }

    protected function getInput()
    {

        $db = JFactory::getDBO();
		$view =JFactory::getApplication()->input->get('view', null, 'string');

        //build the list of categories
        $query = "SELECT `a`.`city` AS `text`, `a`.`id` AS `value`, `a`.`parentid` as `parentid` FROM `#__jstar_shop_cits` AS `a` WHERE `a`.`level` = 1 ORDER BY `a`.`id` DESC";
        $db->setQuery($query);
        $parentss = $db->loadObjectList();
        $catId = -1;

        if ($view == 'cit') {
            $id = $this->form->getValue('id'); // id of current category
            if ((int)$id > 0) {
                $catId = $id;
            }
        }
        $tree = array();
        $text = '';
        $tree = $this->ParentTreeOption($parentss, $tree, 0, $text, $catId);
        array_unshift($tree, JHTML::_('select.option', '0', '' . JText::_('COM_JSTAR_SHOP_NOPARENT') . '', 'value', 'text'));

        return JHTML::_('select.genericlist', $tree, $this->name, '', 'value', 'text', $this->value, $this->id);
    }
}

?>