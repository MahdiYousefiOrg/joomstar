<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelUserinfo extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
                );
		parent::__construct($config);
	}
	
	public function getUserinfo()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$sh = JFactory::getApplication()->input->get('orderid');;
			$sh = $db->escape($sh);
			$query = "SELECT `a`.*,`a`.`name` as `name2` FROM `#__jstar_shop_order_details` AS `a` LEFT JOIN `#__jstar_shop_orders` AS `b` ON `a`.`sh_order` = `b`.`id` WHERE `a`.`sh_order` = '$sh'"; 
			$db->setQuery( $query );
			$rows = $db->LoadObject();
			return $rows; 
	}
}
?>
