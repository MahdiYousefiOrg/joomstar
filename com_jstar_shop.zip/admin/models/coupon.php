<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelCoupon extends JModelAdmin
{
	public function getTable($type = 'coupons', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.coupon', 'coupon', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.coupon.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}
	
}
