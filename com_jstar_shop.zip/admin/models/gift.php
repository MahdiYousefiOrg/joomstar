<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelGift extends JModelAdmin
{
	public function getTable($type = 'gifts', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.gift', 'gift', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.gift.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		}

		return $data;
	}
	
	public function getFields(){ 
		$catID = JFactory::getApplication()->input->get('catid');
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$db = JFactory::getDBO();
		if(isset($id) && trim($id) != '' && $id != 0 && !isset($catID)){ 
			$id = $db->escape($id);
			$query = "SELECT `catid` FROM `#__jstar_shop_gifts` WHERE `id` = '$id'"; 
			$db->setQuery( $query );
			$catID = $db->LoadResult();
		}
		$catID = $db->escape($catID);
		$query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` ";
		$db->setQuery( $query );
		$parentids = $db->LoadColumn();
    	$catids = implode(',',$parentids);
		
		if(isset($catID) && trim($catID) != ''){
			$table = $db->quoteName( '#__jstar_shop_customfields' );
			$query = "SELECT * FROM $table WHERE `catid` IN ($catids) AND `published` = 1 AND `type` != '1' AND `type` != '4' AND `type` != '5' AND `multi` != '1'"; 
			$db->setQuery( $query );
			$rows = $db->LoadObjectList();
			return $rows;
		}
		
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}
	
	public function addproducts($cids){ 
		$db = JFactory::getDBO();
		$cids = array_map('intval', $cids);
		$lastid = $_SESSION['lastid'];
		$lastid = $db->escape($lastid);
		$products_id = implode(',',$cids);
		$query = "UPDATE `#__jstar_shop_gifts` SET `products_id` = '$products_id' WHERE `id` = '$lastid'";
		$db->setQuery( $query ); 
		$db->execute();


	}
}
