<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelsimilar2  extends JModelList
{ 
	 public function getChildeid2() { 
		$db				= $this->getDbo();
		$catID = JFactory::getApplication()->input->get('catid');
		$catID = $db->escape($catID);	
		$query="SELECT `node`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `parent`.`id` = '$catID' ORDER BY `node`.`lft` ";
		$db->setQuery( $query );
		$childid = $db->LoadColumn();
		$childid[] = $catID;
		return $childid;
	 }

	public function getProducts()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
		$id = JFactory::getApplication()->input->get('id', '0', 'int');
		$id = $db->escape($id);
		$catIDf = JFactory::getApplication()->input->get('catid', 0, 'string');
		$catIDf = $db->escape($catIDf);
		$idstr = $this->getChildeid2();
		$idstr = implode(',',$idstr);
		$publish = $db->quote( $db->escape( 1 ), false );
		$table = $db->quoteName( '#__jstar_shop_products' );
		$cel_id = $db->quoteName( 'id' );
		$cel_title = $db->quoteName( 'title' );
		$cel_price = $db->quoteName( 'price' );
		$cel_img1 = $db->quoteName( 'img1' );
		$cel_catid = $db->quoteName( 'catid' );
		$cel_published = $db->quoteName( 'published' );
				
			$i=0;
			$search = JFactory::getApplication()->input->get('search', null, 'array');
			
			if(!isset($search)){ 
				
				if(!isset($catIDf) || trim($catIDf) == ''){
					$app = JFactory::getApplication();
					$app->enqueueMessage(JTExt::_(''), 'success');
					$app->redirect(JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=similars',false));
				}
				if(!isset($id) || $id == 0 || trim($id) == ''){
					$query = "INSERT INTO `#__jstar_shop_similars` (`id`,`catid`,`products_id`,`feilds`,`ordering`) VALUES (NULL,'$catIDf',NULL,NULL,0)";
					$db->setQuery( $query ); 
					$db->execute();
					$lastid = $db->insertid();
					$_SESSION['lastid'] = $lastid;
				} else {
					$query = "UPDATE`#__jstar_shop_similars` SET `catid` = '$catIDf',`feilds` = NULL WHERE `id` = '$id'";
					$db->setQuery( $query ); 
					$db->execute();
					$_SESSION['lastid'] = $id;
				}
				$query = "SELECT $cel_id,$cel_title,$cel_price,$cel_img1 FROM $table WHERE $cel_catid IN ($idstr) AND $cel_published = $publish";
				$db->setQuery( $query ); 
				$rows = $db->LoadObjectList();
			} else {
				if(!isset($catIDf) || trim($catIDf) == ''){
					$app = JFactory::getApplication();
					$app->enqueueMessage(JTExt::_(''), 'success');
					$app->redirect(JRoute::_('index.php?option='.JFactory::getApplication()->input->get('option', 'com_jstar_shop', 'string').'&view=similars',false));
				}
				$fieldids = implode(',',$search);
				if(!isset($id) || $id == 0 || trim($id) == ''){
					$query = "INSERT INTO `#__jstar_shop_similars` (`id`,`catid`,`products_id`,`feilds`,`ordering`) VALUES (NULL,'$catIDf',NULL,'$fieldids',0)";
					$db->setQuery( $query ); 
					$db->execute();
					$lastid = $db->insertid();
					$_SESSION['lastid'] = $lastid;
				} else {
					$query = "UPDATE`#__jstar_shop_similars` SET `catid` = '$catIDf', `feilds` = '$fieldids' WHERE `id` = '$id'";
					$db->setQuery( $query ); 
					$db->execute();
					$lastid = $db->insertid();
					$_SESSION['lastid'] = $id;
				}

				foreach($search as $values){
					$index = explode('-',$values); 
					$arr1[] = $index['0']; 
					$arr2[] = $index['1'];
				}
				$arr1 = array_unique($arr1);
				$arr2 = array_unique($arr2); 
				$str = "";
				foreach($arr2 as $value){
					$str.="'$value',";
				}
				$str = substr($str, 0, -1); 
				foreach($arr1 as $fieldid){ 
					$query = "SELECT `type` FROM `#__jstar_shop_customfields` WHERE `id` = '$fieldid'";
					$db->setQuery( $query );
					$type = $db->LoadResult();
					if($type == 2 || $type == 3){
						$query = "SELECT `product_id` FROM `#__jstar_shop_feilds_products` WHERE `field_id` = '$fieldid' AND `values` IN ($str)"; 
						$db->setQuery( $query );
						$rows[]= $db->loadColumn();
					} 
				}
				if(count($arr1) > 1 ){ 
					$result = @call_user_func_array('array_intersect', array_filter($rows)); 
				} else {
					$result = $rows[0];
				} 
				if(!empty($result)){ 
					$idstr1 = implode(',',$result); 

					$query = "SELECT $cel_id,$cel_title,$cel_price,$cel_img1 FROM $table WHERE `id` IN ($idstr1) AND $cel_catid IN ($idstr) AND $cel_published = $publish"; 
					$db->setQuery( $query ); 
					$rows = $db->LoadObjectList();
				} else {
					return true;
				} 
			}
			return $rows;
			
		}
}
?>
