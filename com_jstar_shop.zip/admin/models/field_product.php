<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelField_product  extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
                );
		parent::__construct($config);
	}
	 
 public function getparents($id)
    {
		$db				= $this->getDbo();
		if(!isset($id)){ 
			$id = JFactory::getApplication()->input->get('id', '0', 'int');
		}
		$id = $db->escape($id);
		$query_catid = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
		$db->setQuery( $query_catid );
		$catID = $db->LoadResult();
		$categories = JCategories::getInstance('jstar_shop');
		$category = $categories->get($catID);
		$p = $category->getParent()->id; 
		if($p != 'root'){
			$parentid[] = $p;
		} else {
			$parentid[] = $catID ;
		} 
		while($p != 'root'){
			$category = $categories->get($p);
			$p = $category->getParent()->id;
			if($p != 'root'){
				$parentid[] = $p;
			}
		} 
		$parentid[] = $catID;
        return $parentid;
    }
	 
	public function getFields($id=NULL){ 
		$db				= $this->getDbo();
		$idstr = $this->getparents($id);
		$idstr = array_map('intval', $idstr);
		$idstr = implode(',',$idstr);
		$query = "SELECT `a`.*,`b`.`title` AS `group2`,`b`.`id` AS `bid` FROM `#__jstar_shop_customfields` AS `a` LEFT JOIN `#__jstar_shop_group_fields` AS `b` ON `a`.`group_id` = `b`.`id`  WHERE `a`.`catid` IN ($idstr) AND `a`.`multi` != 1 ORDER BY `b`.`id`,`a`.`id`"; 
		$db->setQuery( $query );
		$rows = $db->LoadObjectList();
		return $rows;
		
	}
	
	
	public function getValues()
	{
		$db = JFactory::getDBO();
		$id = JFactory::getApplication()->input->get('id', '0', 'int'); 
		$id = $db->escape($id);
		$query = "SELECT `a`.`values`,`a`.`field_id`,`b`.`id`,`c`.`id` FROM `#__jstar_shop_feilds_products` AS `a` LEFT JOIN `#__jstar_shop_customfields` AS `b` ON `a`.`field_id` = `b`.`id` LEFT JOIN `#__jstar_shop_group_fields` AS `c` ON `b`.`group_id` = `c`.`id` WHERE `a`.`product_id` = '$id' AND `b`.`multi` != 1 ORDER BY `c`.`id`,`b`.`id`";
		$db->setQuery( $query );
		$rows = $db->LoadObjectList(); 
		return $rows;
	}
}
?>
