<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelMulticost extends JModelAdmin
{
	public function getTable($type = 'multicosts', $prefix = 'Jstar_shopTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jstar_shop.multicost', 'multicost', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.multicost.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			// Prime some default values.
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		return parent::getItem($pk);
	}
	
	public function getparents($id){
		$db				= $this->getDbo();
		if(!isset($id)){ 
			$id = JFactory::getApplication()->input->get('pid', '0', 'int');
		}
		$id = $db->escape($id);
		$query_catid = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
		$db->setQuery( $query_catid );
		$catID = $db->LoadResult();
		$catID = $db->escape($catID);
		$query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` ";
		$db->setQuery( $query );
		$parentid = $db->LoadColumn();
		return $parentid;
	}
	
	public function getFields($id=NULL){ 
		$db				= $this->getDbo();
		$id = JFactory::getApplication()->input->get('pid', '0', 'int');
		$idstr = $this->getparents($id);
		$idstr = array_map('intval', $idstr);
		$idstr = implode(',',$idstr); 
		$query = "SELECT `a`.*,`b`.`title` AS `group2`,`b`.`id` AS `bid` FROM `#__jstar_shop_customfields` AS `a` LEFT JOIN `#__jstar_shop_group_fields` AS `b` ON `a`.`group_id` = `b`.`id`  WHERE `a`.`catid` IN ($idstr) AND `a`.`multi` = 1 ORDER BY `b`.`id`,`a`.`id`"; 
		$db->setQuery( $query );
		$rows = $db->LoadObjectList(); 
		return $rows;
	}
}
