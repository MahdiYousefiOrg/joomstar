<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class Jstar_shopModelCit extends JModelAdmin
{
    public function getTable($type = 'cits', $prefix = 'Jstar_shopTable', $config = array())
    {
        return JTable::getInstance($type, $prefix, $config);
    }

    public function getForm($data = array(), $loadData = true)
    {
        // Get the form.
        $form = $this->loadForm('com_jstar_shop.cit', 'cit', array('control' => 'jform', 'load_data' => $loadData));
        if (empty($form)) {
            return false;
        }
        return $form;
    }

    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = JFactory::getApplication()->getUserState('com_jstar_shop.edit.cit.data', array());

        if (empty($data)) {
            $data = $this->getItem();
            // Prime some default values.
        }

        return $data;
    }

    public function getItem($pk = null)
    {
        return parent::getItem($pk);
    }

    public function apply2($data)
    {
        $db = JFactory::getDBO();
        $id = JFactory::getApplication()->input->get('id', '0', 'int');
        $parentid = $data['parentid'];
        $parentid = $db->escape($parentid);
        if ($parentid != 0) {
            $query = "SELECT `level` FROM `#__jstar_shop_cits` WHERE `id` = '$parentid'";
            $db->setQuery($query);
            $level0 = $db->LoadResult();
            $level = $level0 + 1;
        } else {
            $level = 1;
        }
        $data[parentid] = $db->escape($data[parentid]);
        $data[level] = $db->escape($data[level]);
        $data[city] = $db->escape($data[city]);
        $data[store] = $db->escape($data[store]);
        if (!isset($id) || $id == 0 || $id == NULL || trim($id) == '') {
            $query = "INSERT INTO `#__jstar_shop_cits` (`id`, `parentid`,`level`,`city`, `store`, `ordering`) VALUES (NULL, '$data[parentid]', '$level', '$data[city]', '$data[store]', 0)";
            $db->setQuery($query);
            $db->execute();
            $id = $db->insertid();
        } else {
            $id = $db->escape($id);
            $query = "UPDATE `#__jstar_shop_cits` SET `parentid`= '$data[parentid]', `level` = '$level', `city` = '$data[city]', `store` = '$data[store]' WHERE `id` = '$id'";
            $db->setQuery($query);
            $db->execute();
        }
        return $id;
    }

    public function getSubcits()
    {
        $db = $this->getDbo();
		$parentcit = JFactory::getApplication()->input->get('parentcit', '', 'string');
        $parentcit = $db->escape($parentcit);
        $query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` = '$parentcit' 
		UNION 
		SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `parentid` IN 
	    (SELECT `id` FROM `#__jstar_shop_cits` WHERE `parentid` = '$parentcit')";
        $db->setQuery($query);
        $subcits = $db->loadObjectList();

        $query = "SELECT `id`,`city` FROM `#__jstar_shop_cits` WHERE `id` = '$parentcit'";
        $db->setQuery($query);
        $row = $db->LoadObject();
        $subcits[] = $obj = new stdClass;
        $obj->id = $row->id;
        $obj->city = $row->city;

        return $subcits;
    }
}
