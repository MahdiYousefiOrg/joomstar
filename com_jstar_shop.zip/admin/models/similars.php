<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopModelSimilars extends JModelList
{ 
	public function __construct($config = array())
	{ 
                $config['filter_fields'] = array(
                );
		parent::__construct($config);
	}
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
			$app		= JFactory::getApplication();

		// Adjust the context to support modal layouts.
			if (JFactory::getApplication()->input->get('layout', null, 'string')) {
				$this->context .= '.'.$layout;
			}
				
		parent::populateState('similars.ordering', 'ASC');
	}
	/**
	 * Build an SQL query to load the list data.
	 */
	 
	protected function getListQuery()
	{
		// Create a new query object.
			$db				= $this->getDbo();
			$query			= $db->getQuery(true);

		// Select the required fields from the table.
				
			$query->select( '`similars`.*' );
			$query->from( '`#__jstar_shop_similars` as `similars`' );
			$query->select('`b`.`title` AS `category`')
				 ->join('LEFT', '`#__categories` AS `b` on `b`.`id` = `similars`.`catid`');
    	// Filter by search in title
			$orderCol = $this->state->get('list.ordering');
			$orderDirn = $this->state->get('list.direction');
			$query->order($db->escape($orderCol.' '.$orderDirn));
			return $query;
	}
}
?>
