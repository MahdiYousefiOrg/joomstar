<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopHelper extends JHelperContent
{
	public static function addSubmenu($vName)
	{
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_DASHBOARD'),
			'index.php?option=com_jstar_shop&view=dashboard',
			$vName == 'dashboard'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_CATEGORIES'),
			'index.php?option=com_categories&view=categories&extension=com_jstar_shop',
			$vName == 'categories'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_GROUP_FIELDS'),
			'index.php?option=com_jstar_shop&view=group_fields',
			$vName == 'group_fields'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_CUSTOMFIELDS'),
			'index.php?option=com_jstar_shop&view=customfields',
			$vName == 'customfields'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_POSTS'),
			'index.php?option=com_jstar_shop&view=posts',
			$vName == 'posts'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_PRODUCTS'),
			'index.php?option=com_jstar_shop&view=products',
			$vName == 'products'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_SIMILARS'),
			'index.php?option=com_jstar_shop&view=similars',
			$vName == 'similars'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_GIFTS'),
			'index.php?option=com_jstar_shop&view=gifts',
			$vName == 'gifts'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_AMAZINGS'),
			'index.php?option=com_jstar_shop&view=amazings',
			$vName == 'amazings'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_COUPONS'),
			'index.php?option=com_jstar_shop&view=coupons',
			$vName == 'coupons'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_COUPON_USERS'),
			'index.php?option=com_jstar_shop&view=coupon_users',
			$vName == 'coupon_users'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_PRICE_CATEGORIES'),
			'index.php?option=com_jstar_shop&view=price_categories',
			$vName == 'price_categories'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_PRICE_USERS_LIST'),
			'index.php?option=com_jstar_shop&view=users',
			$vName == 'users'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_PRICE_ORDERS'),
			'index.php?option=com_jstar_shop&view=orders',
			$vName == 'orders'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_PAYKS'),
			'index.php?option=com_jstar_shop&view=payks',
			$vName == 'payks'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_RECOMMENDS'),
			'index.php?option=com_jstar_shop&view=recommends',
			$vName == 'recommends'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_CONFIGURATION'),
			'index.php?option=com_config&view=component&component=com_jstar_shop'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_JSTAR_SHOP_DOCUMENTS'),
			'https://joomstar.ir'
		);
	}
}
