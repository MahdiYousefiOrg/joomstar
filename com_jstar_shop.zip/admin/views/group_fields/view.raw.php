<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopViewGroup_fields extends JViewLegacy
{
	public function display($tpl = null)
	{
		$groupfields = $this->get('groupfields');
		echo '{items:'.json_encode($groupfields).'}';
	}

}
