<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument(); 
$doc->addStyleSheet(JURi::root().'media/com_jstar_shop/css/admin.product.css'); 
$doc->addScript(JURi::root().'media/com_jstar_shop/js/admin/product.js');
$id = JFactory::getApplication()->input->get('id', null, 'int');
JHTML::_('behavior.formvalidator');
$db=JFactory::getDBO();
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "product.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
JHtml::_('behavior.colorpicker');
if(isset($id) && $id != 0 && $id != NULL && trim($id) != ''){
	$query			= $db->getQuery(true);
	$id = $db->escape($id);
	$query="SELECT `multicost` FROM `#__jstar_shop_products` WHERE `id` = '$id'";
	$db->setQuery( $query );
	$multicost = $db->LoadResult();

}
$options = array(
    'useCookie' => true,
    'active' => 'tabs_1'
);
$lang = JFactory::getLanguage();
$dir = $lang->get('rtl');
if($dir == 0) { ?>
	<style>
	div.radio-input2, div.check-input2{
		float:left !important;
		margin-right:55px !important;
		margin-left:5px !important;
	}
	div.radio-btn2, div.check-btn2{
		float:left !important;
	}
	</style>
<?php } ?>
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=product&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
<?php
// Start Tabs
echo '<div>';
echo JHtml::_('bootstrap.startTabSet', 'tab_group_id', $options);

// Tab 1
echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_1', JText::_('COM_JSTAR_SHOP_MAIN_DETILES'));
?>
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset('myFieldSet') as $fieldset){  ?>
				<li><?php echo $fieldset->label; ?>
				<?php if(isset($id) && $fieldset->name =='jform[catid]') { echo '<div style="border:1px solid #CCC; padding:4px 6px; margin-bottom:6px; width:206px;">'.$this->category.'</div>'; } else { echo $fieldset->input; } ?></li>
<?php } ?>
			</ul>
         </fieldset>
	</div>

<?php
echo JHtml::_('bootstrap.endTab');

// Tab 2
echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_2',  JText::_('COM_JSTAR_SHOP_GALLERY'));
?>
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset('myFieldSet2') as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
				
			</ul>
         </fieldset>
	</div>

<?php
echo JHtml::_('bootstrap.endTab');


// tab5
echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_6', JText::_('COM_JSTAR_SHOP_TAG')); ?>
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset('myFieldSet5') as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
				
			</ul>
         </fieldset>
	</div>

<?php echo JHtml::_('bootstrap.endTab');

// Tab3 
echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_3',  JText::_('COM_JSTAR_SHOP_TECHNICAL_DETILES'));
?>
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist" id="customf">
            	<?php if(isset($this->fields) && $this->fields != NULL) { 
					$i=0;
					foreach($this->fields as $field) { 
						if($i==0) { ?>
                        	<div class="group"><?php echo $field->group2; ?></div>
						<?php } elseif($this->fields[$i-1]->group2 != $this->fields[$i]->group2) {	?>
                   			<div class="group"><?php echo $field->group2; ?></div>
                    <?php } ?>
                    	<li class="fieldtype"><label><?php echo $field->title; ?></label>
						<?php if($field->id == @$this->values[$i]->field_id){
									@$value = @$this->values[$i]->values;
						}
						if($field->type == 1) { ?>
							<input type = "text" name="jform[field<?php echo $i; ?>]" value="<?php echo @$value; ?>" /></li>
						<?php }
						if($field->type == 2) { ?>
                        	<select name="jform[field<?php echo $i; ?>]">
							<?php $values = explode('-',$field->value);
								foreach($values as $list){ ?>
                                	<option value="<?php echo $list; ?>" <?php if(@$list == @$value) echo 'selected="SELECTED"'?> ><?php echo @$list; ?></option>
								<?php } ?>
                        	</select>
						<?php }
						if($field->type == 3) { ?>
                        	<div class="radio-group">
							<?php $values = explode('-',$field->value);
								foreach($values as $list){ ?>
                                	<div class="radio-btn2"><?php echo $list; ?></div>
                                    <div class="radio-input2"><input type="radio" name="jform[field<?php echo $i; ?>]" value="<?php echo @$list; ?>" <?php if(@$list == @$value) echo 'checked="CHECKED"'?> />
                                    </div>
                                <?php } ?>
                                <div class="clear2"></div>
                            </div>
						<?php }
						if($field->type == 4) { ?>
                        	<div class="check-group">
							<?php $values = explode('-',$field->value);
									$check = explode(',',@$value);
								foreach($values as $list){
								 ?>
                                	<div class="check-btn2"><?php echo $list; ?></div>
                                    <div class="check-input2"><input type="checkbox" name="jform[field<?php echo $i; ?>][]" value="<?php echo $list; ?>" <?php if(in_array($list,$check)) echo 'checked="CHECKED"'?> />
                                    </div>
                                <?php } ?>
                                <div class="clear2"></div>
                             </div>
						<?php }
						if($field->type == 5) { 
						JHtml::_('behavior.colorpicker');
						?>
                        	<div class="">
                                <div><?php echo JText::_('COM_JSTAR_SHOP_SET_COLOR_PRODUCT'); ?></div>
							<?php $values = explode('-',$field->value);
								  $query = "SELECT `values` FROM `#__jstar_shop_feilds_products` WHERE `product_id` = '$id' AND `field_id` = '$field->id'";
								  $db->setQuery( $query ); 
								  $colors = $db->LoadResult();
								  $check = explode(',',@$colors);
								  $p=0;
								foreach($values as $list){ ?>
                                <div class=""><?php echo $list; ?></div>
                                 <input type="text" name="jform[field<?php echo $i; ?>][]" class="minicolors hex minicolors-input" id="jform_backgroundcolor" data-position="left" data-control="hue" data-format="hex" dir="ltr" style="text-align:right;" size="7" value="<?php echo $check[$p]; ?>" />
                                 
                                <?php $p++; } ?>
                                </div>
                                </li>
						<?php }
						$i++;
					}
                 } ?>
			</ul>
         </fieldset>
		<input type="hidden" name="task" value="item.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>

<?php
echo JHtml::_('bootstrap.endTab');
// Tab 4
echo JHtml::_('bootstrap.addTab', 'tab_group_id', 'tabs_4',  JText::_('COM_JSTAR_SHOP_META'));
?>
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset('myFieldSet3') as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
				
			</ul>
         </fieldset>
	</div>

<?php
echo JHtml::_('bootstrap.endTab');

// End Tabs
echo JHtml::_('bootstrap.endTabSet');
echo '</div>';
?>
</form>
</td>
</table>


