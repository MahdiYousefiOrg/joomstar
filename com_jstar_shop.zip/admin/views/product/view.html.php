<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopViewProduct extends JViewLegacy
{
	protected $fields;
	protected $values;
	protected $category;
	public function display($tpl = null)
	{
		$form = $this->get('Form');
		$item = $this->get('Item');
		$id = JFactory::getApplication()->input->get('id', null, 'int');
		if(isset($id)){
			$fields = Jstar_shop_CHeckupHelper::getFields();
			$values = Jstar_shop_CHeckupHelper::getValues();
		}
		$category = Jstar_shop_CHeckupHelper::getCategory();
		if (count($errors = $this->get('Errors')))
		{
			JFactory::getApplication()->enqueueMessage(implode('<br />', $errors));
			return false;
		}
		// Assign the Data
		$this->form = $form;
		$this->item = $item;
		if(isset($id)){
			$this->fields = $fields;
			$this->values = $values;
		}
		//$this->values = $values;
		$this->category = $category;
		// Set the toolbar
		$this->addToolBar();

		// Display the template
		parent::display($tpl);
		
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar()
	{
		JFactory::getApplication()->input->set('hidemainmenu',true);
		$isNew = $this->item->id == 0;
		JToolBarHelper::title($isNew ? JText::_('COM_JSTAR_SHOP')." : ".JText::_('COM_JSTAR_SHOP_PRODUCT')."&nbsp-&nbsp;"." <em>[".JText::_('COM_JSTAR_SHOP_NEW')."]</em>" : JText::_('COM_JSTAR_SHOP')." : ".JText::_('COM_JSTAR_SHOP_PRODUCT')."&nbsp-&nbsp;"." <em>[".JText::_('COM_JSTAR_SHOP_EDIT')."]</em>", 'list-2');
		JToolBarHelper::apply('product.apply2', 'JTOOLBAR_APPLY');
		JToolBarHelper::save('product.save2', 'JTOOLBAR_SAVE');
		JToolBarHelper::custom('product.save2new2', 'save-new.png', 'save-new_f2.png', 'JTOOLBAR_SAVE_AND_NEW', false);
		JToolBarHelper::cancel('product.cancel', 'JTOOLBAR_CANCEL');
	}
}
