<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die( 'Restricted Access' );
class Jstar_shopViewCits extends JViewLegacy
{
	protected $items;
	protected $cits_level;
	protected $pagination;
	protected $state;
	function display( $tpl = null )
	{ 
	
		$this->items		= $this->get('Query2');
		$this->cits_level		= $this->get('cits_level');
		$this->state		= $this->get('State');
		
		Jstar_shopHelper::addSubmenu('cits');
		$this->addToolbar();
		$this->sidebar = JHtmlSidebar::render();
		parent::display( $tpl );
	}
	protected function addToolbar()
	{

				JToolBarHelper::title( JText::_('COM_JSTAR_SHOP').' : '.JText::_('COM_JSTAR_SHOP_CITS'), 'location');
				JToolBarHelper::addNew('cit.add');
				JToolBarHelper::editList('cit.edit');
				JToolBarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', 'cits.delete','JTOOLBAR_DELETE');
	}
}
?>