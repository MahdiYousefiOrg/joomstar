<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.formvalidator');
$pid = JFactory::getApplication()->input->get('pid', 0, 'int');
if(!isset($pid) || trim($pid) == '' || $pid == NULL){
	$app = JFactory::getApplication();
	$app->enqueueMessage(JText::_('COM_JSTAR_SHOP_SELECT_PRODUCT_FIRST'), 'error');
	$app->redirect(JRoute::_('index.php?option=com_jstar_shop&view=products'));
}
$id = JFactory::getApplication()->input->get('id', 0, 'int');
if(isset($id) && trim($id) != '' && $id != NULL){
	$db = JFactory::getDBO();
	$id = $db->escape($id);
	$query = "SELECT `values` FROM `#__jstar_shop_multicosts` WHERE `id` = '$id'";
	$db->SetQuery( $query );
	$values = $db->LoadResult();
	$values = explode('-',$values);
	foreach($values as $value){
		$tmp = explode(':',$value);
		$select[] = $tmp['1']; 
	}
}
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "multicost.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
?>
<style>
header.header{
	display:none !important;
}
ul{
	list-style:none;
}
</style>
<?php
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=multicost&layout=edit&pid='.$pid.'id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->fields as $fieldset){
			   $options = explode('-',$fieldset->value);
		   ?>
				<li>
                    <label id="jform_field-<?php echo $fieldset->id; ?>" for="jform_field-<?php echo $fieldset->id; ?>" class="required invalid">
        				<?php echo $fieldset->title; ?><span class="star">&nbsp;*</span></label>
                    <select name="jform[field_<?php echo $fieldset->title; ?>]" id="jform_field-<?php echo $fieldset->id; ?>" aria-required="true" required="required" class="invalid" aria-invalid="true">
                    <option value="">----------</option>
                    <?php foreach ($options as $option) { 
						if(in_array($option,$select)){
							$selected = 'selected="SELECTED"';
						} else {
							$selected = '';
						}
					?>
                    	  <option <?php echo $selected; ?> value="<?php echo $option; ?>"><?php echo $option; ?></option>
                    <?php } ?>
                    </select>
               </li>
<?php } ?>
			</ul>
         </fieldset>
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset() as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
				
			</ul>
         </fieldset>
		<input type="hidden" name="task" value="multicost.edit" />
		<input type="hidden" name="pid" value="<?php echo $pid; ?>" />
		<input type="hidden" name="id" value="<?php echo $id; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
</td>
</table>


