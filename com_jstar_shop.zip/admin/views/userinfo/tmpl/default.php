<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$db = JFactory::getDBO();
$query = "SELECT `city` FROM `#__jstar_shop_cits` WHERE `id` = ".$this->items->state;
$db->SetQuery($query);
$state = $db->LoadResult();

$query = "SELECT `city` FROM `#__jstar_shop_cits` WHERE `id` = ".$this->items->city;
$db->SetQuery($query);
$city = $db->LoadResult();
 ?>
	<table class="table table-striped" id="usersList">
   	 <thead>
    	<tr style="background:none" >
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_NAME_FAMILY'); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_MOBILE'); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_STATE'); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_CITY'); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_POSTAL_CODE'); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_ADDRESS'); ?></th>
         </tr>
     	</thead>
        <tbody>
        	<tr>
            	<td class="nowrap center"><?php echo $this->items->name2; ?></td>
            	<td class="nowrap center"><?php echo $this->items->mobile; ?></td>
            	<td class="nowrap center">
					<?php echo $state; ?>
                </td>
            	<td class="nowrap center">
					<?php echo $city; ?>
                </td>
            	<td class="nowrap center"><?php echo $this->items->postalcode; ?></td>
            	<td class="nowrap center"><?php echo $this->items->address; ?></td>
            </tr>
		</tbody>
	</table>