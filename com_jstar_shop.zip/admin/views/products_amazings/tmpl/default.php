<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.modal');
$user = JFactory::getUser();

$canOrder = $user->authorise('core.edit.state', 'com_jstar_shop');
$saveOrder = $this->sortColumn == 'products.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_jstar_shope&task=products.saveOrderAjax&tmpl=component';
	JHtml::_('sortablelist.sortable', 'productsList', 'adminForm', strtolower($this->sortDirection), $saveOrderingUrl);
}
$db = JFactory::getDBO();
$id = JFactory::getApplication()->input->get('id', '0', 'int');
$amazings = Jstar_shop_CHeckupHelper::getAmazings();
if(is_numeric($id) && $id != 0) {
    $id = $db->escape($id);
    $query = "SELECT `pids` FROM `#__jstar_shop_amazings` WHERE `id` = $id";
} else {
    $query = "SELECT `pids` FROM `#__jstar_shop_amazings`";
}
$db->setQuery($query);
$curent_pids = $db->LoadResult();
$curent_pids = explode(',',$curent_pids);
$array_diff = array_diff($amazings,$curent_pids);
?>
<script type="text/javascript">
Joomla.orderTable = function()
{
table = document.getElementById("productsList");
direction = document.getElementById("directionTable");
order = table.options[table.selectedIndex].value;
if (order != '<?php echo $this->sortColumn; ?>')
{
dirn = 'asc';
}
else
{
dirn = direction.options[direction.selectedIndex].value;
}
Joomla.tableOrdering(order, dirn, '');
}

function setProducts(id,n){
var str=id;
var checked = document.getElementById("cb"+n).checked; 
if(checked){
	var ischeck = 1;
} else {
	var ischeck = 0;
} 
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  /*if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
  }*/
  }
	xmlhttp.open("GET",'index.php?option=com_jstar_shop&view=products_amazings&format=raw&ischeck='+ischeck+'&pid='+str ,true);
	xmlhttp.send();
}

</script>
<style>
a.red{
	color:#ff0000;
}
</style>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=products_amazings&tmpl=component'); ?>" method="post" name="adminForm" id="adminForm" style="width:100%">
	<div id="j-main-container" class="span12">
		<div id="filter-bar" class="btn-toolbar">
            <div class="btn-group pull-right hidden-phone">
            <label for="limit" class="element-invisible">
            <?php echo JText::_
            ('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?>
            </label>
            <?php echo $this->pagination->getLimitBox(); ?>
            </div>
		<div class="filter-search btn-group pull-left">
     
				<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('JSEARCH_FILTER'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" class="" title="" />
			</div>
			<div class="btn-group pull-left">
				<button type="submit" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				<button type="button" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.getElementById('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
			</div>
            
			<select name="filter_categoryid" class="input-medium" onchange="this.form.submit()" style="margin-right:20px;">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_jstar_shop'), 'value', 'text', $this->state->get('filter.categoryid'));?>
			</select>
            
		</div>
		<div class="clearfix"> </div>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
	<table class="table table-striped" id="productsList">
    <thead>
    	<tr style="background:none" >
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
					<th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_TITLE', 'title',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_CATEGORY', 'category',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_PRICE', 'price',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_CUSTOM_FIELDS'); ?></th>
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_MULTI_COST5'); ?></th>
        </tr>
     </thead>
        <tfoot>
        <tr>
        <td colspan="8"><?php echo $this->pagination->getListFooter(); ?>
        </td>
        </tr>
        </tfoot>
			<?php $k = 1; $n = 0;
			foreach ($this->items as $i => $item) :
				@$checked = $_SESSION['amazing'][$item->id];
				if(isset($checked) && $checked == 1) {
					$ischeck = "checked='CHECKED'";
				} else {
					$ischeck = '';
				}
?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php $k; ?>
			                </td>
                            <td class="center">
                                <?php if(!in_array($item->id,$array_diff)  ) { ?>
			                   <input <?php echo $ischeck; ?> onchange="setProducts(<?php echo $item->id.','.$n; ?>)" type="checkbox" name="cid[]" value="<?php echo $item->id; ?>" id="cb<?php echo $n; ?>" />
                                <?php } else { ?>
                                    <input type="checkbox" disabled />
                                <?php } ?>
			                </td>
							<td class="center">
								<?php echo $this->escape($item->title); ?>
                            </td>
							<td class="center">
								<?php echo $this->escape($item->category); ?>
                            </td>
							<td class="center">
								<?php echo $this->escape($item->off); ?>
                            </td>
                            <td class="center">
								<a href="<?php echo 'index.php?option=com_jstar_shop&view=field_product&id='.$item->id ?>&tmpl=component" class="modal" rel="{handler: 'iframe', size: {x: 575, y: 300}}"><?php echo JText::_('COM_JSTAR_SHOP_SHOW_DETILES'); ?></a>
                            </td>
                            <?php 
							
									$query = "SELECT `catid` FROM `#__jstar_shop_products` WHERE `id` = '$item->id'";
									$db->SetQuery($query);
									$catid = $db->LoadResult();
									
									$query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catid' ORDER BY `parent`.`lft` ";
									$db->setQuery( $query );
									$idstr = $db->LoadColumn();
									
									$idstr = implode(',',$idstr);  
									$query = "SELECT `id` FROM `#__jstar_shop_customfields` WHERE catid IN ($idstr) AND multi = 1"; 
									$db->setQuery( $query );
									$rows = $db->LoadColumn();
									if(empty($rows) || $item->multicost == 0){ ?>
                                    	<td class="center"><?php echo JText::_('COM_JSTAR_SHOP_NO_MULTI_PRICE'); ?></td>
								<?php } else { ?>
                                    <td class="center">
                                    	<?php
										$query = "SELECT COUNT(*) FROM `#__jstar_shop_multicosts` WHERE `pid` = '$item->id'";
										$db->SetQuery( $query );
										$count = $db->LoadResult();
										if($count == 0){
											$a_class = 'red';
										} else {
											$a_class = '';
										}
										?>
                                        <a  href="<?php echo 'index.php?option=com_jstar_shop&view=multicosts&pid='.$item->id ?>" class="modal <?php echo $a_class; ?>" rel="{handler: 'iframe', size: {x: 790, y: 550}}"><?php echo JText::_('COM_JSTAR_SHOP_MULTI_COST'); ?></a><br />
										<?php echo $count; ?>
                                    </td>
                                <?php } ?>
				</tr>
			<?php $k++; $n++; endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="id" value="<?php echo @$id; ?>" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="form" value="1" />
        <input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
  </div>
</form>
