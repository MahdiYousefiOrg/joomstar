<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument();
$css = 
$doc->addStyleSheet(JURI::root().'media/com_jstar_shop/css/dashboard.css');
$image_link = JURI::root().'administrator/components/com_jstar_shop/views/dashboard/images/'
?>
<div class="row-fluid">
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_categories&view=categories&extension=com_jstar_shop'); ?>">
        	<img src="<?php echo $image_link.'categories.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_CATEGORIES'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=group_fields'); ?>">
        	<img src="<?php echo $image_link.'fields.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_GROUP_FIELDS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=customfields'); ?>">
        	<img src="<?php echo $image_link.'field.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_CUSTOMFIELDS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=posts'); ?>">
        	<img src="<?php echo $image_link.'posts.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_POSTS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=products'); ?>">
        	<img src="<?php echo $image_link.'products.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_PRODUCTS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=similars'); ?>">
        	<img src="<?php echo $image_link.'similars.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_SIMILARS'); ?></span>
        </a>
    </div>
</div>
<div class="row-fluid row2">
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=gifts'); ?>">
        	<img src="<?php echo $image_link.'gifts.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_GIFTS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=amazings'); ?>">
        	<img src="<?php echo $image_link.'amazings.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_AMAZINGS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=coupons'); ?>">
        	<img src="<?php echo $image_link.'coupons.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_COUPONS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=coupon_users'); ?>">
        	<img src="<?php echo $image_link.'users_coupon.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_COUPON_USERS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=price_categories'); ?>">
        	<img src="<?php echo $image_link.'price_categories.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_PRICE_CATEGORIES'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=users'); ?>">
        	<img src="<?php echo $image_link.'users.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_PRICE_USERS_LIST'); ?></span>
        </a>
    </div>
</div>
<div class="row-fluid row2">
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=orders'); ?>">
        	<img src="<?php echo $image_link.'orders.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_PRICE_ORDERS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=payks'); ?>">
        	<img src="<?php echo $image_link.'payks.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_PAYKS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=recommends'); ?>">
        	<img src="<?php echo $image_link.'recommends.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_RECOMMENDS'); ?></span>
        </a>
    </div>
	<div class="span2 boxes">
    	<a class="" href="<?php echo JRoute::_('index.php?option=com_config&view=component&component=com_jstar_shop'); ?>">
        	<img src="<?php echo $image_link.'seetings.png'; ?>" />
            <span class="txt_link"><?php echo JText::_('COM_JSTAR_SHOP_CONFIGURATION'); ?></span>
        </a>
    </div>
</div>