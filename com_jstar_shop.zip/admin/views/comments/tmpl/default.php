<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$user = JFactory::getUser();
$canOrder = $user->authorise('core.edit.state', 'com_jstar_shop');
$pid = JFactory::getApplication()->input->get('id', '0', 'int');
?>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=comments&id='.$pid); ?>" method="post" name="adminForm" id="adminForm" style="width:100%">
	<div id="j-main-container" class="span12">
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
	<table class="table table-striped" id="coupon_usersList">
    <thead>
    	<tr style="background:none" >
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
					<th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_USER', 'name',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_COMMENT', 'comment',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_STATUS'); ?></th>
        </tr>
     </thead>
        <tfoot>
        <tr>
        <td colspan="5"><?php echo $this->pagination->getListFooter(); ?>
        </td>
        </tr>
        </tfoot>
			<?php $k = 1;
			foreach ($this->items as $i => $item) :
?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php echo $k; ?>
			                </td>
                            <td class="center">
			                    <?php echo JHtml::_('grid.id',   $i, $item->id)?>
			                </td>
							<td class="center">
								<?php echo $this->escape($item->name); ?>
                            </td>
							<td class="center">
								<?php echo $this->escape($item->comment); ?>
                            </td>
                            <td class="center">
                            	<?php if ($item->published == 1) { ?>
								<a href="<?php echo 'index.php?option=com_jstar_shop&task=comments.unpublish2&cid[]='.$item->id.'&id='.$pid ?>"><i class="icon-publish"></i></a>
                                <?php } else { ?>
								<a href="<?php echo 'index.php?option=com_jstar_shop&task=comments.publish&cid[]='.$item->id.'&id='.$pid ?>"><i class="icon-unpublish"></i></a>
                                <?php } ?>
						</td>				
				</tr>
			<?php $k++; endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
        <input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>" />
    		<?php echo JHtml::_('form.token'); ?>
	</div>
  </div>
</form>
