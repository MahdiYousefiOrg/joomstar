<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die( 'Restricted Access' );
class Jstar_shopViewField_product extends JViewLegacy
{
	protected $fields;
	protected $values;
	function display( $tpl = null )
	{ 
		$this->fields		= $this->get('Fields');
		$this->values		= $this->get('Values');
			if (count($errors = $this->get('Errors'))) { 
				JFactory::getApplication()->enqueueMessage(implode("\n", $errors), 'error');
				return false;
			} 
		parent::display( $tpl );
	}
}
?>