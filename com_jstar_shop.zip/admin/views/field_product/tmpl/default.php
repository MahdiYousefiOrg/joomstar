<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument();
$doc->addStyleSheet(JURi::root() . 'media/com_jstar_shop/css/admin.field_product.css');
?>
<table id="table1">
    <tr>
        <th><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
        <th><?php echo JText::_('COM_JSTAR_SHOP_VALUES'); ?></th>
    </tr>
    <?php
    $i = 0;
    foreach ($this->fields as $field) { ?>
        <tr>
        <td><?php echo $field->title; ?></td>
        <?php if ($field->id == @$this->values[$i]->field_id) {
            @$value = @$this->values[$i]->values;
        }
        if ($field->type != 4 && $field->type != 5) { ?>
            <td><?php echo @$value; ?></td>
        <?php }
        if ($field->type == 4) { ?>
            <td>
                <?php $values = explode('-', $field->value);
                $check = explode('-', @$value);
                foreach ($values as $list) {
					 if (in_array($list, $check)) { ?>
                        <div class="check"> <?php echo $list; ?></div><?php } ?>
                <?php } ?>
            </td>
            </tr>
        <?php }
        if ($field->type == 5) { ?>
            <td>
                <?php
                $values = explode(',', @$value);
                foreach ($values as $list) {
                    ?>

                    <div class="check color" style="background:<?php echo $list; ?>"></div>
                <?php } ?>
            </td>
            </tr>
        <?php }
        $i++;
    }
    ?>
</table>
                 