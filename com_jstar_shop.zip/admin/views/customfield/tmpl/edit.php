<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access'); 
$doc = JFactory::getDocument(); 
$doc->addStyleSheet(JURi::root().'media/com_jstar_shop/css/admin.stylesheet.css'); 
$doc->addScript(JURi::root().'media/com_jstar_shop/js/admin/customfield.js'); 
JHTML::_('behavior.formvalidator');
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "customfield.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
?>
<style>
#jform_multi-lbl, #jform_multi{
	display:none;
}
</style>
<?php
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
$id = JFactory::getApplication()->input->get('id', 0, 'int');
	if(!isset($id) || $id == NULL || $id == 0 || $id == '' || ($this->item->type == 1)){ ?>
		<script type="text/javascript">
		window.onload = function() {
			document.getElementById('jform_value-lbl').style.display='none';
			document.getElementById('jform_value').style.display='none';
		}
		</script>
	<?php } 
	if(isset($id) && $id != 0 && $id != NULL && trim($id) != ''){
		$db = JFactory::getDBO();
		$id = $db->escape($id);
		$query = "SELECT `type` FROM `#__jstar_shop_customfields` WHERE `id` = '$id'"; 
		$db->SetQuery( $query );
		$type = $db->LoadResult();
		if($type == 2 || $type == 3 || $type == 5){ ?>
        	<style>
				#jform_multi-lbl, #jform_multi{
					display:block;
				}
			</style>
		<?php }
	}?>

<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>

<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=customfield&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php 
		   		echo '<li>'.$this->form->getLabel('catid').$this->form->getInput('catid').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('title').$this->form->getInput('title').'</li>';
				if(!isset($id) || $id == NULL || $id == 0 || trim($id )== '') {
					echo '<li>'.$this->form->getLabel('group_id').$this->form->getInput('group_id').'</li>'; 
				} else {
					echo '<li>'.$this->form->getLabel('group_id'); ?>
                    <select id="jform_group_id" name="group_id" required="required" aria-required="true">
                    	<?php foreach($this->groupfields as $groupfields) {
								if($this->groupid == $groupfields->id) {
									$select = "selected = selected";
								} else {
									$select = "";
								}
						?>
                            <option value="<?php echo $groupfields->id; ?>" <?php echo $select; ?>><?php echo $groupfields->title; ?></option>
                        <?php } ?>
                    </select>
				<?php }
		   		echo '<li>'.$this->form->getLabel('type').$this->form->getInput('type').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('value').$this->form->getInput('value').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('main').$this->form->getInput('main').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('multi').$this->form->getInput('multi').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('fields').$this->form->getInput('fields').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('search').$this->form->getInput('search').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('published').$this->form->getInput('published').'</li>'; 
		   		echo '<li>'.$this->form->getLabel('id').$this->form->getInput('id').'</li>'; 
		  ?>
			</ul>
         </fieldset>

		<input type="hidden" name="task" value="customfield.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
</td>
</table>


