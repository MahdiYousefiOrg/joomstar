<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die( 'Restricted Access' );
class Jstar_shopViewAmazings extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;
	function display( $tpl = null )
	{ 
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination'); 
		$this->state		= $this->get('State');
		$this->sortDirection = $this->state->get('list.direction');
		$this->sortColumn = $this->state->get('list.ordering');
			if (count($errors = $this->get('Errors'))) { 
				JFactory::getApplication()->enqueueMessage(implode("\n", $errors), 'error');
				return false;
			} 
		Jstar_shopHelper::addSubmenu('amazings');
		$this->addToolbar();
		$this->sidebar = JHtmlSidebar::render();
		parent::display( $tpl );
	}
	protected function addToolbar()
	{

				JToolBarHelper::title( JText::_('COM_JSTAR_SHOP').' : '.JText::_('COM_JSTAR_SHOP_AMAZINGS'), 'basket');
				JToolBarHelper::addNew('amazing.add');
				JToolBarHelper::editList('amazing.edit');
				JToolBarHelper::preferences('com_jstar_shop');
				JToolBarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', 'amazings.delete','JTOOLBAR_DELETE');
	}
}
?>