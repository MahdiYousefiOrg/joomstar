<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.formvalidator');
$doc = JFactory::getDocument(); 
$doc->addStyleSheet(JURi::root().'media/com_jstar_shop/css/admin.stylesheet.css'); 
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "group_field.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=group_field&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset() as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
				
			</ul>
         </fieldset>

		<input type="hidden" name="task" value="group_field.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
</td>
</table>


