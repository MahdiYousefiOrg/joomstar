<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument(); 
$doc->addStyleSheet(JURi::root().'media/com_jstar_shop/css/admin.gift.css'); 
$id = JFactory::getApplication()->input->get('id', '0', 'int');
$submit = JFactory::getApplication()->input->get('submit', null, 'string');
JHTML::_('behavior.formvalidator');
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "gift.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<script type="text/javascript">
	function getValues(){
		document.getElementById("title").value = document.getElementById("jform_title").value;
		document.getElementById("price").value = document.getElementById("jform_price").value;
		document.getElementById("img").value = document.getElementById("jform_img").value;
	}
</script>
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=gift&layout=edit'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<div class="width-200 fltlft">
		<fieldset class="adminform">
			<ul class="adminformlist">
           <?php foreach($this->form->getFieldset() as $fieldset){ ?>
				<li><?php echo $fieldset->label; ?>
				<?php echo $fieldset->input; ?></li>
<?php } ?>
			</ul>
         </fieldset>
         <input type="hidden" name="id" value="<?php echo $id; ?>" />
		 <?php echo JHtml::_('form.token'); ?>
	</div>
</form>
<?php if(!empty($this->fields)) {
		
		if(isset($id) && trim($id) != '' && $id != 0 && !isset($submit)){ 
			$db = JFactory::getDBO();
			$query = "SELECT `catid`,`feilds` FROM `#__jstar_shop_gifts` WHERE `id` = '$id'";
			$db->setQuery( $query );
			$result = $db->LoadObject();
			$field_arr = $result->feilds;
			$field_arr = explode(',',$field_arr);
			$_SESSION['search2'] = $field_arr;
			$catid = $result->catid;
		} 
			$catid = JFactory::getApplication()->input->get('catid');
		
 ?>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=gift2&layout=edit'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
        <?php foreach($this->fields as $row) { 
				if($row->type != 1){
					$values = explode('-',$row->value);
					echo '<div class=" border">';
					echo '<div class="header_title">'.$row->title.'</div>';
					echo '<ul>';
					foreach($values as $value){
						if(isset($_SESSION['search2'])){
							if(in_array($row->id.'-'.$value,$_SESSION['search2'])){
								@$checked = 'checked="CHECKED"';
							} else {
								$checked = '';
							}
						}
						echo '<li>';
						echo ' <input type="checkbox" name="search[]" value="'.$row->id.'-'.$value.'" '.@$checked.' /> '.$value;
						echo '</li>';
					}
					echo '</ul>';
					echo '</div>';
				}
		?>
		<?php } ?>
        <div class="clear"></div>
        	<input type="hidden" name="option" value="com_jstar_shop" />
        	<input type="hidden" name="catid" value="<?php echo $catid; ?>" />
        	<input type="hidden" name="id" value="<?php echo $id; ?>" />
        	<input type="hidden" id="title" name="title" value="" />
        	<input type="hidden" id="price" name="price" value="" />
        	<input type="hidden" id="img" name="img" value="" />
            <input type="submit" onclick="getValues()" class="btn-success bottom" name="submit" value="<?php echo JText::_('COM_JSTAR_SHOP_ADD_GIFT'); ?>" />
</form>
<?php } ?>
</td>
</table>


