<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$user = JFactory::getUser();
$canOrder = $user->authorise('core.edit.state', 'com_jstar_shop');
$saveOrder = $this->sortColumn == 'similars.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_jstar_shop&task=similars.saveOrderAjax&tmpl=component';
	JHtml::_('sortablelist.sortable', 'similarsList', 'adminForm', strtolower($this->sortDirection), $saveOrderingUrl);
}

?>
<script type="text/javascript">
Joomla.orderTable = function()
{
table = document.getElementById("similarsList");
direction = document.getElementById("directionTable");
order = table.options[table.selectedIndex].value;
if (order != '<?php echo $this->sortColumn; ?>')
{
dirn = 'asc';
}
else
{
dirn = direction.options[direction.selectedIndex].value;
}
Joomla.tableOrdering(order, dirn, '');
}
</script>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=similars'); ?>" method="post" name="adminForm" id="adminForm" style="width:100%">
<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
<?php endif;?>
	<div id="j-main-container" class="span10">
		<div id="filter-bar" class="btn-toolbar">
            <div class="btn-group pull-right hidden-phone">
            <label for="limit" class="element-invisible">
            <?php echo JText::_
            ('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?>
            </label>
            <?php echo $this->pagination->getLimitBox(); ?>
            </div>
                <div class="filter-search btn-group pull-left">
                </div>
		</div>
		<div class="clearfix"> </div>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
	<table class="table table-striped" id="couponsList">
    <thead>
    	<tr style="background:none" >
            <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
            <th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
            <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_CATEGORY', 'code',$this->sortDirection, $this->sortColumn ); ?></th>
            <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_COMMENTS2'); ?></th>
        </tr>
     </thead>
        <tfoot>
        <tr>
        <td colspan="5"><?php echo $this->pagination->getListFooter(); ?>
        </td>
        </tr>
        </tfoot>
			<?php $k = 1;
			foreach ($this->items as $i => $item) :
?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php echo $k; ?>
			                </td>
                            <td class="center">
			                    <?php echo JHtml::_('grid.id',   $i, $item->id)?>
			                </td>
							<td class="center">
								<?php echo $this->escape($item->category); ?>
                            </td>
							<td class="center">
                            <a href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=similar&layout=edit&id='.$item->id).'&catid='.$item->catid; ?>">
								<?php
								if($item->products_id != NULL && trim($item->products_id) != ''){
									$count = count(explode(',',$item->products_id));
									echo JText::_('COM_JSTAR_SHOP_COUNT_GIFT').$count.JText::_('COM_JSTAR_SHOP_GIFT_PRODUCTS_ADD');
                                 } else {
									 echo JText::_('COM_JSTAR_SHOP_GIFT_NO_PRODUCTS_ADD');
								 }
								 ?>
                            </a>
                            </td>
				</tr>
			<?php $k++; endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
        <input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>" />
    		<?php echo JHtml::_('form.token'); ?>
	</div>
  </div>
</form>
