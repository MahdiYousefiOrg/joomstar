<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$user = JFactory::getUser();
$canOrder = $user->authorise('core.edit.state', 'com_jstar_shop');
$saveOrder = $this->sortColumn == 'coupon_users.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_jstar_shop&task=coupon_users.saveOrderAjax&tmpl=component';
	JHtml::_('sortablelist.sortable', 'coupon_usersList', 'adminForm', strtolower($this->sortDirection), $saveOrderingUrl);
}

?>
<script type="text/javascript">
Joomla.orderTable = function()
{
table = document.getElementById("coupon_usersList");
direction = document.getElementById("directionTable");
order = table.options[table.selectedIndex].value;
if (order != '<?php echo $this->sortColumn; ?>')
{
dirn = 'asc';
}
else
{
dirn = direction.options[direction.selectedIndex].value;
}
Joomla.tableOrdering(order, dirn, '');
}
</script>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=coupon_users'); ?>" method="post" name="adminForm" id="adminForm" style="width:100%">
<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
<?php endif;?>
	<div id="j-main-container" class="span10">
		<div id="filter-bar" class="btn-toolbar">
            <div class="btn-group pull-right hidden-phone">
            <label for="limit" class="element-invisible">
            <?php echo JText::_
            ('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?>
            </label>
            <?php echo $this->pagination->getLimitBox(); ?>
            </div>
			<div class="filter-search btn-group pull-left">
				<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('JSEARCH_FILTER'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" class="" title="" />
			</div>
			<div class="btn-group pull-left">
				<button type="submit" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				<button type="button" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.getElementById('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
			</div>
            
		</div>
		<div class="clearfix"> </div>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
	<table class="table table-striped" id="coupon_usersList">
    <thead>
    	<tr style="background:none" >
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
                    <th width="1%" class="nowrap center hidden-phone">
                    	<a data-original-title="<?php echo JText::_('JGRID_HEADING_ORDERING') ?>" href="#" onclick="Joomla.tableOrdering('coupon_users.ordering','asc','');return false;" class="hasTooltip" title=""><i class="icon-menu-2"></i></a>	
                    </th>         
					<th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_USER', 'name',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_PERCENT', 'percent',$this->sortDirection, $this->sortColumn ); ?></th>
        </tr>
     </thead>
        <tfoot>
        <tr>
        <td colspan="5"><?php echo $this->pagination->getListFooter(); ?>
        </td>
        </tr>
        </tfoot>
			<?php $k = 1;
			foreach ($this->items as $i => $item) :
?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php echo $k; ?>
			                </td>
                            <td class="order nowrap center hidden-phone">
                            <?php
                            $disableClassName = '';
                            $disabledLabel = '';
                            if (!$saveOrder) :
                            $disabledLabel = JText::_('JORDERINGDISABLED');
                            $disableClassName = 'inactive tip-top';
                            endif; ?>
                            <span class="sortable-handler hasTooltip <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>">
                            <i class="icon-menu"></i>
                            </span>
                            <input type="text" style="display:none" name="order[]"
                            size="5" value="<?php echo $item->ordering;?>" class="width-20 textarea-order " />
                            </td>                            
                            <td class="center">
			                    <?php echo JHtml::_('grid.id',   $i, $item->id)?>
			                </td>
							<td class="center">
                            <a href="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=coupon_user&layout=edit&id='.$item->id); ?>">
								<?php echo $this->escape($item->name); ?>
                            </a>
                            </td>
							<td class="center">
								<?php echo $this->escape($item->percent); ?>
                            </td>
				</tr>
			<?php $k++; endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
        <input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>" />
    		<?php echo JHtml::_('form.token'); ?>
	</div>
  </div>
</form>
