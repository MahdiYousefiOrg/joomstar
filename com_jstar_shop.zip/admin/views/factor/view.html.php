<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
class Jstar_shopViewFactor extends JViewLegacy
{
	protected $items;
	protected $coupon;
	protected $usercoupon;

	public function display($tpl = null)
	{

			$this->items         = $this->get('Factor'); 
			$this->coupon         = $this->get('Coupon');
			$this->usercoupon         = $this->get('User_coupon'); 
		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			JFactory::getApplication()->enqueueMessage(implode("\n", $errors), 'error');

			return false;
		}
		parent::display($tpl);
	}
}
