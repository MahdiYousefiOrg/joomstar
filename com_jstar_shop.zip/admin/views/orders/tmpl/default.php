<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.modal');
$db = JFactory::getDBO();
$query = "SELECT `a`.`id` as `aid`, `a`.`name_family` FROM `#__jstar_shop_payks` AS `a`";
$db->SetQuery( $query );
$payk_orders = $db->LoadObjectList();
$options        = array();
foreach($payk_orders as $value){
	$options[]      = JHtml::_('select.option', $value->aid, $value->name_family);
}
?>
<style>
select{
	width:auto !important;
}
</style>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=orders'); ?>" method="post" name="adminForm" id="adminForm" style="width:100%">
<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
<?php endif;?>
	<div id="j-main-container" class="span10">
		<div id="filter-bar" class="btn-toolbar">
            <div class="btn-group pull-right hidden-phone">
            <label for="limit" class="element-invisible">
            <?php echo JText::_
            ('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?>
            </label>
            <?php echo $this->pagination->getLimitBox(); ?>
            </div>
		<div class="filter-search btn-group pull-left">
     
				<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('COM_JSTAR_SHOP_PRODUCT_USER'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" class="" title="" />
			</div>
			<div class="btn-group pull-left">
				<button type="submit" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				<button type="button" class="btn hasTooltip" title="<?php echo JHtml::tooltipText('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.getElementById('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
			</div>
            <select name="filter_payk" class="inputbox" onchange="this.form.submit()" style="margin-right:20px; width:150px">
                        <option value=""><?php echo JText::_('COM_JSTAR_SHOP_SELECT_PAYK');?></option>
                        <?php echo JHtml::_('select.options', $options, 'value', 'text', $this->state->get('filter.payk'), true);?>
            </select>
            
		</div>
		<div class="clearfix"> </div>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
	<table class="table table-striped" id="ordersList">
    <thead>
    	<tr style="background:none" >
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
					<th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_USER', 'name',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_SH_FACTOR', 'sh',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_DATE_ORDER', 'date2',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_ORDER'); ?></th>
                    <th class="nowrap center"><?php echo JHTML::_('grid.sort',  'COM_JSTAR_SHOP_PAYMENT_METHOD', 'payment_method',$this->sortDirection, $this->sortColumn ); ?></th>
                    <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_PAYKS'); ?></th>
        </tr>
     </thead>
        <tfoot>
        <tr>
        <td colspan="8"><?php echo $this->pagination->getListFooter(); ?>
        </td>
        </tr>
        </tfoot>
			<?php $k = 1;
			foreach ($this->items as $i => $item) : ?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php echo $k; ?>
			                </td>
                            <td class="center">
			                    <?php echo JHtml::_('grid.id',   $i, $item->sh); ?>
			                </td>
							<td class="center">
                            	<a class="modal" rel="{handler: 'iframe', size: {x: 575, y: 300}}" href="index.php?option=com_jstar_shop&view=userinfo&tmpl=component&orderid=<?php echo $item->sh; ?>">
								<?php echo $this->escape($item->name); ?>
                                </a>
                            </td>
							<td class="center">
                            	<a class="modal" rel="{handler: 'iframe', size: {x: 575, y: 300}}" href="index.php?option=com_jstar_shop&view=factor&tmpl=component&sh=<?php echo $item->sh; ?>&userid=<?php echo $item->user_id; ?>">
									<?php echo $this->escape($item->sh); ?>
                                </a>
                            </td>
							<td class="center">
								<?php echo JHtml::date($this->escape($item->date2),'DATE_FORMAT_LC'); ?>
                            </td>
							<td class="center">
                            	<select name="status[<?php echo $item->sh; ?>]" onchange="form.submit();">
                                	<option <?php if($item->status == -2) echo 'selected="SELECTED"'; ?> value="-2"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_-2'); ?></option>
                                	<option <?php if($item->status == -1) echo 'selected="SELECTED"'; ?> value="-1"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_-1'); ?></option>
                                	<option <?php if($item->status == 0) echo 'selected="SELECTED"'; ?> value="0"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_1'); ?></option>
                                	<option <?php if($item->status == 1) echo 'selected="SELECTED"'; ?> value="1"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_2'); ?></option>
                                	<option <?php if($item->status == 2) echo 'selected="SELECTED"'; ?> value="2"><?php echo JText::_('COM_JSTAR_SHOP_STATUS_3'); ?></option>
                                </select>
                            </td>
							<td class="center">
                            	<select name="payments[<?php echo $item->sh; ?>]" onchange="form.submit();">
                                	<option value="-1"><?php echo JText::_('COM_JSTAR_SHOP_SELECT'); ?></option>
                                	<?php if($item->status != -2 && $item->status!=-1) { ?>
                                	<option <?php if(@$item->payment_method == 1) echo 'selected="SELECTED"'; ?> value="1"><?php echo JText::_('COM_JSTAR_SHOP_PAYMENT_ELECTORONIC'); ?></option>
                                	<option <?php if(@$item->payment_method == 2) echo 'selected="SELECTED"'; ?> value="2"><?php echo JText::_('COM_JSTAR_SHOP_PAYMENT_NAGHDI'); ?></option>
                                	<option <?php if(@$item->payment_method == 3) echo 'selected="SELECTED"'; ?> value="3"><?php echo JText::_('COM_JSTAR_SHOP_PAYMENT_MAHAL'); ?></option>
                                    <?php } ?>
                                </select>
                            </td>
							<td class="center">
                            	<select name="payks[<?php echo $item->sh; ?>]" onchange="form.submit();">
                                	<option value="-1"><?php echo JText::_('COM_JSTAR_SHOP_SELECT'); ?></option>
                                    <?php foreach($payk_orders as $value) {
											$query = "SELECT `payk_id` FROM `#__jstar_shop_payks_orders` WHERE `factor` = '$item->sh'"; 
											$db->SetQuery( $query );
											$selected = $db->LoadResult();
									?>
                                        <option <?php if(@$value->aid == @$selected) echo 'selected="SELECTED"'; ?> value="<?php echo $value->aid; ?>"><?php echo $value->name_family; ?></option>
                                    <?php } ?>
                                </select>
                            </td>
				</tr>
			<?php $k++; endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
        <input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>" />
    		<?php echo JHtml::_('form.token'); ?>
	</div>
  </div>
</form>
