<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
class Jstar_shopViewSimilar2 extends JViewLegacy
{
	public function display($tpl = null)
	{
		$products = $this->get('Products');
		if (count($errors = $this->get('Errors')))
		{
			JFactory::getApplication()->enqueueMessage(implode('<br />', $errors));
			return false;
		}
		// Assign the Data
		$this->products = $products;

		// Set the toolbar
		$this->addToolBar();

		// Display the template
		parent::display($tpl);
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar()
	{
		JFactory::getApplication()->input->set('hidemainmenu',true);
		JToolBarHelper::title(JText::_('COM_JSTAR_SHOP')." : ".JText::_('COM_JSTAR_SHOP_SIMILAR')."&nbsp-&nbsp;"." <em>[".JText::_('COM_JSTAR_SHOP_NEW')."]</em>", 'shuffle');
		JToolBarHelper::custom('similar.addproducts', 'save-new.png', 'save-new_f2.png', 'COM_JSTAR_SHOP_ADD_SIMILAR_PRODUCTS', false);
		JToolBarHelper::cancel('similar.cancel', 'JTOOLBAR_CANCEL');
	}
}
