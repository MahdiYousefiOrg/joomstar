<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
$doc = JFactory::getDocument(); 
$doc->addStyleSheet(JURi::root().'media/com_jstar_shop/css/admin.stylesheet.css'); 
JHtml::_('behavior.modal');
JHTML::_('behavior.formvalidator');
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "similar2.cancel" || document.formvalidator.isValid(document.getElementById("adminForm")))
		{
			Joomla.submitform(task, document.getElementById("adminForm"));
		}
	};
');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
$db = JFactory::getDBO();
$id = $_SESSION['lastid'];
$id = $db->escape($id);
$query = "SELECT `products_id` FROM `#__jstar_shop_similars` WHERE `id` = '$id'";
$db->setQuery( $query );
$products_id = $db->LoadResult();
$products_id = explode(',',$products_id);
?>
<form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=similar2&layout=edit'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
<?php if (empty($this->products)) : ?>
	<div class="alert alert-no-items">
		<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
	</div>
<?php else : ?>
	<table class="table table-striped" id="productsList">
    <thead>
    	<tr style="background:none" >
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_FIELD_ROW_LABEL'); ?></th>
					<th width="1%" class="nowrap center"><?php echo JHtml::_('grid.checkall'); ?></th>
                    <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_TITLE'); ?></th>
                    <th class="nowrap center"><?php echo JText::_('COM_JSTAR_SHOP_PRICE'); ?></th>
                    <th class="nowrap center" style="width:10%"><?php echo JText::_('COM_JSTAR_SHOP_CUSTOM_FIELDS'); ?></th>
        </tr>
     </thead>
			<?php $k = 1; 
			
			foreach ($this->products as $i => $item) :
				if(in_array($item->id,$products_id)){
					$checked = 'checked="CHECKED"';
				} else {
					$checked = '';
				}
?>
				<tr class="row<?php echo $i % 2; ?>">
                            <td class="center">
			                    <?php echo $k; ?>
			                </td>
                            <td class="center">
			                    <input id="cb<?php echo $i; ?>" name="cid[]" <?php echo $checked; ?> value="<?php echo $item->id; ?>"  type="checkbox">
			                </td>
							<td class="center">
								<?php echo $this->escape($item->title); ?>
                            </td>
							<td class="center">
								<?php echo $this->escape($item->price); ?>
                            </td>
                            <td class="center">
								<a href="<?php echo 'index.php?option=com_jstar_shop&view=field_product&id='.$item->id ?>&tmpl=component" class="modal" rel="{handler: 'iframe', size: {x: 575, y: 300}}"><?php echo JText::_('COM_JSTAR_SHOP_SHOW_DETILES'); ?></a>
                            </td>
				</tr>
			<?php $k++; endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>
    		<input type="hidden" name="task" value="" />
            <input type="hidden" name="boxchecked" value="0" />
            <?php echo JHtml::_('form.token'); ?>
</form>


