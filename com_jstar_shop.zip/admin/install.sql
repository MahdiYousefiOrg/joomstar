CREATE TABLE `#__jstar_shop_amazings` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `pids` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `date1` datetime DEFAULT NULL,
  `date2` datetime DEFAULT NULL,
  `off` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `text` text COLLATE utf8_persian_ci DEFAULT NULL,
  `module` tinyint(1) NOT NULL DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_bankmsg`
--

CREATE TABLE `#__jstar_shop_bankmsg` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_cits`
--

CREATE TABLE `#__jstar_shop_cits` (
  `id` int(11) NOT NULL,
  `parentid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `store` tinyint(1) NOT NULL DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_comments`
--

CREATE TABLE `#__jstar_shop_comments` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_coupons`
--

CREATE TABLE `#__jstar_shop_coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `percent` varchar(255) DEFAULT NULL,
  `date1` date DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_coupon_users`
--

CREATE TABLE `#__jstar_shop_coupon_users` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `percent` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_customfields`
--

CREATE TABLE `#__jstar_shop_customfields` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `main` tinyint(1) DEFAULT NULL,
  `multi` tinyint(1) NOT NULL DEFAULT 0,
  `fields` tinyint(1) NOT NULL DEFAULT 1,
  `search` tinyint(1) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_feilds_products`
--

CREATE TABLE `#__jstar_shop_feilds_products` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `field_id` int(11) DEFAULT NULL,
  `values` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_gifts`
--

CREATE TABLE `#__jstar_shop_gifts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `catid` int(11) DEFAULT NULL,
  `img` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `products_id` text COLLATE utf8_persian_ci DEFAULT NULL,
  `feilds` text COLLATE utf8_persian_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_group_fields`
--

CREATE TABLE `#__jstar_shop_group_fields` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_interests`
--

CREATE TABLE `#__jstar_shop_interests` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_multicosts`
--

CREATE TABLE `#__jstar_shop_multicosts` (
  `id` int(11) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `values` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `cost1` int(11) DEFAULT NULL,
  `cost2` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_orders`
--

CREATE TABLE `#__jstar_shop_orders` (
  `id` int(11) NOT NULL,
  `sh` varchar(255) CHARACTER SET utf8 COLLATE utf8_persian_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `fieldid` int(11) DEFAULT NULL,
  `count2` varchar(255) DEFAULT NULL,
  `coupon` varchar(255) DEFAULT NULL,
  `usercoupon` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `giftid` varchar(255) DEFAULT NULL,
  `typePost` int(11) NOT NULL DEFAULT 0,
  `amazing` tinyint(1) NOT NULL DEFAULT 0,
  `amazing_off` int(3) NOT NULL DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_order_details`
--

CREATE TABLE `#__jstar_shop_order_details` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `sh_order` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `address` text COLLATE utf8_persian_ci DEFAULT NULL,
  `postalcode` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `payment_method` tinyint(1) DEFAULT NULL,
  `bank` varchar(11) COLLATE utf8_persian_ci DEFAULT NULL,
  `RefID` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_payks`
--

CREATE TABLE `#__jstar_shop_payks` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `name_family` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_payks_orders`
--

CREATE TABLE `#__jstar_shop_payks_orders` (
  `id` int(11) NOT NULL,
  `factor` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `payk_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_posts`
--

CREATE TABLE `#__jstar_shop_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `type_post` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `cits` text COLLATE utf8_persian_ci DEFAULT NULL,
  `price1` int(11) DEFAULT NULL,
  `price2` int(11) DEFAULT NULL,
  `w1` int(11) DEFAULT NULL,
  `w2` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `comment` text COLLATE utf8_persian_ci DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_price_categories`
--

CREATE TABLE `#__jstar_shop_price_categories` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_products`
--

CREATE TABLE `#__jstar_shop_products` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `multicost` tinyint(1) NOT NULL DEFAULT 0,
  `price` varchar(255) DEFAULT NULL,
  `off` int(11) DEFAULT NULL,
  `img1` varchar(255) DEFAULT NULL,
  `img2` varchar(255) DEFAULT NULL,
  `img3` varchar(255) DEFAULT NULL,
  `img4` varchar(255) DEFAULT NULL,
  `text2` text DEFAULT NULL,
  `metadesc` text DEFAULT NULL,
  `metakey` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `published` tinyint(1) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `w` varchar(255) DEFAULT NULL,
  `posts` varchar(255) DEFAULT NULL,
  `tag1` text DEFAULT NULL,
  `tag2` text DEFAULT NULL,
  `counttag` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `view` int(11) NOT NULL DEFAULT 0,
  `sales` int(11) NOT NULL DEFAULT 0,
  `best` tinyint(1) DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_recommends`
--

CREATE TABLE `#__jstar_shop_recommends` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `name_family` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `recommend` text COLLATE utf8_persian_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_similars`
--

CREATE TABLE `#__jstar_shop_similars` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `products_id` text COLLATE utf8_persian_ci DEFAULT NULL,
  `feilds` text COLLATE utf8_persian_ci DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `#__jstar_shop_users`
--

CREATE TABLE `#__jstar_shop_users` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `payam` text DEFAULT NULL,
  `ordering` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `#__jstar_shop_amazings`
--
ALTER TABLE `#__jstar_shop_amazings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_bankmsg`
--
ALTER TABLE `#__jstar_shop_bankmsg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_cits`
--
ALTER TABLE `#__jstar_shop_cits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_comments`
--
ALTER TABLE `#__jstar_shop_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_coupons`
--
ALTER TABLE `#__jstar_shop_coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_coupon_users`
--
ALTER TABLE `#__jstar_shop_coupon_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_customfields`
--
ALTER TABLE `#__jstar_shop_customfields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_feilds_products`
--
ALTER TABLE `#__jstar_shop_feilds_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_gifts`
--
ALTER TABLE `#__jstar_shop_gifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_group_fields`
--
ALTER TABLE `#__jstar_shop_group_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_interests`
--
ALTER TABLE `#__jstar_shop_interests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_multicosts`
--
ALTER TABLE `#__jstar_shop_multicosts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_orders`
--
ALTER TABLE `#__jstar_shop_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_order_details`
--
ALTER TABLE `#__jstar_shop_order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_payks`
--
ALTER TABLE `#__jstar_shop_payks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_payks_orders`
--
ALTER TABLE `#__jstar_shop_payks_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `factor` (`factor`);

--
-- Indexes for table `#__jstar_shop_posts`
--
ALTER TABLE `#__jstar_shop_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_price_categories`
--
ALTER TABLE `#__jstar_shop_price_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_products`
--
ALTER TABLE `#__jstar_shop_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_recommends`
--
ALTER TABLE `#__jstar_shop_recommends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_similars`
--
ALTER TABLE `#__jstar_shop_similars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `#__jstar_shop_users`
--
ALTER TABLE `#__jstar_shop_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `#__jstar_shop_amazings`
--
ALTER TABLE `#__jstar_shop_amazings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_bankmsg`
--
ALTER TABLE `#__jstar_shop_bankmsg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_cits`
--
ALTER TABLE `#__jstar_shop_cits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_comments`
--
ALTER TABLE `#__jstar_shop_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_coupons`
--
ALTER TABLE `#__jstar_shop_coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_coupon_users`
--
ALTER TABLE `#__jstar_shop_coupon_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_customfields`
--
ALTER TABLE `#__jstar_shop_customfields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_feilds_products`
--
ALTER TABLE `#__jstar_shop_feilds_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_gifts`
--
ALTER TABLE `#__jstar_shop_gifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_group_fields`
--
ALTER TABLE `#__jstar_shop_group_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_interests`
--
ALTER TABLE `#__jstar_shop_interests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_multicosts`
--
ALTER TABLE `#__jstar_shop_multicosts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_orders`
--
ALTER TABLE `#__jstar_shop_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_order_details`
--
ALTER TABLE `#__jstar_shop_order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_payks`
--
ALTER TABLE `#__jstar_shop_payks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_payks_orders`
--
ALTER TABLE `#__jstar_shop_payks_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_posts`
--
ALTER TABLE `#__jstar_shop_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_price_categories`
--
ALTER TABLE `#__jstar_shop_price_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_products`
--
ALTER TABLE `#__jstar_shop_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_recommends`
--
ALTER TABLE `#__jstar_shop_recommends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_similars`
--
ALTER TABLE `#__jstar_shop_similars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `#__jstar_shop_users`
--
ALTER TABLE `#__jstar_shop_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;