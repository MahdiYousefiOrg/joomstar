<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
class Jstar_shopTableRecommends extends JTable{
	public function __construct(&$db)
	{
		parent::__construct('#__jstar_shop_recommends', 'id', $db);
	}
	
		function check()
		{
			jimport( 'joomla.filter.output' );
		 
			/* All your other checks */
			return true;
		}	
	
	
	public function bind($array, $ignore = '')
	{
		return parent::bind($array, $ignore);
	}
	public function store($updateNulls = false)
	{
		return parent::store($updateNulls);
	}
	
	public function getdata($id)
	{
		$db			= JFactory::getDBO();
		$query		= $db->getQuery(true);
		$query->select('*');
		$query->from('#__jstar_shop_recommends');
		$query->where('id ='.$id);
		$db->setQuery($query);
		$faq = $db->loadObject();
		return $faq;
	}
	
	
}

?>