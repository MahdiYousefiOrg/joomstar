<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_jstar_shop_search_txt/assets/css/search_txt.css');
if ($_REQUEST['view'] != 'searched') {
    unset($_SESSION['search_txt']);
}
?>
<style>
</style>
<div class="c_header_search">
    <form action="<?php echo JRoute::_('index.php?option=com_jstar_shop&view=searched'); ?>" method="post"
          enctype="multipart/form-data">
        <input type="text" class="js-search-input" name="search_txt" value="<?php echo @$_SESSION['search_txt']; ?>"
               placeholder="<?php echo JText::_('MOD_JSTAR_SHOP_SEARCH_TXT_PRODUCT_NAME'); ?>"/>
        <input type="submit" name="search_txt_btn" id="search_txt_btn" value=""/>
        <div class="clear"></div>
    </form>
</div>
