<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');
 
class modJstar_shop_bestsHelper { 
	static function getBests($catids){
		$db			= JFactory::getDbo();
		if(!empty($catids)){
		$catids_str = implode(',',$catids);
		$catids_str = $db->escape( $catids_str );
			$query = "SELECT GROUP_CONCAT(`a`.`id`,'spaceProg',`a`.`title`,'spaceProg',`a`.`catid`,'spaceProg',`a`.`img1`,'spaceProg',`a`.`multicost`,'spaceProg',`a`.`status`,'spaceProg',`a`.`off`,'spaceProg') AS `article`, CONCAT(`b`.`title`) AS `category` FROM `#__jstar_shop_products`  AS `a` LEFT JOIN `#__categories` AS `b` ON `a`.`catid` = `b`.`id` WHERE `a`.`catid` IN ($catids_str) AND `a`.`best` = '1' GROUP BY `a`.`catid` ";
			$db->setQuery( $query );
			$bests = $db->LoadObjectList(); 
			return $bests;
		} else {
			return false;
		}
	}
}
