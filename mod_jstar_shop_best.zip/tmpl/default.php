<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStyleSheet('modules/mod_jstar_shop_best/assets/css/uikit.min.css');
$doc->addStyleSheet('modules/mod_jstar_shop_best/assets/css/main.css');
?>
<script src='<?php echo JURI::base(true) . '/modules/mod_jstar_shop_best/assets/js/uikit.min.js'; ?>'></script>
<script src='<?php echo JURI::base(true) . '/modules/mod_jstar_shop_best/assets/js/uikit-icons.min.js'; ?>'></script>
<?php
if($rows != 0){
    $amazings = Jstar_shop_CHeckupHelper::getAmazings();
foreach ($rows as $i => $item) { ?>
    <div class="row-fluid">
        <div class="title_best">
            <?php echo $item->category; ?>
        </div>
        <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slider>
            <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-3@m uk-grid">

                <?php
                $into_rows = explode(',', $item->article);
                foreach ($into_rows as $into_row) {
                    $product = explode('spaceProg', $into_row);
                    $link = JRoute::_('index.php?option=com_jstar_shop&view=product&id=' . $product[0]);
                    ?>
                    <li>
                        <a class="link_best" href="<?php echo $link; ?>">
                            <div class="uk-panel best_product">
                                <?php if ($off = array_search($product[0], $amazings)) {
                                    $off = explode('-',$off)[1];
                                    ?>
                                    <div class="c-promotion__discount">
                                        <span><?php echo '%'.$off; ?></span>
                                    </div>
                                <?php } else { $off = 0; } ?>
                                <img src="<?php echo JURI::base() . $product[3]; ?>" alt="">
                                <div class="uk-panel">
                                    <span id="product_title"><?php echo $product[1]; ?></span>
                                </div>
                                <div class="uk-panel">
                                    <span id="product_title"><?php echo Jstar_shop_Fa_digits::fa_digits(number_format($product[6]-(round($product[6]*$off/100)))) . JText::_('COM_JSTAR_SHOP_TOMAN'); ?></span>
                                </div>
                            </div>
                        </a>
                    </li>
                <?php } ?>
            </ul>
            <a class="uk-position-center-right uk-position-small " href="#" uk-slidenav-previous
               uk-slider-item="previous"></a>
            <a class="uk-position-center-left uk-position-small " href="#" uk-slidenav-next uk-slider-item="next"></a>
        </div>
    </div>
<?php }
}
?>
