<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die('Restricted access');

class modJstar_shop_searchHelper
{
    static function getparents($catID)
    {
        $db = JFactory::getDbo();
        $catID = $db->escape($catID);
        $view = JFactory::getApplication()->input->get('view');
        $query = "SELECT `parent`.`id` FROM `#__categories` AS `node`, `#__categories` AS `parent` WHERE `node`.`lft` BETWEEN `parent`.`lft` AND `parent`.`rgt` AND `node`.`id` = '$catID' ORDER BY `parent`.`lft` ";
        $db->setQuery($query);
        $parentids = $db->LoadColumn();
        return $parentids;
    }

    static function getItems($catids)
    {
        $db = JFactory::getDbo();
        $catids = $db->escape($catids);
        $table = $db->quoteName('#__jstar_shop_customfields');
        $query = "SELECT * FROM $table WHERE `catid` IN ($catids) AND `published` = 1 AND `search` = '1' AND `type` != '1' AND `type` != '4' AND `type` != '5' AND `multi` != '1'";
        $db->setQuery($query);
        $rows = $db->LoadObjectList();
        return $rows;
    }
}
