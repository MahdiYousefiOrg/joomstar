<?php
/**
 * @package	StarShop for Joomla!
 * @version	1.0.9
 * @author	joomstar.ir
 * @copyright	(C) 2012-2020 JOOMSTAR.IR SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_jstar_shop_search/assets/css/search.css');
$view = JFactory::getApplication()->input->get('view');
$params = JComponentHelper::getParams('com_jstar_shop');
$method = $params->get('method');
switch ($method) {
    case 2:
        $form_method = 'get';
        break;
    case 1:
        $form_method = 'post';
        break;
}
$db = JFactory::getDBO();
unset($search);
if ($view == 'category') {
    $catID = JFactory::getApplication()->input->get('id');

    $parentids = modJstar_shop_searchHelper::getparents($catID);
    $catids = implode(',', $parentids);

    $rows = modJstar_shop_searchHelper::getItems($catids);

    $search = @$_REQUEST['search'];
    if (isset($search)) {
        $_SESSION['search2'] = $search;
    } else {
        unset($_SESSION['search2']);
        unset($search);
    }
    ?>

    <div id="search_module" class="search_mod">
        <div id="search_adv" class="search_adv"><?php echo JText::_('MOD_JSTAR_SHOP_SEARCH_ADV'); ?></div>
        <form action="<?php echo JRoute::_('index.php?option=com_jstar_shop', false); ?>"
              method="<?php echo $form_method; ?>" enctype="multipart/form-data" id="easys22">
            <div id="search_adv_hidden">
                <?php foreach ($rows as $row) {
                    if ($row->type != 1) {
                        $values = explode('-', $row->value);
                        echo '<div class="search_div">';
                        echo '<div id="search_sh" class="search_title" onclick="myFunctionhide(' . $row->id . ')"><span>' . $row->title . '</span><span class="search_span_show">+</span><div class="clear"></div></div>';
                        echo '<ul id="search_hi' . $row->id . '" class="search_ul">';
                        foreach ($values as $value) {
							$value = $db->escape( $value );
                            $query = "SELECT `values` FROM `#__jstar_shop_feilds_products` WHERE `values` = '$value'";
                            $db->setQuery($query);
                            $checkvalue = $db->LoadResult();

                            if ($checkvalue) {
                                if (isset($_SESSION['search2'])) {
                                    if (in_array($row->id . '-' . $value, $_SESSION['search2'])) {
                                        @$checked = 'checked="CHECKED"';
                                    } else {
                                        $checked = '';
                                    }
                                }
                                echo '<li class="search_li">';
                                echo '<input type="checkbox" class="search1" name="search[]" onchange="form.submit()" value="' . $row->id . '-' . $value . '" ' . @$checked . ' />' . $value;
                                echo '</li>';
                            }
                        }
                        echo '</ul>';
                        echo '</div>';
                    }
                    ?>
                <?php } ?>
            </div>
            <input type="hidden" name="option" value="com_jstar_shop"/>
            <input type="hidden" name="view" value="<?php echo $view; ?>"/>
            <input type="hidden" name="option" value="com_jstar_shop"/>
            <input type="hidden" name="view" value="<?php echo $view; ?>"/>
            <input type="hidden" name="id" value="<?php echo $catID; ?>"/>
        </form>
    </div>
    <script>
        function myFunctionhide(fields) {
            var x = document.getElementById("search_hi" + fields);
            if (x.style.display == 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>
<?php } ?>
